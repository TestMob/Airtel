CREATE PROCEDURE [usp_CorporateDealerErrorView] (@i_strAccount_No varchar(100), @o_strErrorMessage varchar(500) output)
AS
BEGIN
	Set @o_strErrorMessage = ''
	Set @o_strErrorMessage = (Select Top 1 CDE_Error_Message From Corporate_Dealer_Error Where CDE_Account_No = @i_strAccount_No)
END