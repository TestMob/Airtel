CREATE PROCEDURE [usp_DealerOutstandingReport] (@i_strAccount_No varchar(16))
AS
BEGIN 
	DECLARE @AsOnDate datetime
	Declare @DealerID varchar(10) 	
	
	SELECT  TOP 1 @AsOnDate =  REPLACE(CONVERT(VARCHAR(20),SM_Scheduler_Date,106),' ','-')  
	FROM SCHEDULER_MASTER ORDER BY SM_Scheduler_Id DESC
	Set @DealerID = (Select DM_Dealer_Id From Dealer_master Where DM_Account_No = @i_strAccount_No)
	
	SELECT 
        DM_Dealer_Id, DM_Account_no As [Account No], DM_PARENT_LIMIT_ID_PREFIX [Corporate Name], replace(DM_DEALER_NAME,'"','') [Dealer Name], DM_Dealer_Corporate_Name As [Dealer's Corporate Name], DM_Customer_Id As [Customer ID], 
        DD_DEALER_LIMIT [Sanction Limit], DD_Tenor As [Tenor (In Days)], DD_PEAK_LIMIT [Peak Limit],  DD_PEAK_TENOR [Peak Limit Tenor(In Days)],      
	( 
        --OUTSTANDING - BEYOND CURE (QUERY FROM DATEDIFF DATE 15THAPRIL WHERE ACCNO=DM.ACCNO), 
        SELECT 
                SUM(DD_OUTSTANDING_AMOUNT) 
        FROM 
                Transaction_Master , Debit_Details 
        WHERE 
                TM_UPLOAD_TRAN_ID = DD_UPLOAD_TRAN_ID 
                AND DD_OUTSTANDING_AMOUNT > 0 
                AND (DD_OUTSTANDING_FROM <= @AsOnDate AND DD_OUTSTANDING_TILL >= @AsOnDate) 
                AND TM_ACCOUNT_NO = DM.DM_ACCOUNT_NO 
		AND DD_Penal_Rate IS NOT NULL	
        ) [Overdue Beyond Cure],       
		REPLACE(CONVERT(VARCHAR(20), @AsOnDate,106),' ','-') As [As On Date], REPLACE(CONVERT(VARCHAR(20), GetDate() ,106),' ','-') As [Report Date]
	FROM DEALER_MASTER DM, DEALER_DETAILS DD 
	WHERE 
		DM_DEALER_ID = DD_DEALER_ID 
	AND 
		DD_Status = 'A' 
	AND 
	(
	DD_EFFECTIVE_FROM <= @AsOnDate 
	AND 
        ISNULL(DD_EFFECTIVE_TILL,GETDATE()) >= @AsOnDate
	)
	And DM_ACCOUNT_NO = @i_strAccount_No	 	
	Exec [usp_ReportDealerwiseOutstanding] @DealerID, @AsOnDate,'','',0,0,0,0,0,''
END