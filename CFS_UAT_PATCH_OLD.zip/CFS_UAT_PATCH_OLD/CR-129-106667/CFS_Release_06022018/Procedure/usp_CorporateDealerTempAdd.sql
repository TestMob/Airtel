
/*
Name		: usp_CorporateDealerTempAdd
Purpose    	: Insert Corporate in temp table
Input Parameter : 
Output Parameter: 
SPs Referred	: 
Created By  	: Sandhya Parab 
Created On  	: 01-Feb-2018
Modified By 	: 
Modified On 	: 
Purpose Of Modification:
*/
CREATE PROCEDURE [usp_CorporateDealerTempAdd]	 
	@i_strDealerName varchar(100), 
	@i_strAccount_No varchar(100), 
	@i_strCustomerId varchar(100),
	@i_strSanctionLimit varchar(100),
	@i_strSanctionDate varchar(100),
	@i_strExpiryDate varchar(100),
	@i_strRenewalDate varchar(100),
	@i_strLimitIdPrefix varchar(100), 
	@i_strLimitIdSuffix varchar(100),
	@i_strParentLimitIdPrefix varchar(100),
	@i_strParentLimitIdSuffix varchar(100),
	@i_strAddress1 varchar(250),
	@i_strAddress2 varchar(250),
	@i_strCity varchar(100), 
	@i_strState varchar(100),
	@i_strPin varchar(100),
	@i_strPhoneNo varchar(100),
	@i_strEmailID varchar(100),
	@i_strAccountOpenDate varchar(100),
	@i_strAccountCloseDate varchar(100), 
	@i_strAccountStatus varchar(100),
	@i_strProgramLimit varchar(100),
	@i_strProgramSanctionDate varchar(100),
	@i_strProgramExpiryDate varchar(100),
	@i_strProgramRenewalDate varchar(100),
	@i_strDocumentationDate varchar(100), 
	@i_strDoc1 varchar(100),
	@i_strDoc2 varchar(100),
	@i_strDoc3 varchar(100),
	@i_strDoc4 varchar(100),
	@i_strDoc5 varchar(100),
	@i_strDoc6 varchar(100), 
	@i_strDoc7 varchar(100),
	@i_strDoc8 varchar(100),
	@i_strDoc9 varchar(100),
	@i_strDoc10 varchar(100),
	@i_strDealerShortName varchar(100),
	@i_strSolID varchar(100),
	@i_strDealerCorporateName varchar(100),
	@i_strUploadFileId varchar(10),
	@o_strReturnFlag char(1) output -- S=Success/E=Error/D=Duplicate
AS
BEGIN
SET NOCOUNT ON 
	BEGIN
		DECLARE @strDealerName varchar(100) 
		DECLARE @strAccount_No varchar(100) 
		DECLARE @strCustomerId varchar(100)
		DECLARE @strSanctionLimit varchar(100)
		DECLARE @strSanctionDate varchar(100)
		DECLARE @strExpiryDate varchar(100)
		DECLARE @strRenewalDate varchar(100)
		DECLARE @strLimitIdPrefix varchar(100)
		DECLARE @strLimitIdSuffix varchar(100)
		DECLARE @strParentLimitIdPrefix varchar(100)
		DECLARE @strParentLimitIdSuffix varchar(100)
		DECLARE @strAddress1 varchar(250)
		DECLARE @strAddress2 varchar(250)
		DECLARE @strCity varchar(100)
		DECLARE @strState varchar(100)
		DECLARE @strPin varchar(100)
		DECLARE @strPhoneNo varchar(100)
		DECLARE @strEmailID varchar(100)
		DECLARE @strAccountOpenDate varchar(100)
		DECLARE @strAccountCloseDate varchar(100)
		DECLARE @strAccountStatus varchar(100)
		DECLARE @strProgramLimit varchar(100)
		DECLARE @strProgramSanctionDate varchar(100)
		DECLARE @strProgramExpiryDate varchar(100)
		DECLARE @strProgramRenewalDate varchar(100)
		DECLARE @strDocumentationDate varchar(100) 
		DECLARE @strDoc1 varchar(100)
		DECLARE @strDoc2 varchar(100)
		DECLARE @strDoc3 varchar(100)
		DECLARE @strDoc4 varchar(100)
		DECLARE @strDoc5 varchar(100)
		DECLARE @strDoc6 varchar(100) 
		DECLARE @strDoc7 varchar(100)
		DECLARE @strDoc8 varchar(100)
		DECLARE @strDoc9 varchar(100)
		DECLARE @strDoc10 varchar(100)
		DECLARE @strDealerShortName varchar(100)
		DECLARE @strSolID varchar(100)
		DECLARE @strDealerCorporateName varchar(100)
		DECLARE @strFileID varchar(10)
		DECLARE @intError NUMERIC(10)
	
		SET @strDealerName = @i_strDealerName 
		SET @strAccount_No = @i_strAccount_No 
		SET @strCustomerId  = @i_strCustomerId 
		SET @strSanctionLimit  = @i_strSanctionLimit 
		SET @strSanctionDate  = @i_strSanctionDate 
		SET @strExpiryDate  = @i_strExpiryDate 
		SET @strRenewalDate  = @i_strRenewalDate 
		SET @strLimitIdPrefix  = @i_strLimitIdPrefix 
		SET @strLimitIdSuffix  = @i_strLimitIdSuffix 
		SET @strParentLimitIdPrefix  = @i_strParentLimitIdPrefix 
		SET @strParentLimitIdSuffix  = @i_strParentLimitIdSuffix 
		SET @strAddress1  = @i_strAddress1 
		SET @strAddress2  = @i_strAddress2 
		SET @strCity  = @i_strCity 
		SET @strState  = @i_strState 
		SET @strPin  = @i_strPin 
		SET @strPhoneNo  = @i_strPhoneNo 
		SET @strEmailID  = @i_strEmailID 
		SET @strAccountOpenDate  = @i_strAccountOpenDate 
		SET @strAccountCloseDate  = @i_strAccountCloseDate 
		SET @strAccountStatus  = @i_strAccountStatus 
		SET @strProgramLimit  = @i_strProgramLimit 
		SET @strProgramSanctionDate  = @i_strProgramSanctionDate 
		SET @strProgramExpiryDate  = @i_strProgramExpiryDate 
		SET @strProgramRenewalDate  = @i_strProgramRenewalDate 
		SET @strDocumentationDate  = @i_strDocumentationDate 
		SET @strDoc1  = @i_strDoc1 
		SET @strDoc2  = @i_strDoc2 
		SET @strDoc3  = @i_strDoc3 
		SET @strDoc4  = @i_strDoc4 
		SET @strDoc5  = @i_strDoc5 
		SET @strDoc6  = @i_strDoc6 
		SET @strDoc7  = @i_strDoc7 
		SET @strDoc8  = @i_strDoc8 
		SET @strDoc9  = @i_strDoc9 
		SET @strDoc10  = @i_strDoc10 
		SET @strDealerShortName  = @i_strDealerShortName 
		SET @strSolID  = @i_strSolID 
		SET @strDealerCorporateName  = @i_strDealerCorporateName 
		SET @strFileID = @i_strUploadFileId
		
		SET @o_strReturnFlag  = 'S'
	END
  BEGIN
  Begin Transaction
		TRUNCATE Table Corporate_Dealer_Error    
		TRUNCATE Table Corporate_Dealer_Temp  
		Insert Into CORPORATE_DEALER_TEMP
		Select
		  @strDealerName , 
		  @strAccount_No , 
		  @strCustomerId ,
		  @strSanctionLimit ,
		  @strSanctionDate ,
		  @strExpiryDate ,
		  @strRenewalDate ,
		  @strLimitIdPrefix ,
		  @strLimitIdSuffix ,
		  @strParentLimitIdPrefix ,
		  @strParentLimitIdSuffix ,
		  @strAddress1 ,
		  @strAddress2 ,
		  @strCity ,
		  @strState ,
		  @strPin ,
		  @strPhoneNo ,
		  @strEmailID ,
		  @strAccountOpenDate ,
		  @strAccountCloseDate ,
		  @strAccountStatus ,
		  @strProgramLimit ,
		  @strProgramSanctionDate ,
		  @strProgramExpiryDate ,
		  @strProgramRenewalDate ,
		  @strDocumentationDate , 
		  @strDoc1 ,
		  @strDoc2 ,
		  @strDoc3 ,
		  @strDoc4 ,
		  @strDoc5 ,
		  @strDoc6 , 
		  @strDoc7 ,
		  @strDoc8 ,
		  @strDoc9 ,
		  @strDoc10 ,
		  @strDealerShortName ,
		  @strSolID ,
		  @strDealerCorporateName
		
		
		Update UPLOAD_FILE_MASTER
		Set UFM_Total_Records = (Select Count(*) From CORPORATE_DEALER_TEMP)
		Where UFM_Upload_File_Id = @strFileID
		SET @intError = @@ERROR
		If (@intError <> 0) 
			Goto Err_handler
Commit Transaction
		  
	END	
Err_Handler:
	BEGIN
		IF (@intError <> 0)
		BEGIN
			Rollback Transaction
			SET @o_strReturnFlag = 'E'
		END	
	END
SET NOCOUNT OFF
END