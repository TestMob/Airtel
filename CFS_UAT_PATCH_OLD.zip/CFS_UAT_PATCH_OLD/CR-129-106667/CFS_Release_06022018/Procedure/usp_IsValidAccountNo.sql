
/*
Purpose    	: To check Account No exists or not
Tables Used 	: Dealer_Master
Input Parameter : @i_strAccountNo
Output Parameter: @o_strIsValidAccount 
Created By  	: Sandhya Parab
Created On  	: 05.02.2018
*/
CREATE  Procedure [usp_IsValidAccountNo]
	@i_strAccount_No as varchar(20),
	@o_strReturnFlag as char(1) output
AS
BEGIN
	SET NOCOUNT ON 
	
	SET @o_strReturnFlag = 'N'	
	SELECT 	
		DM_Account_No
	FROM 
	Dealer_master	
	WHERE
	DM_Account_No   = @i_strAccount_No
	IF(@@RowCount > 0)
	BEGIN
		SET @o_strReturnFlag = 'Y'
	END
	ELSE
	BEGIN
		SET @o_strReturnFlag = 'N'
	END
	SET NOCOUNT OFF	
END