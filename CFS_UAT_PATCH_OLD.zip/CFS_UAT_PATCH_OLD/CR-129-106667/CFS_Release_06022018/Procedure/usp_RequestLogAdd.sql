
/*
Name		: usp_RequestLogAdd
Purpose    	: Insert new request
Input Parameter : @i_strTokenNo, @i_strRequestData, @i_strResponseData, @i_strIPAddress
Output Parameter: @o_strReturnFlag
SPs Referred	: 
Created By  	: Sandhya Parab 
Created On  	: 01-Feb-2018
Modified By 	: 
Modified On 	: 
Purpose Of Modification:
*/
CREATE PROCEDURE [usp_RequestLogAdd]	 
	@i_strTokenNo varchar(20), 
	@i_strRequestData varchar(max),
	@i_strResponseData varchar(max),
	@i_strIPAddress varchar(50),
	@o_strReturnFlag char(1) output -- S=Success/E=Error/D=Duplicate
AS
BEGIN
SET NOCOUNT ON 
	BEGIN	
		DECLARE @strTokenNo varchar(20)
		DECLARE @strRequestData varchar(max)
		DECLARE @strResponseData varchar(max)
		DECLARE @strIPAddress varchar(50)	
		DECLARE @intError as numeric(10)
	
		SET @strTokenNo = @i_strTokenNo
		SET @strRequestData = @i_strRequestData
		SET @strResponseData = @i_strResponseData
		SET @strIPAddress = @i_strIPAddress
		SET @o_strReturnFlag  = 'S'
	END
	BEGIN
		INSERT INTO Request_Log
		(
			Token_No,
			Request_Data,
			Response_Data,
			IP_Address,
			Created_On
		)
		VALUES
		(
			@strTokenNo,
			@strRequestData,
			@strResponseData,
			@strIPAddress,
			GetDate()
		)
		SET @intError = @@ERROR
		If (@intError <> 0) 
			Goto Err_handler
		RETURN  
	END	
Err_Handler:
	BEGIN
		IF (@intError <> 0)
		BEGIN
			SET @o_strReturnFlag = 'E'
		END	
	END
SET NOCOUNT OFF
END