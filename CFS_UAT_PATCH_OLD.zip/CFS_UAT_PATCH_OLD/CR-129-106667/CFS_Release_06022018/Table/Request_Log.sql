USE [CFS]
GO

/****** Object:  Table [dbo].[Request_Log]    Script Date: 06-02-2018 17:30:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Request_Log](
	[Log_ID] [numeric](20, 0) IDENTITY(1,1) NOT NULL,
	[Token_No] [varchar](20) NULL,
	[Request_Data] [varchar](max) NULL,
	[Response_Data] [varchar](max) NULL,
	[IP_Address] [varchar](50) NULL,
	[Created_On] [datetime] NULL,
 CONSTRAINT [PK_Request_Log] PRIMARY KEY CLUSTERED 
(
	[Log_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


