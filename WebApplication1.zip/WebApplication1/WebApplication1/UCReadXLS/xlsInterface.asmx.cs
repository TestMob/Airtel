﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebApplication1.UCReadXLS
{
    /// <summary>
    /// Summary description for xlsInterface
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.Web.Script.Services.ScriptService]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class xlsInterface : System.Web.Services.WebService
    {

        //[WebMethod]
        //public string getxldata(string sheet, string xlsName)
        //{
        //    string strResult = string.Empty;
        //    string FilePath = string.Empty;
        //    xlsReadWrite objread = new xlsReadWrite();
        //    string Folders = Convert.ToString(ConfigurationManager.AppSettings["xlsFolders"]);
        //    if (Folders.Contains(","))
        //    {
        //        string[] arrFolder = Folders.Split(',');
        //        for (int i = 0; i < arrFolder.Length; i++)
        //        {
        //            // We are consider the folder of excel that placed in parent application folder.
        //            if (File.Exists(Server.MapPath(arrFolder[i]).Replace("\\UCReadXLS", "") + "\\" + xlsName))
        //            {
        //                FilePath = Server.MapPath(arrFolder[i]).Replace("\\UCReadXLS", "") + "\\" + xlsName;
        //                break;
        //            }
        //        }
        //    }
        //    else
        //    {
        //        FilePath = Server.MapPath(Folders).Replace("\\UCReadXLS", "") + "\\" + xlsName;
        //    }

        //    string[] ArrFileName = xlsName.Split('.');

        //    strResult = objread.ReadExcel(FilePath, "." + ArrFileName[1].ToLower().ToString(), "Yes");
        //    return strResult;
        //}

        [WebMethod]
        public string getxldata(string sheet, string xlsName)
        {
            string strResult = string.Empty;
            xlsReadWrite objread = new xlsReadWrite(System.Web.HttpContext.Current.Server.MapPath("Logs/ErrorLog"));
            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];
            string FilePath = System.Web.HttpContext.Current.Server.MapPath(FolderPath + xlsName);
            string[] ArrFileName = xlsName.Split('.');

            strResult = objread.Import_To_Grid(FilePath, "." + ArrFileName[1].ToLower().ToString(), "Yes", xlsName);
            return strResult;
        }

        [WebMethod]
        public string savexldata(string xlsData, string xlsHeader)
        {

            string strResult = string.Empty;
            string xlsName = string.Empty;
            strResult = "[{response:'exception occured'}]";
            xlsName = "xls_Demo_" + DateTime.Now.ToString("ddMMyyyyhhmmss");
            DataTable dt = new DataTable();
            xlsReadWrite objwrite = new xlsReadWrite(System.Web.HttpContext.Current.Server.MapPath("Logs/ErrorLog"));
            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];
            string FilePath = System.Web.HttpContext.Current.Server.MapPath(FolderPath);
            strResult = objwrite.UpdateXLS(xlsData, FilePath, xlsName, xlsHeader);
            return strResult;
        }
    }
}
