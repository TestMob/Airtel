﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;
using System.Xml;
//using Microsoft.Office.Interop;
using xl = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;
using System.Text;
//using DocumentFormat.OpenXml.Packaging;
//using DocumentFormat.OpenXml.Spreadsheet;


public class xlsReadWrite
{

    string _strLogPath;
    CreateLogFiles Log;

    public xlsReadWrite(string LogPath)
    {
        _strLogPath = LogPath;
        Log = new CreateLogFiles();
    }

    public string Import_To_Grid(string FilePath, string Extension, string isHDR, string FileName = "")
    {
        Log.ErrorLog(_strLogPath, "Function Start : Import_To_Grid");
        string conStr = "";
        OleDbConnection connExcel = new OleDbConnection();
        OleDbCommand cmdExcel;
        OleDbDataAdapter oda;
        DataTable dt = new DataTable();
        DataTable dtResult = new DataTable();
        try
        {
            switch (Extension)
            {
                case ".xls": //Excel 97-03
                    conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"]
                             .ConnectionString;
                    break;
                case ".xlsx": //Excel 07
                    conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"]
                              .ConnectionString;
                    break;
            }

            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];

            do
            {
                FilePath = Directory.GetParent(FilePath).FullName.ToString();

            } while (!Directory.Exists(FilePath + @"\" + FolderPath));

            FilePath = FilePath + @"\" + FolderPath + FileName;

            conStr = String.Format(conStr, FilePath, isHDR);
            connExcel = new OleDbConnection(conStr);
            cmdExcel = new OleDbCommand();
            oda = new OleDbDataAdapter();
            dt = new DataTable();
            cmdExcel.Connection = connExcel;

            //Get the name of First Sheet
            connExcel.Open();
            DataTable dtExcelSchema;
            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

            DataTable dtSchema = new DataTable();
            dtSchema = connExcel.GetSchema();

            connExcel.Close();

            //Read Data from First Sheet
            connExcel.Open();
            cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
            oda.SelectCommand = cmdExcel;
            oda.Fill(dt);
            connExcel.Close();
        }
        catch (Exception ex)
        {
            Log.ErrorLog(_strLogPath, ex.ToString());

        }
        finally
        {
            if (connExcel.State == ConnectionState.Open)
            {
                connExcel.Close();
            }
            connExcel.Dispose();
            cmdExcel = null;
            oda = null;
            Log.ErrorLog(_strLogPath, "Function End : Import_To_Grid");
        }

        //dt = ReadXlsxFile(FilePath + Extension);

        //dt = ImportDataFromExcel(FilePath + Extension);
        dtResult = BindDTWithTableHeader(dt);

        //dtResult = GetXlFormating(FilePath + Extension);
        return DataTableToJSONWithJSONNet(dtResult);
        //Bind Data to GridView

    }



    //private DataTable ImportDataFromExcel(string FilePath)
    //{
    //    //Create a new DataTable.
    //    DataTable dt = new DataTable();

    //    using (SpreadsheetDocument doc = SpreadsheetDocument.Open(FilePath, false))
    //    {
    //        //Read the first Sheet from Excel file.
    //        Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

    //        //Get the Worksheet instance.
    //        Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

    //        //Fetch all the rows present in the Worksheet.
    //        IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();


    //        //Loop through the Worksheet rows.
    //        foreach (Row row in rows)
    //        {
    //            //Use the first row to add columns to DataTable.
    //            if (row.RowIndex.Value == 1)
    //            {
    //                foreach (Cell cell in row.Descendants<Cell>())
    //                {
    //                    dt.Columns.Add(GetValue(doc, cell));
    //                }
    //            }
    //            else
    //            {
    //                //Add rows to DataTable.
    //                dt.Rows.Add();
    //                int i = 0;
    //                foreach (Cell cell in row.Descendants<Cell>())
    //                {
    //                    dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
    //                    i++;
    //                }
    //            }
    //        }
    //    }

    //    return dt;

    //}

    //private string GetValue(SpreadsheetDocument doc, Cell cell)
    //{
    //    string value = cell.CellValue.InnerText;

    //    if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
    //    {
    //        value = doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
    //    }

    //    if (String.IsNullOrEmpty(value)) value = "N.A.";
    //    return value;
    //}

    private DataTable ReadXlsxFile(string path)
    {
        ////using (var pck = new OfficeOpenXml.ExcelPackage())
        ////{
        ////    using (var stream = File.OpenRead(path))
        ////    {
        ////        pck.Load(stream);
        ////    }
        ////    var ws = pck.Workbook.Worksheets.First();
        ////    DataTable tbl = new DataTable();
        ////    bool hasHeader = true;
        ////    foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
        ////    {
        ////        tbl.Columns.Add(hasHeader ? firstRowCell.Text : string.Format("Column {0}", firstRowCell.Start.Column));
        ////    }
        ////    var startRow = hasHeader ? 2 : 1;
        ////    for (var rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
        ////    {
        ////        var wsRow = ws.Cells[rowNum, 1, rowNum, ws.Dimension.End.Column];
        ////        var row = tbl.NewRow();
        ////        foreach (var cell in wsRow)
        ////        {
        ////            row[cell.Start.Column - 1] = cell.Text;
        ////        }
        ////        tbl.Rows.Add(row);
        ////    }
        ////    return tbl;
        ////}

        return new DataTable();
    }

    private DataTable GetXlFormating(string FilePath)
    {
        string strResult = string.Empty;
        //Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
        //Microsoft.Office.Interop.Excel.Workbooks xlWorkBooks = xlApp.Workbooks;
        //Microsoft.Office.Interop.Excel.Workbook xlWorkBook = xlWorkBooks.Open(FilePath);
        //Microsoft.Office.Interop.Excel.Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
        //Microsoft.Office.Interop.Excel.Range xlRange = null;
        DataTable Dt = new DataTable();


        var xlApp = new xl.Application();
        //var xlWorkBook = xlApp.Workbooks.Open(@"E:\Book1.xlsx");
        //var xlWorkSheet = xlWorkBook.Sheets[1];
        //var xlRange = xlWorkSheet.UsedRange;
        //xl.Workbook activeWorkBook = xlApp.Workbooks.Open(@"E:\Book1.xlsx");
        //xl.Worksheet ActiveWorksheet = 
        xl.Workbook xlWorkBook = xlApp.Workbooks.Open(FilePath);
        xl.Worksheet xlWorkSheet = (xl.Worksheet)xlWorkBook.Sheets[1];
        xl.Range xlRange = xlWorkSheet.UsedRange;

        int xlCol = xlRange.Columns.Count;
        int xlrow = xlRange.Rows.Count;

        try
        {

            if (xlApp == null)
            {
                strResult = "[{response:'Excel is not properly installed!!'}]";
            }


            //Add Column in DataTable,

            for (int r = 1; r <= xlrow; r++)
            {
                if (r > 1)
                    break;

                for (int c = 1; c <= xlCol; c++)
                {
                    //xlRange = workSheet.Range[workSheet.Cells[r, c], workSheet.Cells[r, c]];
                    //object objtemp = ((Microsoft.Office.Interop.Excel.Range)(xlRange.Cells[r, c])).Value;
                    //string str = Convert.ToString(objtemp);
                    xl.Range currentCell = (xl.Range)xlWorkSheet.Cells[r, c];

                    //xlRange = workSheet.Range[workSheet.Cells[r, c], workSheet.Cells[r, c]];
                    //var ColHeader = ((Microsoft.Office.Interop.Excel.Range)(xlRange.Cells[r, c])).Text;

                    if (Convert.ToString(currentCell.Text) != "")
                    {
                        Dt.Columns.Add(currentCell.Text.ToString());
                    }
                    else
                    {
                        xlCol = c - 1;
                        break;
                    }
                }
            }

            for (int r = 1; r <= xlrow; r++)
            {
                DataRow dr;
                dr = Dt.NewRow();

                for (int c = 1; c <= xlCol; c++)
                {
                    //xlRange = workSheet.Range[workSheet.Cells[r, c], workSheet.Cells[r, c]];
                    //var CellVal = ((Microsoft.Office.Interop.Excel.Range)(xlRange.Cells[r, c])).Text;

                    xl.Range currentCell = (xl.Range)xlWorkSheet.Cells[r, c];

                    if (Convert.ToString(currentCell.Text) != "")
                    {
                        dr[c - 1] = currentCell.Text.ToString();
                    }
                }
                Dt.Rows.Add(dr);
            }

            //xlWorkBook.Save();


            //strResult = "[{response:'Excel file created, File Name : " + xlsName + ".xls'}]";
        }
        catch (Exception ex)
        {
            strResult = "[{response:'exception error : " + ex.ToString() + "'}]";
            Log.ErrorLog(_strLogPath, ex.ToString());

        }
        finally
        {
            xlWorkBook.Close();
        }

        return Dt;

    }

    private DataTable BindDTWithTableHeader(DataTable dtIn)
    {
        DataTable dt = new DataTable();

        if (dtIn.Columns.Count > 0)
        {
            for (int c = 0; c < dtIn.Columns.Count; c++)
            {
                dt.Columns.Add(dtIn.Columns[c].ColumnName + "");
            }

            DataRow dr = null;
            dr = dt.NewRow();

            for (int c = 0; c < dtIn.Columns.Count; c++)
            {
                dr[dtIn.Columns[c].ColumnName + ""] = dtIn.Columns[c].ColumnName + "";
            }

            dt.Rows.Add(dr);

            for (int r = 0; r < dtIn.Rows.Count; r++)
            {
                dr = null;
                dr = dt.NewRow();

                for (int c = 0; c < dtIn.Columns.Count; c++)
                {
                    try
                    {
                        //Only for DateTime.
                        if (dtIn.Columns[c].DataType.FullName == "System.DateTime")
                        {
                            if (Convert.ToString(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]) != "")
                            {
                                if (Convert.ToDateTime(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]).ToString("HH:mm:ss") == "00:00:00")
                                {
                                    dr[dtIn.Columns[c].ColumnName + ""] = Convert.ToDateTime(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]).ToString("dd-MM-yyyy");
                                }
                                else if (Convert.ToDateTime(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]).ToString("dd-MM-yyyy") == "30-12-1899")
                                {
                                    dr[dtIn.Columns[c].ColumnName + ""] = Convert.ToDateTime(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]).ToString("HH:mm:ss");
                                }
                            }
                        }
                        else if (dtIn.Columns[c].DataType.FullName == "System.String")
                        {
                            if (Convert.ToString(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]) != "")
                            {
                                if (IsExponentialValue(Convert.ToString(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""])))
                                {
                                    dr[dtIn.Columns[c].ColumnName + ""] = ParseExponential(Convert.ToString(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]));
                                }
                                else
                                {
                                    dr[dtIn.Columns[c].ColumnName + ""] = Convert.ToString(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]);
                                }
                            }

                        }
                        else
                        {
                            dr[dtIn.Columns[c].ColumnName + ""] = Convert.ToString(dtIn.Rows[r][dtIn.Columns[c].ColumnName + ""]);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.ErrorLog(_strLogPath, "Excel Row" + r.ToString() + "And Column" + c.ToString() + " Ex : BindDTWithTableHeader " + ex.ToString());
                    }
                }
                dt.Rows.Add(dr);
            }
        }


        return dt;
    }

    private bool IsExponentialValue(string strVal)
    {
        bool IsExpo = false;

        if (strVal.Contains("e") || strVal.Contains("E"))
        {
            string pattern = @"^\d{1}.\d+(E\+)\d+$";
            try
            {
                Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
                IsExpo = rgx.IsMatch(strVal);
            }
            catch (Exception ex)
            {
                Log.ErrorLog(_strLogPath, " fn : IsExponentialValue : Req Conversion Value: " + strVal + " Error Ex: " + ex.ToString());
            }
        }
        return IsExpo;
    }


    private double ParseExponential(string strVal)
    {
        double result = 0;
        try
        {
            double.TryParse(strVal, out result);
        }
        catch (Exception ex)
        {
            Log.ErrorLog(_strLogPath, " fn : ParseExponential : Req Conversion Value: " + strVal + " Error Ex: " + ex.ToString());
        }

        return result;
    }
    public string DataTableToJSONWithJSONNet(DataTable table)
    {
        string JSONString = string.Empty;
        JSONString = JsonConvert.SerializeObject(table);
        return JSONString;
    }


    public string UpdateXLS(string jsonString, string FilePath, string xlsName, string jsonHeader)
    {
        string FolderPath = ConfigurationManager.AppSettings["FolderPath"];

        do
        {
            FilePath = Directory.GetParent(FilePath).FullName.ToString();

        } while (!Directory.Exists(FilePath + @"\" + FolderPath));

        FilePath = FilePath + @"\" + FolderPath;

        string strResult = string.Empty;
        strResult = "[{response:'exception occured'}]";
        strResult = CreateXL(jsonString, FilePath, xlsName, jsonHeader);
        //strResult = UpdateExcel(jsonString, FilePath, xlsName);
        return strResult;
    }


    public string UpdateExcelByOleDB(string jsonString, string FilePath, string Extension, string isHDR, string xlsName)
    {

        string conStr = "";
        OleDbConnection connExcel = new OleDbConnection();
        OleDbCommand cmdExcel;
        OleDbDataAdapter oda;
        DataTable dt = new DataTable();
        DataTable dtResult = new DataTable();
        try
        {
            switch (Extension)
            {
                case ".xls": //Excel 97-03
                    conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"]
                             .ConnectionString;
                    break;
                case ".xlsx": //Excel 07
                    conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"]
                              .ConnectionString;
                    break;
            }
            conStr = String.Format(conStr, FilePath, isHDR);
            connExcel = new OleDbConnection(conStr);
            cmdExcel = new OleDbCommand();
            oda = new OleDbDataAdapter();
            dt = new DataTable();
            cmdExcel.Connection = connExcel;

            //Get the name of First Sheet
            connExcel.Open();
            DataTable dtExcelSchema;
            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

            DataTable dtSchema = new DataTable();
            dtSchema = connExcel.GetSchema();

            connExcel.Close();

            //Read Data from First Sheet
            connExcel.Open();
            cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
            oda.SelectCommand = cmdExcel;
            oda.Fill(dt);
            connExcel.Close();
        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (connExcel.State == ConnectionState.Open)
            {
                connExcel.Close();
            }
            connExcel.Dispose();
            cmdExcel = null;
            oda = null;
        }

        //dt = ReadXlsxFile(FilePath + Extension);

        //dt = ImportDataFromExcel(FilePath + Extension);
        dtResult = BindDTWithTableHeader(dt);

        //dtResult = GetXlFormating(FilePath + Extension);
        return DataTableToJSONWithJSONNet(dtResult);
        //Bind Data to GridView

    }

    private Boolean MakeCopyExcel(string SouceFileName, string FilePath, string DestFileName)
    {
        Boolean flg = false;

        try
        {

            string sourceFile = System.IO.Path.Combine(FilePath, SouceFileName);
            string destFile = System.IO.Path.Combine(FilePath, DestFileName);

            System.IO.File.Copy(sourceFile, destFile, true);
            flg = true;
        }
        catch (Exception ex)
        {
            flg = false;
        }

        return flg;
    }

    private string UpdateExcel(string jsonString, string FilePath, string xlsName)
    {
        string strResult = string.Empty;

        try
        {
            MakeCopyExcel("Emp_Data_2003.xls", FilePath, xlsName + ".xls");

            Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbooks xlWorkBooks = xlApp.Workbooks;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook = xlWorkBooks.Open(FilePath + xlsName + ".xls");
            Microsoft.Office.Interop.Excel.Worksheet workSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            Microsoft.Office.Interop.Excel.Range xlRange = null;
            string IsCellBold = string.Empty;
            string BackGround = string.Empty;


            //int ncols = workSheet.UsedRange.Columns.Count;
            //int nrows = workSheet.UsedRange.Rows.Count;

            if (xlApp == null)
            {
                strResult = "[{response:'Excel is not properly installed!!'}]";
            }

            int r = 1;
            int c = 1;

            JObject j = JObject.Parse(jsonString);

            foreach (JToken row in j["data"])
            {
                c = 1;
                foreach (JToken col in row)
                {
                    workSheet.Cells[r, c] = col.ToString();
                    xlRange = workSheet.Range[workSheet.Cells[r, c], workSheet.Cells[r, c]];
                    IsCellBold = Convert.ToString(xlRange.Font.Bold);
                    BackGround = Convert.ToString(xlRange.Font.Background);

                    //string strP = col.ToString();
                    c++;
                }

                r++;
            }

            xlWorkBook.Save();
            xlWorkBook.Close();

            strResult = "[{response:'Excel file created, File Name : " + xlsName + ".xls'}]";
        }
        catch (Exception ex)
        {
            strResult = "[{response:'exception error : " + ex.ToString() + "'}]";
        }
        return strResult;

    }


    private string CreateXL(string jsonString, string FilePath, string xlsName, string jsonHeader)
    {
        Log.ErrorLog(_strLogPath, "CreateXL Start");
        Log.ErrorLog(_strLogPath, "jsonString : " + jsonString);
        DataTable dtXL = new DataTable();


        string strResult = string.Empty;

        int r = 1;
        int c = 1;

        Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
        Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
        Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
        object misValue = System.Reflection.Missing.Value;

        try
        {

            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            if (xlApp == null)
            {
                strResult = "[{response:'Excel is not properly installed!!'}]";
            }

            //Bind Header
            JObject jHead = JObject.Parse(jsonHeader);
            foreach (JToken row in jHead["data"])
            {
                xlWorkSheet.Cells[r, c] = "'" + jHead["data"][c - 1].ToString();
                dtXL.Columns.Add(jHead["data"][c - 1].ToString());
                c++;
            }

            //xlWorkBook.SaveAs(FilePath + xlsName + ".xlsx", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.SaveAs(FilePath + xlsName + ".xlsx", Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, misValue, misValue, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlUserResolution, true, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

            //

            r = 2;

            JObject j = JObject.Parse(jsonString);
            //int LastColNo = 0;
            foreach (JToken row in j["data"])
            {
                c = 0;
                DataRow dr;
                dr = null;
                dr = dtXL.NewRow();

                foreach (JToken col in row)
                {
                    //Restrict to read blank data from Jagged Array,
                    //if (r == 1)
                    //{
                    //    if (col.ToString().ToLower().Contains("noname") || col.ToString().Trim() == "")
                    //    {
                    //        LastColNo = c;
                    //        break;
                    //    }
                    //}

                    //if ((LastColNo == 0) || (c < LastColNo))
                    //{
                    //xlWorkSheet.Cells[r, c] = "'" + col.ToString();
                    dr[c] = col.ToString();
                    //string strP = col.ToString();
                    c++;
                    //}
                }
                dtXL.Rows.Add(dr);
                r++;
            }

            string strResponse = InsertDataXL(FilePath + xlsName + ".xlsx", dtXL);

            if (strResponse.Split('~')[0] == "true")
                strResult = "[{response:'Excel file created, File Name : " + xlsName + ".xlsx " + strResponse.Split('~')[1] + "'}]";
            else
                strResult = "[{response:'" + strResponse.Split('~')[1] + "'}]";

        }
        catch (Exception ex)
        {
            strResult = "[{response:'exception error : " + ex.ToString() + "'}]";
            Log.ErrorLog(_strLogPath, "CreateXL == > Ex ==>" + ex.ToString());
        }
        finally
        {
            xlApp = null;
            xlWorkBook = null;
            xlWorkSheet = null;
            misValue = null;
            Log.ErrorLog(_strLogPath, "CreateXL End");
        }
        return strResult;


    }

    public string InsertDataXL(string FilePath, DataTable dtXL)
    {
        string strResponse = string.Empty;
        strResponse = "";
        Log.ErrorLog(_strLogPath, "Function Start : InsertDataXL");
        string conStr = "";
        string sql = "";
        StringBuilder sb = new StringBuilder();
        StringBuilder sbHead = new StringBuilder();
        StringBuilder sbRow = new StringBuilder();

        OleDbConnection connExcel = new OleDbConnection();
        OleDbCommand cmdExcel;

        DataTable dt = new DataTable();
        DataTable dtResult = new DataTable();
        conStr = ConfigurationManager.ConnectionStrings["SaveExcel07ConString"]
                             .ConnectionString;

        try
        {
            conStr = String.Format(conStr, FilePath, "Yes");
            connExcel = new OleDbConnection(conStr);
            cmdExcel = new OleDbCommand();

            dt = new DataTable();
            cmdExcel.Connection = connExcel;

            //Get the name of First Sheet
            connExcel.Open();


            DataTable dtExcelSchema;
            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

            DataTable dtSchema = new DataTable();
            dtSchema = connExcel.GetSchema();

            connExcel.Close();

            connExcel.Open();


            //            int pageCount = 0;
            //            int pageSize = 100;
            //            int rowsCount = dtXL.Rows.Count;

            //            if ((rowsCount % pageSize) > 0)
            //                pageCount = (rowsCount / pageSize) + 1;
            //            else
            //                pageCount = (rowsCount / pageSize);

            //            for (int p = 1; p <= pageCount; p++)
            //            {

            //                sql = GetXLInsertQuery(SheetName, dtXL, pageSize, p);

            //                if (!string.IsNullOrEmpty(sql))
            //                {
            //                    cmdExcel = new OleDbCommand(@"" + sql, connExcel);
            ////                    cmdExcel.CommandText = @"" + sql;
            //                    cmdExcel.ExecuteNonQuery();
            //                    //connExcel.Close();
            //                }
            //            }


            for (int c = 0; c < dtXL.Columns.Count; c++)
            {
                sbHead.Append("[" + dtXL.Columns[c].ColumnName + "],");
            }

            //sbHead.ToString().TrimEnd(',');

            for (int r = 0; r < dtXL.Rows.Count; r++)
            {

                sb = new StringBuilder();
                sbRow = new StringBuilder();

                for (int c = 0; c < dtXL.Columns.Count; c++)
                {
                    sbRow.Append("'" + Convert.ToString(dtXL.Rows[r][c]) + "',");
                }

                sb.Append("Insert into [" + SheetName + "] (" + sbHead.ToString().TrimEnd(',') + ") values(" + sbRow.ToString().TrimEnd(',') + "); ");

                if (!string.IsNullOrEmpty(sb.ToString()))
                {
                    try
                    {
                        cmdExcel = new OleDbCommand(@"" + sb.ToString(), connExcel);
                        //cmdExcel.CommandText = @"" + sql;
                        cmdExcel.ExecuteNonQuery();
                        //connExcel.Close();
                    }
                    catch (Exception ex)
                    {
                        strResponse = "false~Operation does not completed";
                        Log.ErrorLog(_strLogPath, "ERROR => Function => InsertDataXL =>" + " Insert Query : " + sb.ToString() + "\n Ex :" + ex.ToString());
                    }
                }
            }

            if (string.IsNullOrEmpty(strResponse))
                strResponse = "true~";

        }
        catch (Exception ex)
        {
            strResponse = "false~Operation does not completed";
            Log.ErrorLog(_strLogPath, "ERROR => Function => InsertDataXL => Exception => " + ex.ToString());
        }
        finally
        {
            if (connExcel.State == ConnectionState.Open)
            {
                connExcel.Close();
            }
            connExcel.Dispose();
            cmdExcel = null;

            Log.ErrorLog(_strLogPath, "Function End : InsertDataXL");
        }

        if (string.IsNullOrEmpty(strResponse))
            strResponse = "false~Operation does not completed";

        return strResponse;


    }

    private string GetXLInsertQuery(string SheetName, DataTable dt, int PageSize, int PageNo)
    {
        StringBuilder sb = new StringBuilder();
        StringBuilder sbHead = new StringBuilder();
        StringBuilder sbRow = new StringBuilder();
        int rowfrom = 0;
        int rowto = 0;
        int totRec = dt.Rows.Count;

        rowfrom = (PageSize * (PageNo - 1));
        rowto = ((PageSize * PageNo) > totRec ? totRec : (PageSize * PageNo));

        try
        {
            for (int c = 0; c < dt.Columns.Count; c++)
            {
                sbHead.Append("[" + dt.Columns[c].ColumnName + "],");
            }

            //sbHead.ToString().TrimEnd(',');

            for (int r = rowfrom; r < rowto; r++)
            {
                sbRow = new StringBuilder();

                for (int c = 0; c < dt.Columns.Count; c++)
                {
                    sbRow.Append("'" + Convert.ToString(dt.Rows[r][c]) + "',");
                }

                sb.Append("Insert into [" + SheetName + "] (" + sbHead.ToString().TrimEnd(',') + ") values(" + sbRow.ToString().TrimEnd(',') + ") ; ");
            }
        }
        catch (Exception ex)
        {

        }


        return sb.ToString().TrimEnd(';');
    }

}

