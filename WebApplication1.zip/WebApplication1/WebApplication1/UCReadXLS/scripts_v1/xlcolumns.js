

function getXLColArray(size)
{
    var ArrCol = [];

    var str = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
    var res = str.split(",");
    var res2 = str.split(",");
    var len = res.length;
    //alert(len);
    var ArrCol = [];
    var strRes;
    strRes = "";

    size = size - 1;

    for (var i = 0; i < len ; i++) {
        if (i > size)
            break;

        strRes = strRes + res[i] + ",";
        ArrCol.push(res[i]);
    }

    var p;
    p = 0;

    if (size > 26) {
        size = size - 26;

        for (var c = 0; c < len ; c++) {
            if (p > size)
                break;

            for (var r = 0; r < len ; r++) {
                if (p > size)
                    break;

                strRes = strRes + res[c] + res2[r] + ",";
                ArrCol.push(res[c] + res2[r]);
                p++;
            }
        }
    }

    //alert(strRes);

    return ArrCol;
}