﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication1
{
    public partial class UcReadExcel : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static string getxldata(string sheet, string xlsName)
        {
            string strResult = string.Empty;
            xlsReadWrite objread = new xlsReadWrite(System.Web.HttpContext.Current.Server.MapPath("Logs/ErrorLog"));
            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];
            string FilePath = System.Web.HttpContext.Current.Server.MapPath(FolderPath + xlsName);
            string[] ArrFileName = xlsName.Split('.');

            strResult = objread.Import_To_Grid(FilePath, "." + ArrFileName[1].ToLower().ToString(), "Yes");
            return strResult;
        }

        [WebMethod]
        public static string savexldata(string xlsData, string xlsHeader)
        {

            string strResult = string.Empty;
            string xlsName = string.Empty;
            strResult = "[{response:'exception occured'}]";
            xlsName = "xls_Demo_" + DateTime.Now.ToString("ddMMyyyyhhmmss");
            DataTable dt = new DataTable();
            xlsReadWrite objwrite = new xlsReadWrite(System.Web.HttpContext.Current.Server.MapPath("Logs/ErrorLog"));
            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];
            string FilePath = System.Web.HttpContext.Current.Server.MapPath(FolderPath);
            strResult = objwrite.UpdateXLS(xlsData, FilePath, xlsName, xlsHeader);
            return strResult;
        }
    }
}