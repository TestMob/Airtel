﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using WebApplication1.CFSTest;
using System.Text.RegularExpressions;

namespace WebApplication1
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        CFSTest.ServiceClient p = new ServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            WCFProperty a = new WCFProperty();

            //////string str = "?asdasf";
            //////bool errorCounter = Regex.IsMatch(str, @"^[a-zA-Z0-9,.\~]*$");

            ////DataTable dt = new DataTable("hhh");

            ////string v = Guid.NewGuid().ToString().Substring(0, 8).Replace('-', 'H');
            ////dt.Columns.Add("DealerAccountNo");
            ////dt.Columns.Add("TokenNo");

            ////dt.Rows.Add("010205000208", v);//010205004966, 010205000004 

            ////a.json = ConvertToJson(dt);
            ////////a.json = null;

            ////string output = p.DealerOutstandingReport(a);

            //////DataTable dt1 = p.JsonToTable(output);
            //////DataSet ds = JsonToDataset(output);

            ////Response.Write(output);

            //-------------------------------------------------------------------------//

            DataSet ds = new DataSet();

            string v = Guid.NewGuid().ToString().Substring(0, 8).Replace('-', 'H');

            ds.Tables.Add("TokenNo");

            ds.Tables[0].Columns.Add("TokenNo");
            ds.Tables[0].Rows.Add(v);

            DataTable dt = this.createTable();

            ds.Tables.Add(dt);

            a.json = ConvertToJson(ds);
            //a.json = "";
            //a.json = p.DataSetToJson(ds);


            string output = p.CreateDealer(a);

            DataTable dt1 = new DataTable();
            DataSet ds1 = new DataSet();

            //dt1 = JsonToTable(output);
            //ds1 = JsonToDataset(output);

            Response.Write(output);
        }

        public string ConvertToJson(DataTable dt)
        {
            string JSONString = string.Empty;

            JSONString = JsonConvert.SerializeObject(dt);

            return JSONString;
        }

        public string ConvertToJson(DataSet ds)
        {
            string JSONString = string.Empty;

            JSONString = JsonConvert.SerializeObject(ds);

            return JSONString;
        }

        public DataTable JsonToTable(string json)
        {
            DataTable dt = new DataTable();

            dt = JsonConvert.DeserializeObject<DataTable>(json);

            return dt;
        }

        public DataSet JsonToDataset(string json)
        {
            DataSet ds = new DataSet();

            ds = JsonConvert.DeserializeObject<DataSet>(json);

            return ds;
        }

        public DataTable createTable()
        {
            ArrayList al = new ArrayList();
            al.Add("DealerName");
            al.Add("AccountNo");
            al.Add("CustomerId");
            al.Add("DealerLimit");
            al.Add("DealerSanctionDate");
            al.Add("DealerExpiryDate");
            al.Add("DealerRenewalDate");
            al.Add("LimitIdPrefix");
            al.Add("LimitIdSuffix");
            al.Add("ParentLimitIdPrefix");
            al.Add("ParentLimitIdSuffix");
            al.Add("Address1");
            al.Add("Address2");
            al.Add("City");
            al.Add("State");
            al.Add("Pin");
            al.Add("PhoneNo");
            al.Add("EmailId");
            al.Add("AccountOpenDate");
            al.Add("AccountCloseDate");
            al.Add("AccountStatus");
            al.Add("ProgramLimit");
            al.Add("ProgramSanctionDate");
            al.Add("ProgramExpiryDate");
            al.Add("ProgramRenewalDate");
            al.Add("DocumentationDate");
            al.Add("Doc1");
            al.Add("Doc2");
            al.Add("Doc3");
            al.Add("Doc4");
            al.Add("Doc5");
            al.Add("Doc6");
            al.Add("Doc7");
            al.Add("Doc8");
            al.Add("Doc9");
            al.Add("Doc10");
            al.Add("DealerShortName");
            al.Add("SolID");
            al.Add("DealerCorporateName");
            al.Add("SMAccountManagerEmailID");
            al.Add("NameOfSM");
            al.Add("NameOfCRM");
            al.Add("CreditTenorForTheProgram");
            al.Add("CategoryName");
            al.Add("RateCode");
            al.Add("FixedRateCode");
            al.Add("CureRateCode");
            al.Add("PenalRateCode");
            al.Add("MinimumCode");
            al.Add("MaximumCode");
            al.Add("ContactPerson");
            al.Add("ModeOfFunding");
            al.Add("AssetClassification");
            al.Add("CreatedThroughChannel");

            DataTable dtTable = new DataTable("Dealer");

            foreach (var item in al)
            {
                dtTable.Columns.Add(item.ToString());
            }
            string[] data1 = 
                {
                    //"SK PLYWOODS PLYWOODS PLYWOODSPLYWOODSPLYWOODSPLYWOODSPLYWOODSPLYWOODSPLYWOODSPLYWOODSPLYWOODS PLYWOODSPLYWOODS|110205005913|527394013|12000000|06-01-2012|05-31-2013|03-30-2013|xYY|OD|xDS|PL|606,R.R LODGE BUILDING SATHY ROAD|ERODE|ERODE|TAMIL NADU|638005|0424-2252124/919843017877|RASAPLYWOODS@GMAIL.COM|02-28-2012||N|100000000|03-30-2012|03-29-2013|||||||||||||CENT|0102|",
                 
                 //"sadasd ROTATING SYSTEMS PVT LTD|010205005991|528099859|20000000|05-21-2012|05-16-2013|03-15-2013|ABB-ELE ROAT|OD|ABB-DEALERS|PL|249, MOUNT ROAD||CHENNAI|TAMIL NADU|600006|044 24321402/919381038785|ERSCHENNAI@YAHOO.CO.IN|05-19-2012||N|250000000|10-31-2011|10-30-2012|||||||||||||ABB|0102|"

                 "Temp Dealer|020205145505|527759129|1000|03-21-2012|03-20-2013|01-19-2013|DLR-AAP|OD|CORP-AAA|PL|255 LOHA MANDI GZB||GHAZIABAD|UTTAR PRADESH|201001|01203253560/919818243001||04-12-2012||N|300000000|10-11-2011|10-10-2012|||||||||||||BSSL-DEkk|0102||sm@tesgmail.comssssss|sss|CRM Name|50||Fixed Rate||||AML5|ACCL78|Sandhya Parab|Infinity|Vendor Overdraft Program|Arteria"
                 //"MAHA LAXMI STEELS ABCD123|222222222222|527759129|5000000|03-21-2012|03-20-2013|01-19-2013|SSS|OD|SSS|PL|255 LOHA MANDI GZB||GHAZIABAD|UTTAR PRADESH|201001|01203253560/919818243001||04-12-2012||N|300000000|10-11-2011|10-10-2012|||||||||||||BSSL-DEALEkk|0102|"
                };

            int ctr = 0;


            foreach (var dataRow in data1)
            {
                dtTable.Rows.Add();
                foreach (var item in dataRow.Split('|'))
                {
                    dtTable.Rows[dtTable.Rows.Count - 1][al[ctr].ToString()] = item.ToString();
                    ctr++;
                }
                ctr = 0;
            }

            ctr = 0;

            return dtTable;

            //string result = JsonConvert.SerializeObject(DatatableToDictionary(queryResult, "Title"), Newtonsoft.Json.Formatting.Indented);
        }
    }
}