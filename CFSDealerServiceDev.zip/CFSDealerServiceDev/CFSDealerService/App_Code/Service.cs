﻿using System;
using System.IO;
using System.Configuration;
using System.Collections;
using System.Xml.Linq;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Web;
using System.Text;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using ICICIInfotechLtd.Ibank.CFS.DAL;
using ICICIInfotechLtd.Ibank.CFS.Entity;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Single)]
public class Service : IService
{
    private string ConvertToJson(DataTable dt)
    {
        string JSONString = string.Empty;

        JSONString = JsonConvert.SerializeObject(dt);

        return JSONString;
    }

    private string ConvertToJson(DataSet ds)
    {
        string JSONString = string.Empty;

        JSONString = JsonConvert.SerializeObject(ds);

        return JSONString;
    }

    private DataTable JsonToTable(string json)
    {
        DataTable dt = new DataTable();

        dt = JsonConvert.DeserializeObject<DataTable>(json);

        return dt;
    }

    private DataSet JsonToDataset(string json)
    {
        DataSet ds = new DataSet();

        ds = JsonConvert.DeserializeObject<DataSet>(json);

        return ds;
    }

    private string SendMessage(WCFProperty prop, string tokenNo = "")
    {
        string output = string.Empty;

        DataTable dt;
        DataSet ds;

        if (!String.IsNullOrEmpty(tokenNo))
        {
            ds = new DataSet();

            ds.Tables.Add("TokenNo");
            ds.Tables.Add("Message");

            ds.Tables["TokenNo"].Columns.Add("TokenNo");
            ds.Tables["TokenNo"].Rows.Add(tokenNo);

            ds.Tables["Message"].Columns.Add("ResponseCode");
            ds.Tables["Message"].Columns.Add("Message");

            ds.Tables["Message"].Rows.Add(prop.resCode, prop.message);

            output = JsonConvert.SerializeObject(ds);
        }
        else
        {
            dt = new DataTable();

            dt.Columns.Add("ResponseCode");
            dt.Columns.Add("Message");

            dt.Rows.Add(prop.resCode, prop.message);

            output = JsonConvert.SerializeObject(dt);
        }

        this.CreateRequestLog("Requested On : " + prop.requestedOn + " Input : " + prop.json, "Responded On : " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF") + " Output : " + output, tokenNo);

        ExceptionHandler.Instance.Trace("Error: " + prop.message + " at " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF"));
        ExceptionHandler.Instance.Trace("--------------------------------------------------------------------------------------------------");

        dt = null;
        ds = null;

        return output;
    }

    private string GetRateCode(string rateCodeName)
    {
        string rateCode = string.Empty;

        switch (rateCodeName)
        {
            case "IBAR":
                rateCode = "1";
                break;

            case "PLR":
                rateCode = "2";
                break;

            case "Fixed Rate":
                rateCode = "3";
                break;
        }

        return rateCode;
    }

    private string GetModeOfFunding(string fundingName)
    {
        string mode = string.Empty;

        switch (fundingName.Trim().ToUpper())
        {
            case "INFINITY":
                mode = "I";
                break;

            case "MANUAL":
                mode = "M";
                break;

            case "CHEQUE":
                mode = "C";
                break;
        }

        return mode;
    }

    private string GetClassification(string programName)
    {
        string mode = string.Empty;

        switch (programName.Trim().ToUpper())
        {
            case "VENDOR OVERDRAFT PROGRAM":
                mode = "V";
                break;

            case "DEALER OVERDRAFT PROGRAM":
                mode = "D";
                break;
        }

        return mode;
    }

    private bool IsValidIP()
    {
        bool retVal = false;

        System.Xml.XmlTextReader _xmlReader = null;
        System.Xml.XmlDocument xml = null;
        System.Xml.XmlNodeList nodeList;

        int counter;
        string strDFSRoot;

        try
        {
            OperationContext context = OperationContext.Current;
            MessageProperties properties = context.IncomingMessageProperties;
            RemoteEndpointMessageProperty endpoint = properties[RemoteEndpointMessageProperty.Name] as RemoteEndpointMessageProperty;

            string ip = endpoint.Address + ":" + endpoint.Port;

            ExceptionHandler.Instance.Trace("IP : " + ip + " requested on " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF"));

            do
            {
                //strDFSRoot = Directory.GetParent(strDFSRoot).FullName.ToString();
                strDFSRoot = System.AppDomain.CurrentDomain.BaseDirectory;

            } while (!System.IO.File.Exists(strDFSRoot + @"\IPAddress.xml"));

            _xmlReader = new System.Xml.XmlTextReader(strDFSRoot + @"\IPAddress.xml");

            xml = new System.Xml.XmlDocument();

            xml.Load(_xmlReader);

            nodeList = xml.SelectNodes("IPList/ip");

            for (counter = 0; counter < nodeList.Count; counter++)
            {
                if (endpoint.Address == nodeList[counter].InnerText)
                {
                    retVal = true;
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionHandler.Instance.ExtractExceptionInfo(ex, "");//add user token
        }
        finally
        {
            _xmlReader.Close();
            xml.DocumentElement.ParentNode.RemoveAll();

            nodeList = null;
        }

        return retVal;
    }

    private string CreateRequestLog(string input, string output, string tokenNo, string requestChannel = "")
    {
        RequestLog logEntity;

        DALRequestLog objRequest;

        OperationContext context = OperationContext.Current;
        MessageProperties properties = context.IncomingMessageProperties;
        RemoteEndpointMessageProperty endpoint = properties[RemoteEndpointMessageProperty.Name] as RemoteEndpointMessageProperty;

        string ip = endpoint.Address + ":" + endpoint.Port;

        logEntity = new RequestLog();
        logEntity.TokenNo = String.IsNullOrEmpty(tokenNo) ? "" : tokenNo;
        logEntity.RequestData = String.IsNullOrEmpty(input) ? "" : input;
        logEntity.ResponseData = String.IsNullOrEmpty(output) ? "" : output;
        logEntity.IPAddress = ip;
        logEntity.RequestChannel = String.IsNullOrEmpty(requestChannel) ? "" : requestChannel;

        objRequest = new DALRequestLog();

        objRequest.AddRequestLog(logEntity);

        objRequest = null;

        return logEntity.Message;
    }

    private bool IsValidToken(string tokenNo, out string msg, out string resCode)
    {
        bool retVal = true;
        msg = "";
        resCode = "302";

        if (String.IsNullOrEmpty(tokenNo.Trim()))
        {
            msg = "Token No is empty";
            resCode = "300";

            retVal = false;
        }
        else if (tokenNo.Trim().Contains(" "))
        {
            msg = "Token No should not contain space";

            retVal = false;
        }
        else if (!Regex.IsMatch(tokenNo.Trim(), @"^[a-zA-Z0-9]*$"))
        {
            msg = "Token No should be alphanumeric";

            retVal = false;
        }
        else if (tokenNo.Trim().Length < 6 || tokenNo.Trim().Length > 12)
        {
            msg = "Token No length should be 6 - 12 characters";

            retVal = false;
        }
        else if (IsValidTokenNo(tokenNo.Trim()) == "N")
        {
            msg = "Request already exists for this Token No '" + tokenNo.Trim() + "'";

            retVal = false;
        }

        return retVal;
    }

    private string IsValidAccount(string accountNo)
    {
        Dealer entity;
        DALDealer objDealer;

        entity = new Dealer();
        entity.Account_No = accountNo;

        objDealer = new DALDealer();

        objDealer.IsValidAccountNo(entity);

        objDealer = null;

        return entity.Message;
    }

    private string IsValidTokenNo(string tokenNo)
    {
        string retVal;

        RequestLog entity;
        DALRequestLog objRequestLog;

        entity = new RequestLog();
        entity.TokenNo = tokenNo;

        objRequestLog = new DALRequestLog();

        objRequestLog.IsValidTokenNo(entity);

        retVal = entity.Message;

        objRequestLog = null;
        entity = null;

        return retVal;
    }

    private string CheckDealerRateCode(DataTable source, out string resCode)
    {
        int rowCount;

        string retMsg = string.Empty;

        DataSet ds;

        resCode = "302";

        Dealer entityDealer;
        DALDealer objDealer;

        entityDealer = new Dealer();
        objDealer = new DALDealer();

        for (rowCount = 0; rowCount < 1; rowCount++)//source.Rows.Count
        {
            entityDealer.Category_Code = Convert.ToString(source.Rows[rowCount]["CategoryName"]);
            entityDealer.Fixed_Rate_Code = Convert.ToString(source.Rows[rowCount]["FixedRateCode"]);
            entityDealer.Cure_Code = Convert.ToString(source.Rows[rowCount]["CureRateCode"]);
            entityDealer.Penal_Code = Convert.ToString(source.Rows[rowCount]["PenalRateCode"]);
            entityDealer.Minimum_Code = Convert.ToString(source.Rows[rowCount]["MinimumCode"]);
            entityDealer.Maximum_Code = Convert.ToString(source.Rows[rowCount]["MaximumCode"]);
        }

        ds = objDealer.getValidDealerRateCode(entityDealer);

        if (ds != null)
        {
            if (Convert.ToString(ds.Tables[0].Rows[0]["VALUE"]) == "E")
            {
                retMsg = Convert.ToString(ds.Tables[0].Rows[0]["RetMessage"]);
            }
        }

        objDealer = null;
        entityDealer = null;

        ds = null;

        return retMsg;
    }

    private string IsInvalidColumns(DataTable source, out string resCode)
    {
        //flag is set against column name in array. If flag = 0 then mandatory else non-mandatory.
        int counter;

        string retMsg = string.Empty;
        string[,] columns;
        decimal val;

        resCode = "300";

        columns = new string[,] { {"DealerName", "0"},{"AccountNo", "0"}, {"CustomerId", "0"},{ "DealerLimit", "0"}, {"DealerSanctionDate", "0"},{ "DealerExpiryDate", "0"},
        {"DealerRenewalDate", "0"},{"LimitIdPrefix", "0"},{"LimitIdSuffix", "0"},{"ParentLimitIdPrefix", "0"},{"ParentLimitIdSuffix", "0"},{"Address1", "1"},{"Address2", "1"},
        {"City", "1"},{"State", "1"},{"Pin", "1"},{"PhoneNo", "1"},{"EmailId", "1"},{"AccountOpenDate", "0"},
        {"AccountCloseDate", "1"},{"AccountStatus", "0"},{ "ProgramLimit", "0"},{"ProgramSanctionDate", "0"},{"ProgramExpiryDate", "0"},{"ProgramRenewalDate", "1"},{"DocumentationDate", "1"}, {"Doc1", "1"},{"Doc2", "1"},
        {"Doc3", "1"},{"Doc4", "1"},{"Doc5", "1"},{"Doc6", "1"},{"Doc7", "1"},{"Doc8", "1"},{"Doc9", "1"},{"Doc10", "1"},{"DealerShortName", "0"},{"SolID", "0"},{"DealerCorporateName" , "1"},
        {"SMAccountManagerEmailID", "1"}, {"NameOfSM", "0"},{"NameOfCRM", "0"},{"CreditTenorForTheProgram", "0"}, {"CategoryName", "1"}, {"RateCode", "0"}, {"FixedRateCode", "1"},
        {"CureRateCode", "1"}, {"PenalRateCode", "1"}, {"MinimumCode", "0"}, {"MaximumCode", "0"},{"ContactPerson", "1"},
        {"ModeOfFunding", "0"}, {"AssetClassification", "0"}, {"CreatedThroughChannel", "0"}};

        for (counter = 0; counter < (columns.Length / 2); counter++)
        {
            if (columns[counter, 1] == "0")
            {
                if (String.IsNullOrEmpty(Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim()))//|| source.Rows[0][columns[counter, 0]] == "" || Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length <= 0
                {
                    retMsg = "Column '" + columns[counter, 0] + "' is empty.";

                    break;
                }

                if (columns[counter, 0] == "AccountNo" || columns[counter, 0] == "CustomerId" || columns[counter, 0] == "DealerLimit" || columns[counter, 0] == "SolID")
                {
                    if (Regex.Matches(Convert.ToString(source.Rows[0][columns[counter, 0]]), @"[a-zA-Z ]").Count > 0)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should contain numeric value.";
                        resCode = "302";

                        break;
                    }
                    else if (decimal.TryParse(Convert.ToString(source.Rows[0][columns[counter, 0]]), out val) == false)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should contain numeric value.";
                        resCode = "302";

                        break;
                    }
                    else if (Convert.ToDecimal(source.Rows[0][columns[counter, 0]]) <= 0)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should contain valid value.";
                        resCode = "302";

                        break;
                    }
                }
                else if (columns[counter, 0] == "DealerName" || columns[counter, 0] == "DealerShortName" || columns[counter, 0] == "LimitIdPrefix"
                    || columns[counter, 0] == "LimitIdSuffix" || columns[counter, 0] == "ParentLimitIdPrefix" || columns[counter, 0] == "ParentLimitIdSuffix")
                {
                    if (Regex.Matches(Convert.ToString(source.Rows[0][columns[counter, 0]]), @"[a-zA-Z]").Count == 0)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' contains invalid value.";
                        resCode = "302";

                        break;
                    }
                }
                else if (columns[counter, 0] == "NameOfSM" || columns[counter, 0] == "NameOfCRM")
                {
                    if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 50)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                        resCode = "302";

                        break;
                    }

                    if (!IsAlphabetsOnly(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should contain alphabets only";
                        resCode = "302";

                        break;
                    }

                    if (CheckForSplChar(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should not contain special characters";
                        resCode = "302";

                        break;
                    }
                }
                else if (columns[counter, 0] == "CreditTenorForTheProgram")
                {
                    if (decimal.TryParse(Convert.ToString(source.Rows[0][columns[counter, 0]]), out val) == false)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should contain numeric value.";
                        resCode = "302";

                        break;
                    }

                    if (Convert.ToDecimal(source.Rows[0][columns[counter, 0]]) <= 0)
                    {
                        retMsg = "Credit Tenor should be greater than 0.";
                        resCode = "302";

                        break;
                    }

                    if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 3)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                        resCode = "302";

                        break;
                    }

                    if (CheckForSplChar(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should not contain special characters";
                        resCode = "302";

                        break;
                    }
                }
                else if (columns[counter, 0] == "RateCode" || columns[counter, 0] == "MinimumCode" || columns[counter, 0] == "MaximumCode"
                    || columns[counter, 0] == "ModeOfFunding" || columns[counter, 0] == "AssetClassification" || columns[counter, 0] == "CreatedThroughChannel")
                {
                    if (columns[counter, 0] == "CreatedThroughChannel" || columns[counter, 0] == "AssetClassification")
                    {
                        if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 30)
                        {
                            retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                            resCode = "302";

                            break;
                        }
                    }
                    else
                    {
                        if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 10)
                        {
                            retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                            resCode = "302";

                            break;
                        }
                    }

                    if (CheckForSplChar(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should not contain special characters";
                        resCode = "302";

                        break;
                    }

                    if (columns[counter, 0] == "CreatedThroughChannel")
                    {
                        if (!IsAlphabetsOnly(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                        {
                            retMsg = "Column '" + columns[counter, 0] + "' should contain alphabets only";
                            resCode = "302";

                            break;
                        }
                    }

                    if (columns[counter, 0] == "RateCode" && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "IBAR"
                        && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "PLR"
                        && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "FIXED RATE")
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' contains invalid value";
                        resCode = "302";

                        break;
                    }

                    if (columns[counter, 0] == "ModeOfFunding" && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "INFINITY"
                        && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "MANUAL"
                        && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "CHEQUE")
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' contains invalid value";
                        resCode = "302";

                        break;
                    }

                    if (columns[counter, 0] == "AssetClassification" && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "VENDOR OVERDRAFT PROGRAM"
                        && Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().ToUpper() != "DEALER OVERDRAFT PROGRAM")
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' contains invalid value";
                        resCode = "302";

                        break;
                    }
                }
            }
            else
            {
                if (!String.IsNullOrEmpty(Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim()) &&
                    (columns[counter, 0] == "SMAccountManagerEmailID" || columns[counter, 0] == "ContactPerson"))
                {
                    if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 50)
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                        resCode = "302";

                        break;
                    }

                    if (columns[counter, 0] == "SMAccountManagerEmailID")
                    {
                        if (CheckForValidEmail(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                        {
                            retMsg = "SM / Account Manager Email ID is invalid";
                            resCode = "302";

                            break;
                        }
                    }

                    if (columns[counter, 0] == "ContactPerson")
                    {
                        if (!IsAlphabetsOnly(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                        {
                            retMsg = "Contact Person field should contain alphabets only";
                            resCode = "302";

                            break;
                        }

                        if (CheckForSplChar(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                        {
                            retMsg = "Contact Person field should not contain special characters";
                            resCode = "302";

                            break;
                        }
                    }
                }
                else if (columns[counter, 0] == "CategoryName" || columns[counter, 0] == "FixedRateCode" ||
                        columns[counter, 0] == "CureRateCode" || columns[counter, 0] == "PenalRateCode")
                {
                    if (columns[counter, 0] == "CategoryName")
                    {
                        if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 30)
                        {
                            retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                            resCode = "302";

                            break;
                        }
                    }
                    else
                    {
                        if (Convert.ToString(source.Rows[0][columns[counter, 0]]).Trim().Length > 10)
                        {
                            retMsg = "Column '" + columns[counter, 0] + "' exceed the max length.";
                            resCode = "302";

                            break;
                        }
                    }

                    if (CheckForSplChar(Convert.ToString(source.Rows[0][columns[counter, 0]])))
                    {
                        retMsg = "Column '" + columns[counter, 0] + "' should not contain special characters";
                        resCode = "302";

                        break;
                    } 
                }
            }
        }

        return retMsg;
    }

    private bool CheckForSplChar(string strtoCheck)  //characters allowed : &*()-+='/
    {
        Regex objAlphaNumeric = new Regex("[^a-z0-9A-Z/\\&-.\\s]");
        return objAlphaNumeric.IsMatch(strtoCheck);
    }

    private bool CheckForValidEmail(string strtoCheck)
    {
        string patternStrict = @"^(([^<>()[\]\\.,;:\s@\""]+"
            + @"(\.[^<>()[\]\\.,;:\s@\""]+)*)|(\"".+\""))@"
            + @"((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
            + @"\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+"
            + @"[a-zA-Z]{2,}))$";

        Regex objAlphaNumeric = new Regex(patternStrict);
        return !objAlphaNumeric.IsMatch(strtoCheck);
    }

    private bool IsAlphabetsOnly(string strtoCheck)
    {
        System.Text.RegularExpressions.Regex objPattern = new System.Text.RegularExpressions.Regex("^[a-zA-Z ]+$");
        return objPattern.IsMatch(strtoCheck);
    }

    public string DealerOutstandingReport(WCFProperty prop)
    {
        string output;
        string msg;
        string resCode;
        string tokenNo = null;

        Dealer entity;
        DALDealer objDealer;

        DataTable dt;
        DataSet ds = new DataSet();

        prop.resCode = "301";

        try
        {
            if (!IsValidIP()) { prop.resCode = "100"; prop.message = "Access Denied!!!"; return SendMessage(prop); }

            prop.requestedOn = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF");
            ExceptionHandler.Instance.Trace("Report Start: " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF"));

            if (String.IsNullOrEmpty(prop.json))
            {
                prop.resCode = "300";
                prop.message = "Empty Input";

                return SendMessage(prop);
            }

            ExceptionHandler.Instance.Trace("INPUT-> Report: " + prop.json);

            dt = JsonToTable(prop.json);

            if (dt == null) { prop.resCode = "300"; prop.message = "Empty Input"; return SendMessage(prop); }
            if (dt.Rows.Count == 0) { prop.resCode = "300"; prop.message = "Empty Input"; return SendMessage(prop); }
            if (String.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["TokenNo"]).Trim())) { prop.resCode = "300"; prop.message = "Token No is empty"; return SendMessage(prop); }
            if (String.IsNullOrEmpty(Convert.ToString(dt.Rows[0]["DealerAccountNo"]).Trim())) { prop.resCode = "300"; prop.message = "Dealer Account No is empty"; return SendMessage(prop); }

            tokenNo = Convert.ToString(dt.Rows[0]["TokenNo"]);

            ExceptionHandler.Instance.Trace("Token No: " + tokenNo);

            if (!IsValidToken(tokenNo, out msg, out resCode)) { prop.resCode = resCode; prop.message = msg; return SendMessage(prop); }

            entity = new Dealer();
            entity.Account_No = Convert.ToString(dt.Rows[0]["DealerAccountNo"]);

            ExceptionHandler.Instance.Trace("Account No: " + entity.Account_No);

            if (IsValidAccount(Convert.ToString(dt.Rows[0]["DealerAccountNo"])) == "N") { prop.resCode = "303"; prop.message = "Dealer Account does not exist!!!"; return SendMessage(prop, tokenNo); }

            objDealer = new DALDealer();

            ds = objDealer.getDealerwiseOutstanding(entity);

            if (ds == null) { prop.resCode = "304"; prop.message = "No records found!!!"; return SendMessage(prop, tokenNo); }
            if (ds.Tables.Count == 0) { prop.resCode = "304"; prop.message = "No records found!!!"; return SendMessage(prop, tokenNo); }
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count == 0 && ds.Tables[1].Rows.Count == 0) { prop.resCode = "304"; prop.message = "No records found!!!"; return SendMessage(prop, tokenNo); }

            ds.Tables[0].Columns.Remove("DM_Dealer_Id");

            ds.Tables[0].TableName = "Header";
            ds.Tables[1].TableName = "Detail";

            for (int i = 0; i < ds.Tables.Count; i++)
            {
                for (int j = 0; j < ds.Tables[i].Columns.Count; j++)
                {
                    ds.Tables[i].Columns[j].ColumnName = ds.Tables[i].Columns[j].ColumnName.Replace(" ", "").Replace("-", "").Replace("/", "").Replace("'", "").Replace("(", "").Replace(")", "");
                }
            }

            ds.Tables.Add(new DataTable("TokenNo"));

            ds.Tables["TokenNo"].Columns.Add("TokenNo");
            ds.Tables["TokenNo"].Rows.Add(tokenNo);

            output = ConvertToJson(ds);

            //if (CreateRequestLog(prop.json, output, tokenNo) == "E") { prop.message = "Log Exception Occurred!!!"; return SendMessage(prop); }
            CreateRequestLog("Requested On : " + prop.requestedOn + " Input : " + prop.json, "Responded On : " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF") + " Output : " + output, tokenNo);

            ExceptionHandler.Instance.Trace("OUTPUT-> Report: " + output);
            ExceptionHandler.Instance.Trace("Report End: " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF"));
            ExceptionHandler.Instance.Trace("--------------------------------------------------------------------------------------------------");
        }
        catch (Exception ex)
        {
            ExceptionHandler.Instance.ExtractExceptionInfo(ex, tokenNo);//add user token

            prop.resCode = "301";
            prop.message = "Exception Occurred...";
            return SendMessage(prop, tokenNo);
        }
        finally
        {
            entity = null;
            objDealer = null;

            dt = null;
            ds = null;
        }

        return output;
    }

    public string CreateDealer(WCFProperty prop)
    {
        int dealerColumns = 54;

        string validMsg = string.Empty;
        string tokenNo = string.Empty;
        string output = string.Empty;
        string resCode = string.Empty;

        prop.resCode = "301";

        DataTable dt;
        DataSet ds;
        DataSet destination;

        Dealer dealerEntity;
        UploadFile fileEntity;

        DALDealer objDealer;

        try
        {
            if (!IsValidIP()) { prop.resCode = "100"; prop.message = "Access Denied!!!"; return SendMessage(prop); }

            prop.requestedOn = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF");
            ExceptionHandler.Instance.Trace("Dealer Creation Start: " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF"));

            //...Validations Start...//
            if (String.IsNullOrEmpty(prop.json))
            {
                prop.resCode = "300";
                prop.message = "Empty Input";

                return SendMessage(prop);
            }

            ds = JsonToDataset(prop.json);

            if (ds == null) { prop.resCode = "300"; prop.message = "Empty Data"; return SendMessage(prop); }
            if (ds.Tables.Count == 0) { prop.resCode = "300"; prop.message = "Empty Data"; return SendMessage(prop); }
            if (ds.Tables.Count < 2) { prop.resCode = "300"; prop.message = "Improper Data"; return SendMessage(prop); }
            if (ds.Tables["TokenNo"].Rows.Count == 0) { prop.resCode = "300"; prop.message = "Token No is empty."; return SendMessage(prop); }
            if (ds.Tables["Dealer"].Rows.Count == 0) { prop.resCode = "300"; prop.message = "Dealer detail is empty."; return SendMessage(prop); }

            ExceptionHandler.Instance.Trace("INPUT -> Dealer: " + prop.json);

            tokenNo = Convert.ToString(ds.Tables["TokenNo"].Rows[0]["TokenNo"]);

            ExceptionHandler.Instance.Trace("Token No: " + tokenNo);

            if (!IsValidToken(tokenNo, out validMsg, out resCode)) { prop.resCode = resCode; prop.message = validMsg; return SendMessage(prop); }
            if (ds.Tables["Dealer"].Columns.Count != dealerColumns) { prop.resCode = "302"; prop.message = "Dealer Columns mismatch."; return SendMessage(prop, tokenNo); }            

            validMsg = IsInvalidColumns(ds.Tables["Dealer"], out resCode);

            if (validMsg != "" || validMsg.Trim().Length > 0) { prop.resCode = resCode; prop.message = validMsg; return SendMessage(prop, tokenNo); }            

            validMsg = CheckDealerRateCode(ds.Tables["Dealer"], out resCode);

            if (validMsg != "" || validMsg.Trim().Length > 0) { prop.resCode = resCode; prop.message = validMsg; return SendMessage(prop, tokenNo); }

            if (IsValidAccount(Convert.ToString(ds.Tables["Dealer"].Rows[0]["AccountNo"])) == "Y") { prop.resCode = "302"; prop.message = "Dealer already exists!!!"; return SendMessage(prop, tokenNo); }
            //...Validations End...//            

            dt = ds.Tables["Dealer"];

            fileEntity = new UploadFile();

            objDealer = new DALDealer();
            objDealer.InsertUploadFileDetails(fileEntity, tokenNo);

            if (fileEntity.Message == "E") { prop.resCode = "305"; prop.message = "Data Upload failed."; return SendMessage(prop, tokenNo); }

            dealerEntity = new Dealer();

            dealerEntity.Dealer_Name = Convert.ToString(dt.Rows[0]["DealerName"]);
            dealerEntity.Account_No = Convert.ToString(dt.Rows[0]["AccountNo"]);
            dealerEntity.Customer_Id = Convert.ToString(dt.Rows[0]["CustomerId"]);
            dealerEntity.Sanction_Limit = Convert.ToString(dt.Rows[0]["DealerLimit"]);
            dealerEntity.Sanction_date = Convert.ToString(dt.Rows[0]["DealerSanctionDate"]);
            dealerEntity.Expiry_Date = Convert.ToString(dt.Rows[0]["DealerExpiryDate"]);
            dealerEntity.Renewal_Date = Convert.ToString(dt.Rows[0]["DealerRenewalDate"]);
            dealerEntity.Limit_Id_Prefix = Convert.ToString(dt.Rows[0]["LimitIdPrefix"]);
            dealerEntity.Limit_Id_Suffix = Convert.ToString(dt.Rows[0]["LimitIdSuffix"]);
            dealerEntity.Parent_Limit_Id_Prefix = Convert.ToString(dt.Rows[0]["ParentLimitIdPrefix"]);
            dealerEntity.Parent_Limit_Id_Suffix = Convert.ToString(dt.Rows[0]["ParentLimitIdSuffix"]);
            dealerEntity.Address1 = Convert.ToString(dt.Rows[0]["Address1"]);
            dealerEntity.Address2 = Convert.ToString(dt.Rows[0]["Address2"]);
            dealerEntity.City = Convert.ToString(dt.Rows[0]["City"]);
            dealerEntity.State = Convert.ToString(dt.Rows[0]["State"]);
            dealerEntity.PIN = Convert.ToString(dt.Rows[0]["Pin"]);
            dealerEntity.PhoneNo = Convert.ToString(dt.Rows[0]["PhoneNo"]);
            dealerEntity.Email1 = Convert.ToString(dt.Rows[0]["EmailId"]);
            dealerEntity.Account_Opening_Date = Convert.ToString(dt.Rows[0]["AccountOpenDate"]);
            dealerEntity.Account_Closing_Date = Convert.ToString(dt.Rows[0]["AccountCloseDate"]);
            dealerEntity.Account_Status = Convert.ToString(dt.Rows[0]["AccountStatus"]);
            dealerEntity.Limit = Convert.ToString(dt.Rows[0]["ProgramLimit"]);
            dealerEntity.ProgramSanctionDate = Convert.ToString(dt.Rows[0]["ProgramSanctionDate"]);
            dealerEntity.ProgramExpiryDate = Convert.ToString(dt.Rows[0]["ProgramExpiryDate"]);
            dealerEntity.ProgramRenewalDate = Convert.ToString(dt.Rows[0]["ProgramRenewalDate"]);
            dealerEntity.Documentation_Date = Convert.ToString(dt.Rows[0]["DocumentationDate"]);
            dealerEntity.Doc1 = Convert.ToString(dt.Rows[0]["Doc1"]);
            dealerEntity.Doc2 = Convert.ToString(dt.Rows[0]["Doc2"]);
            dealerEntity.Doc3 = Convert.ToString(dt.Rows[0]["Doc3"]);
            dealerEntity.Doc4 = Convert.ToString(dt.Rows[0]["Doc4"]);
            dealerEntity.Doc5 = Convert.ToString(dt.Rows[0]["Doc5"]);
            dealerEntity.Doc6 = Convert.ToString(dt.Rows[0]["Doc6"]);
            dealerEntity.Doc7 = Convert.ToString(dt.Rows[0]["Doc7"]);
            dealerEntity.Doc8 = Convert.ToString(dt.Rows[0]["Doc8"]);
            dealerEntity.Doc9 = Convert.ToString(dt.Rows[0]["Doc9"]);
            dealerEntity.Doc10 = Convert.ToString(dt.Rows[0]["Doc10"]);
            dealerEntity.Short_Name = Convert.ToString(dt.Rows[0]["DealerShortName"]);
            dealerEntity.Sol_Id = Convert.ToString(dt.Rows[0]["SolID"]);
            dealerEntity.Dealer_Corporate_Name = Convert.ToString(dt.Rows[0]["DealerCorporateName"]);
            dealerEntity.FileID = fileEntity.Id;
            dealerEntity.SM_Email = Convert.ToString(dt.Rows[0]["SMAccountManagerEmailID"]);
            dealerEntity.SM_Name = Convert.ToString(dt.Rows[0]["NameOfSM"]);
            dealerEntity.CRM_Name = Convert.ToString(dt.Rows[0]["NameOfCRM"]);
            dealerEntity.Tenor = Convert.ToString(dt.Rows[0]["CreditTenorForTheProgram"]).Trim();
            dealerEntity.Category_Code = Convert.ToString(dt.Rows[0]["CategoryName"]).Trim();
            dealerEntity.Rate_Code = this.GetRateCode(Convert.ToString(dt.Rows[0]["RateCode"]).Trim());
            dealerEntity.Fixed_Rate_Code = Convert.ToString(dt.Rows[0]["FixedRateCode"]).Trim();
            dealerEntity.Cure_Code = Convert.ToString(dt.Rows[0]["CureRateCode"]).Trim();
            dealerEntity.Penal_Code = Convert.ToString(dt.Rows[0]["PenalRateCode"]).Trim();
            dealerEntity.Minimum_Code = Convert.ToString(dt.Rows[0]["MinimumCode"]).Trim();
            dealerEntity.Maximum_Code = Convert.ToString(dt.Rows[0]["MaximumCode"]).Trim();
            dealerEntity.Contact_Person = Convert.ToString(dt.Rows[0]["ContactPerson"]);
            dealerEntity.Mode_Of_Funding_Flag = this.GetModeOfFunding(Convert.ToString(dt.Rows[0]["ModeOfFunding"]).Trim());
            dealerEntity.Asset_Classification = this.GetClassification(Convert.ToString(dt.Rows[0]["AssetClassification"]).Trim());
            dealerEntity.CreatedThroughChannel = Convert.ToString(dt.Rows[0]["CreatedThroughChannel"]).Trim();

            objDealer.InsertCorporateDealerTemp(dealerEntity);

            if (dealerEntity.Message == "E") { prop.resCode = "305"; prop.message = "Data Upload failed."; return SendMessage(prop, tokenNo); }

            fileEntity.Message = string.Empty;

            fileEntity.CreatedBy = tokenNo;

            objDealer.InsertIntoCorporateDealer(fileEntity);

            if (fileEntity.Message == "E")
            {
                dealerEntity.Message = string.Empty;

                objDealer.getCorporateDealerError(dealerEntity);

                prop.resCode = "302";
                prop.message = dealerEntity.Message;
            }
            else if (fileEntity.Message == "S")
            {
                prop.resCode = "200";
                prop.message = "Dealer Created Successfully.";
            }

            destination = new DataSet();

            destination.Tables.Add("TokenNo");
            destination.Tables.Add("Message");

            destination.Tables["TokenNo"].Columns.Add("TokenNo");
            destination.Tables["TokenNo"].Rows.Add(tokenNo);

            destination.Tables["Message"].Columns.Add("ResponseCode");
            destination.Tables["Message"].Columns.Add("Message");

            destination.Tables["Message"].Rows.Add(prop.resCode, prop.message);

            output = ConvertToJson(destination);

            CreateRequestLog("Requested On : " + prop.requestedOn + " Input : " + prop.json, "Responded On : " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF") + " Output : " + output, tokenNo, dealerEntity.CreatedThroughChannel);

            ExceptionHandler.Instance.Trace("OUTPUT-> Dealer: " + output);
            ExceptionHandler.Instance.Trace("Dealer Creation End: " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss.FFF"));
            ExceptionHandler.Instance.Trace("--------------------------------------------------------------------------------------------------");
        }
        catch (Exception ex)
        {
            ExceptionHandler.Instance.ExtractExceptionInfo(ex, tokenNo);//add user token

            prop.resCode = "301";
            prop.message = "Exception Occurred...";
            return SendMessage(prop, tokenNo);
        }
        finally
        {
            destination = null;
            objDealer = null;

            dt = null;
            ds = null;

            dealerEntity = null;
            fileEntity = null;
            objDealer = null;
        }

        return output;
    }

}
