﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
[ServiceContract]
public interface IService
{

    //[OperationContract(Name = "DataTableToJson")]
    //string ConvertToJson(DataTable dt);
  
    [OperationContract]
    string DealerOutstandingReport(WCFProperty prop);

    [OperationContract]
    string CreateDealer(WCFProperty prop);  

    // TODO: Add your service operations here
}

// Use a data contract as illustrated in the sample below to add composite types to service operations.
[DataContract]
public class WCFProperty
{
    private string _json;
    private string _resCode;
    private string _message;
    private string _requestedOn;

    [DataMember]
    public string json { get { return _json; } set { _json = value; } }

    public string resCode { get { return _resCode; } set { _resCode = value; } }
    public string message { get { return _message; } set { _message = value; } }
    public string requestedOn { get { return _requestedOn; } set { _requestedOn = value; } }

}
