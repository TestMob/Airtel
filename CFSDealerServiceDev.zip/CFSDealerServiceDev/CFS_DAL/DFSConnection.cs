using System;
using System.Web;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using IBank.Framework.Components;

namespace ICICIInfotechLtd.Ibank.CFS.DAL
{
    /// <summary>
    /// Summary description for DFSConnection.
    /// </summary>
    public class DFSConnection
    {
        private SqlConnection _DFSConn;
        internal DFSConnection()
        {
            //
            // TODO: Add constructor logic here			
            //
        }
        internal SqlConnection GetConnection()
        {
            return GetConnection(getConnectionString());
        }

        internal SqlConnection GetConnection(string connectionstring)
        {
            _DFSConn = new SqlConnection();
            _DFSConn.ConnectionString = connectionstring;
            _DFSConn.Open();

            return _DFSConn;
        }

        internal string getConnectionString()
        {
            string decryptedConn = null;
            try
            {
                EncryptionClient _objEncrypt = new EncryptionClient();
                string strConnStrEnc = "";

                strConnStrEnc = ConfigurationSettings.AppSettings["connstr"].ToString(); //Encrypted string from Web.Config

                decryptedConn = _objEncrypt.StringDecrypt(strConnStrEnc, "CFSENC");
            }
            catch (Exception ex) { }

            return decryptedConn;
        }

        internal void CloseConnection(SqlConnection Connnection)
        {
            if (Connnection != null)
            {
                if (Connnection.State == ConnectionState.Open)
                {
                    Connnection.Close();
                    Connnection = null;
                }
            }
        }

        /*internal static string getCLBConnectionString()
        {	
            EncryptionClient _objEncrypt = new EncryptionClient();
            string strConnStrEnc = "";
            strConnStrEnc = ConfigurationManager.AppSettings["connstr"].ToString(); //Encrypted string from Web.Config		
            return _objEncrypt.StringDecrypt(strConnStrEnc,"CFSENC");
        }*/

        /*
                public string testConnection ()
                {
                    SqlConnection testcn = new SqlConnection();
                    testcn  = GetConnection();
                    return testcn.State.ToString (); 
                }
	
        */
    }
}
