using System;
using System.Text;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using ICICIInfotechLtd.Ibank.CFS.Entity;
using ICICIInfotechLtd.Ibank.CFS.Entity.Interface;
using ICICIInfotechLtd.Ibank.CFS.DAL;
using System.IO;

namespace ICICIInfotechLtd.Ibank.CFS.DAL
{
    /// <summary>
    /// Class for saving the exception details to the database.
    /// </summary>
    public class ExceptionHandler
    {
        private static ExceptionHandler _exception;

        //**********************************************************************
        /// <summary>
        /// Default constructor.
        /// </summary>
        private ExceptionHandler() { } // end constructor.	

        public static ExceptionHandler Instance
        {
            get
            {
                if (_exception == null)
                {
                    _exception = new ExceptionHandler();
                }
                return _exception;
            }
        } // end Instance

        public void ExtractExceptionInfo(Exception ex, string userName)
        {
            string className;

            try
            {
                AddExceptionToFile(ex);

                ExceptionEntity _exceptionentity = new ExceptionEntity();

                // ThreadAbortException occurs when Response.redirect()/Response.end() is used in try block.
                if (ex.GetType() == typeof(System.Threading.ThreadAbortException))
                {
                    return;
                }
                // First check if exception object is of type SqlException.
                // If yes, extract the error number.
                if (ex.GetType() == typeof(SqlException))
                {
                    SqlException sqlEx = (SqlException)ex;
                    // Extract or assign parameter value for exception code.				
                    _exceptionentity.ExceptionCode = sqlEx.Number.ToString();
                }
                else
                {
                    _exceptionentity.ExceptionCode = "";
                    Debug.WriteLine("It is general exception.");
                }
                // Extract or assign parameter value for base exception.
                _exceptionentity.BaseException = ex.GetBaseException().ToString();
                _exceptionentity.InnerException = (ex.InnerException == null ||
                    ex.InnerException.ToString() == string.Empty) ?
                    "Inner exception" : ex.InnerException.ToString();
                //*********************************************
                string h = ex.StackTrace.Remove(ex.StackTrace.LastIndexOf("("),
                    ex.StackTrace.Length - ex.StackTrace.LastIndexOf("("));
                string i = h.Substring(h.LastIndexOf(" ") + 1);
                string methodName = i.Substring(i.LastIndexOf(".") + 1);

                if (i.IndexOf(".") == i.LastIndexOf("."))
                {
                    className = i.Remove(i.LastIndexOf("."),
                   methodName.Length + 1);
                }
                else
                {
                    className = i.Remove(i.LastIndexOf("."),
                       methodName.Length + 1).Substring(i.IndexOf(".") + 1);
                }

                _exceptionentity.SourceClass = className;
                _exceptionentity.SourceFunction = methodName;
                //*********************************************
                _exceptionentity.ExceptionMessage = ex.Message;
                _exceptionentity.Source = ex.Source;
                _exceptionentity.StackTrace = ex.StackTrace;
                _exceptionentity.TargetSite = ex.TargetSite.ToString();
                _exceptionentity.CreatedBy = userName;

                DALApplicationException _DAL = new DALApplicationException();
                _DAL.addEntity(_exceptionentity);
            }
            catch (Exception exe)
            {

            }

        } // end ExtractAndAssignParameterValues

        //Overloaded method in case of scheduler generates any error (Need to pass connectionstring.
        public void ExtractExceptionInfo(Exception ex, string userName, string connectionstring)
        {
            try
            {
                AddExceptionToFile(ex);

                ExceptionEntity _exceptionentity = new ExceptionEntity();

                // ThreadAbortException occurs when Response.redirect()/Response.end() is used in try block.
                if (ex.GetType() == typeof(System.Threading.ThreadAbortException))
                {
                    return;
                }
                // First check if exception object is of type SqlException.
                // If yes, extract the error number.
                if (ex.GetType() == typeof(SqlException))
                {
                    SqlException sqlEx = (SqlException)ex;
                    // Extract or assign parameter value for exception code.				
                    _exceptionentity.ExceptionCode = sqlEx.Number.ToString();
                }
                else
                {
                    _exceptionentity.ExceptionCode = "";
                    Debug.WriteLine("It is general exception.");
                }
                // Extract or assign parameter value for base exception.
                _exceptionentity.BaseException = ex.GetBaseException().ToString();
                _exceptionentity.InnerException = (ex.InnerException == null ||
                    ex.InnerException.ToString() == string.Empty) ?
                    "Inner exception" : ex.InnerException.ToString();
                //*********************************************
                string h = ex.StackTrace.Remove(ex.StackTrace.LastIndexOf("("),
                    ex.StackTrace.Length - ex.StackTrace.LastIndexOf("("));
                string i = h.Substring(h.LastIndexOf(" ") + 1);
                string methodName = i.Substring(i.LastIndexOf(".") + 1);
                string className = i.Remove(i.LastIndexOf("."),
                    methodName.Length + 1).Substring(i.IndexOf(".") + 1);

                _exceptionentity.SourceClass = className;
                _exceptionentity.SourceFunction = methodName;
                //*********************************************
                _exceptionentity.ExceptionMessage = ex.Message;
                _exceptionentity.Source = ex.Source;
                _exceptionentity.StackTrace = ex.StackTrace;
                _exceptionentity.TargetSite = ex.TargetSite.ToString();
                _exceptionentity.ConnectionString = connectionstring;
                _exceptionentity.CreatedBy = userName;

                DALApplicationException _DAL = new DALApplicationException();
                _DAL.addEntity(_exceptionentity);
            }
            catch
            {

            }

        } // end ExtractAndAssignParameterValues

        public void AddExceptionToFile(Exception ex)
        {
            // ThreadAbortException occurs when Response.redirect()/Response.end() is used in try block.
            if (ex.GetType() == typeof(System.Threading.ThreadAbortException))
                return;

            // HttpUnhandledException occurs when Response.redirect()/Response.end() is used in try block.
            //if (ex.GetType() == typeof(System.Web.HttpUnhandledException))			
            //	return ;				

            string errLogPath = ConfigurationSettings.AppSettings["ErrorLogPath"].ToString();
            if (!Directory.Exists(errLogPath))
                Directory.CreateDirectory(errLogPath);

            string filename = DateTime.Now.ToString("dd-MMM-yyyy") + "_DealerServiceError" + ".txt";
            string filepath = Path.Combine(errLogPath, filename);

            if (!File.Exists(filepath))
                File.CreateText(filepath).Close();

            using (StreamWriter sw = new StreamWriter(filepath, true))
            {
                sw.WriteLine("Date Time	: " + DateTime.Now.ToString("dd MMM yyyy hh:mm:ss tt"));
                sw.WriteLine("Message		: " + Convert.ToString(ex.Message));
                sw.WriteLine("Stack Trace	: " + Convert.ToString(ex.StackTrace));
                sw.WriteLine("Source	: " + Convert.ToString(ex.Source));
                sw.WriteLine("Inner Exception	: " + Convert.ToString(ex.InnerException));
                sw.WriteLine("-----------------------------------------------------------------------------------");
                sw.WriteLine(Environment.NewLine);
            }
        }

        public void Trace(string sHeader)
        {
            if (ConfigurationSettings.AppSettings["IsFileLogged"].ToString().ToUpper() != "YES") { return; }

            string strLogPath = ConfigurationSettings.AppSettings["LogPath"].ToString();

            try
            {
                StringBuilder sActualError = new StringBuilder();

                if (!Directory.Exists(strLogPath))
                    Directory.CreateDirectory(strLogPath);

                string filename = DateTime.Now.ToString("ddMMyyyy") + "_DealerService.txt";
                string filepath = Path.Combine(strLogPath, filename);

                using (StreamWriter sw = new StreamWriter(filepath, true, System.Text.Encoding.ASCII))
                {
                    if (!string.IsNullOrEmpty(sHeader))
                    {
                        sActualError.AppendLine(sHeader);
                    }
                    sw.WriteLine(sActualError.ToString());
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception exc)
            {
                ExtractExceptionInfo(exc, "SYSTEM");
            }
            finally
            {

            }
        }

    } // end class ExceptionHandler

} // end namespace ExceptionInformation
