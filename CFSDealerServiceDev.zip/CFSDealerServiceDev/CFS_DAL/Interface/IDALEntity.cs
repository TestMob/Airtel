using System;
using System.Collections;
using ICICIInfotechLtd.Ibank.CFS.Entity.Interface;


namespace ICICIInfotechLtd.Ibank.CFS.DAL.Interface
{
	/// <summary>
	/// Summary description for IDAL_Entity.
	/// </summary>
	public interface IDALEntity
	{
		void getEntity(IEntity entity);

		ArrayList getEntityList(IEntity entity);

		void addEntity(IEntity entity);

		void updateEntity(IEntity entity);

		void updateStatus(IEntity entity);
	}
}
