using System;
using System.Data;
using System.Data.SqlClient;
using ICICIInfotechLtd.Ibank.CFS.Entity;
using ICICIInfotechLtd.Ibank.CFS.DAL;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;

namespace ICICIInfotechLtd.Ibank.CFS.DAL
{
    /// <summary>
    /// Summary description for DALDealer.
    /// </summary>
    public class DALDealer
    {
        const int COMMANDTIMEOUT = 21000;
        SqlConnection _objConn;
        DFSConnection con = new DFSConnection();

        public DALDealer()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Generate SQL Parameter

        //Enum to define codes for all parameters. 
        enum _ParameterValues
        {
            DealerID = 0,
            DealerName,
            AccountNo,
            CustomerId,
            SanctionLimit,
            SanctionDate,
            ExpiryDate,
            RenewalDate,
            LimitIdPrefix,
            LimitIdSuffix,
            ParentLimitIdPrefix,
            ParentLimitIdSuffix,
            Address1,
            Address2,
            City,
            State,
            Pin,
            PhoneNo,
            EmailID,
            Email1,  //not to be updated.
            Email2,
            Email3,
            AccountOpenDate,
            AccountCloseDate,
            AccountStatus,
            ProgramLimit,
            ProgramSanctionDate,
            ProgramExpiryDate,
            ProgramRenewalDate,
            DocumentationDate,
            Doc1,
            Doc2,
            Doc3,
            Doc4,
            Doc5,
            Doc6,
            Doc7,
            Doc8,
            Doc9,
            Doc10,
            DealerShortName,
            SolID,
            DealerCorporateName,
            CreatedBy,
            SuccessMessage,
            ErrorMessage,
            OutputFileID,
            ReturnFlag,
            UploadFileName,
            UploadFileType,
            CreatedOn,
            SuccessRecords,
            FailureRecords,
            TotalRecords,
            CategoryCode,
            FixedRateCode,
            CureCode,
            PenalCode,
            MinimumCode,
            MaximumCode,
            SMEmailID,
            NameOfSM,
            NameOfCRM,
            CreditTenor,
            RateCode,
            ContactPerson,
            ModeOfFunding,
            AssetClassification,
            CreatedThroughChannel

            //SM_Name,
            //CRM_Name,
            //Contact_Person,
            //Mode_Of_Funding_Flag,
            //SM_EMail,
            //Asset_Classification,
            //Rating = 29,
            //Status = 41,
            //Remark = 42,
            //Tenor = 43,
            //Limit = 44,
            //Category_Code = 48,
            //Rate_Code = 49,
            //Fixed_Rate_Code = 50,
            //Cure_Code = 51,
            //Penal_Code = 52,
            //Minimum_Code = 53,
            //Maximum_Code = 54,
            //No_Of_Peak_Usage = 55,
            //Peak_Interest = 56,
            //Peak_Tenor = 57,
            //Peak_Limit = 58,
            //Peak_Effective_From = 59,
            //Peak_Effective_Till = 60,
            //TOD_Code = 61,
            //TOD_Margin = 62,
            //Effective_From = 63,
            //Effective_Till = 64,
            //Created_By = 65,
            //Modified_By = 66,
            //ReturnFlag = 67,
            //Identity = 68,
            //TOD_Calculation = 69,
            //Report_Format = 70
        };

        private SqlParameter[] generateSQLParameter(CustomSQLParameter[] parameter)
        {
            int intParaLen = parameter.GetLength(0);

            SqlParameter[] objSQLParameter = new SqlParameter[intParaLen];

            for (int i = 0; i < intParaLen; i++)
            {
                //if (parameter[i].Parameter == _ParameterValues.DealerID.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDealerId", SqlDbType.VarChar, 7);

                //if (parameter[i].Parameter == _ParameterValues.DealerName.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDealerName", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.CustomerId.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strCustomerId", SqlDbType.VarChar, 9);

                //if (parameter[i].Parameter == _ParameterValues.SanctionLimit.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strSanctionLimit", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.SanctionDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strSanctionDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.ExpiryDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strExpiryDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.RenewalDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strRenewalDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.LimitIdPrefix.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strLimitIdPrefix", SqlDbType.VarChar, 12);

                //if (parameter[i].Parameter == _ParameterValues.LimitIdSuffix.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strLimitIdSuffix", SqlDbType.VarChar, 5);

                //if (parameter[i].Parameter == _ParameterValues.ParentLimitIdPrefix.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strParentLimitIdPrefix", SqlDbType.VarChar, 12);

                //if (parameter[i].Parameter == _ParameterValues.ParentLimitIdSuffix.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strParentLimitIdSuffix", SqlDbType.VarChar, 5);

                //if (parameter[i].Parameter == _ParameterValues.Address1.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strAddress1", SqlDbType.VarChar, 250);

                //if (parameter[i].Parameter == _ParameterValues.Address2.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strAddress2", SqlDbType.VarChar, 250);

                //if (parameter[i].Parameter == _ParameterValues.City.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strCity", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.State.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strState", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Pin.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strPin", SqlDbType.VarChar, 20);

                //if (parameter[i].Parameter == _ParameterValues.PhoneNo.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strPhoneNo", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.EmailID.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strEmailID", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.AccountOpenDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strAccountOpenDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.AccountCloseDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strAccountCloseDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.AccountStatus.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strAccountStatus", SqlDbType.VarChar, 1);

                //if (parameter[i].Parameter == _ParameterValues.ProgramLimit.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strProgramLimit", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.ProgramSanctionDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strProgramSanctionDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.ProgramExpiryDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strProgramExpiryDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.ProgramRenewalDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strProgramRenewalDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.DocumentationDate.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDocumentationDate", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.Doc1.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc1", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc2.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc2", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc3.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc3", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc4.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc4", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc5.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc5", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc6.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc6", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc7.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc7", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc8.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc8", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc9.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc9", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.Doc10.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDoc10", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.DealerShortName.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDealerShortName", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.SolID.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strSolID", SqlDbType.VarChar, 10);

                //if (parameter[i].Parameter == _ParameterValues.DealerCorporateName.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strDealerCorporateName", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.AccountNo.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strAccount_No", SqlDbType.VarChar, 20);

                //if (parameter[i].Parameter == _ParameterValues.CreatedBy.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strUserId", SqlDbType.VarChar, 20);

                //if (parameter[i].Parameter == _ParameterValues.SuccessMessage.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strSuccessMessage", SqlDbType.VarChar, 3000);

                //if (parameter[i].Parameter == _ParameterValues.ErrorMessage.ToString() && parameter[i].Direction == ParameterDirection.Input)
                //    objSQLParameter[i] = new SqlParameter("@i_strErrorMessage", SqlDbType.VarChar, 3000);

                //if (parameter[i].Parameter == _ParameterValues.ErrorMessage.ToString() && parameter[i].Direction == ParameterDirection.Output)
                //    objSQLParameter[i] = new SqlParameter("@o_strErrorMessage", SqlDbType.VarChar, 3000);

                //if (parameter[i].Parameter == _ParameterValues.ReturnFlag.ToString())
                //    objSQLParameter[i] = new SqlParameter("@o_strReturnFlag", SqlDbType.Char, 1);

                //if (parameter[i].Parameter == _ParameterValues.OutputFileID.ToString() && parameter[i].Direction == ParameterDirection.Input)
                //    objSQLParameter[i] = new SqlParameter("i_strUploadFileId", SqlDbType.VarChar, 10);

                //if (parameter[i].Parameter == _ParameterValues.OutputFileID.ToString() && parameter[i].Direction == ParameterDirection.Output)
                //    objSQLParameter[i] = new SqlParameter("@o_strUploadFileId", SqlDbType.VarChar, 10);

                //if (parameter[i].Parameter == _ParameterValues.UploadFileName.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strUploadFileName", SqlDbType.VarChar, 50);

                //if (parameter[i].Parameter == _ParameterValues.UploadFileType.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strTypeOfUpload", SqlDbType.VarChar, 5);

                //if (parameter[i].Parameter == _ParameterValues.CreatedOn.ToString() && parameter[i].Direction == ParameterDirection.Output)
                //    objSQLParameter[i] = new SqlParameter("@o_strCreatedOn", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.CreatedOn.ToString() && parameter[i].Direction == ParameterDirection.Input)
                //    objSQLParameter[i] = new SqlParameter("@i_strCreatedOn", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.CreatedBy.ToString())
                //    objSQLParameter[i] = new SqlParameter("@i_strCreatedBy", SqlDbType.VarChar, 25);

                //if (parameter[i].Parameter == _ParameterValues.SuccessRecords.ToString())
                //    objSQLParameter[i] = new SqlParameter("@o_strSuccessRecords", SqlDbType.VarChar, 10);

                //if (parameter[i].Parameter == _ParameterValues.FailureRecords.ToString())
                //    objSQLParameter[i] = new SqlParameter("@o_strFailureRecords", SqlDbType.VarChar, 10);

                //if (parameter[i].Parameter == _ParameterValues.TotalRecords.ToString())
                //    objSQLParameter[i] = new SqlParameter("@o_strTotalRecords", SqlDbType.VarChar, 10);

                if (parameter[i].Parameter == _ParameterValues.DealerID.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDealerId", SqlDbType.VarChar, 7);

                if (parameter[i].Parameter == _ParameterValues.DealerName.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDealerName", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.CustomerId.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCustomerId", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.SanctionLimit.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strSanctionLimit", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.SanctionDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strSanctionDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ExpiryDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strExpiryDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.RenewalDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strRenewalDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.LimitIdPrefix.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strLimitIdPrefix", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.LimitIdSuffix.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strLimitIdSuffix", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ParentLimitIdPrefix.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strParentLimitIdPrefix", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ParentLimitIdSuffix.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strParentLimitIdSuffix", SqlDbType.VarChar,100);

                if (parameter[i].Parameter == _ParameterValues.Address1.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAddress1", SqlDbType.VarChar, 250);

                if (parameter[i].Parameter == _ParameterValues.Address2.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAddress2", SqlDbType.VarChar, 250);

                if (parameter[i].Parameter == _ParameterValues.City.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCity", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.State.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strState", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Pin.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strPin", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.PhoneNo.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strPhoneNo", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.EmailID.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strEmailID", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.AccountOpenDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAccountOpenDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.AccountCloseDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAccountCloseDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.AccountStatus.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAccountStatus", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ProgramLimit.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strProgramLimit", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ProgramSanctionDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strProgramSanctionDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ProgramExpiryDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strProgramExpiryDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ProgramRenewalDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strProgramRenewalDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.DocumentationDate.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDocumentationDate", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc1.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc1", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc2.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc2", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc3.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc3", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc4.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc4", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc5.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc5", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc6.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc6", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc7.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc7", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc8.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc8", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc9.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc9", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.Doc10.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDoc10", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.DealerShortName.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDealerShortName", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.SolID.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strSolID", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.DealerCorporateName.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strDealerCorporateName", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.AccountNo.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAccount_No", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.CreatedBy.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strUserId", SqlDbType.VarChar, 20);

                if (parameter[i].Parameter == _ParameterValues.SuccessMessage.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strSuccessMessage", SqlDbType.VarChar, 3000);

                if (parameter[i].Parameter == _ParameterValues.ErrorMessage.ToString() && parameter[i].Direction == ParameterDirection.Input)
                    objSQLParameter[i] = new SqlParameter("@i_strErrorMessage", SqlDbType.VarChar, 3000);

                if (parameter[i].Parameter == _ParameterValues.ErrorMessage.ToString() && parameter[i].Direction == ParameterDirection.Output)
                    objSQLParameter[i] = new SqlParameter("@o_strErrorMessage", SqlDbType.VarChar, 3000);

                if (parameter[i].Parameter == _ParameterValues.ReturnFlag.ToString())
                    objSQLParameter[i] = new SqlParameter("@o_strReturnFlag", SqlDbType.Char, 1);

                if (parameter[i].Parameter == _ParameterValues.OutputFileID.ToString() && parameter[i].Direction == ParameterDirection.Input)
                    objSQLParameter[i] = new SqlParameter("i_strUploadFileId", SqlDbType.VarChar, 10);

                if (parameter[i].Parameter == _ParameterValues.OutputFileID.ToString() && parameter[i].Direction == ParameterDirection.Output)
                    objSQLParameter[i] = new SqlParameter("@o_strUploadFileId", SqlDbType.VarChar, 10);

                if (parameter[i].Parameter == _ParameterValues.UploadFileName.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strUploadFileName", SqlDbType.VarChar, 50);

                if (parameter[i].Parameter == _ParameterValues.UploadFileType.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strTypeOfUpload", SqlDbType.VarChar, 5);

                if (parameter[i].Parameter == _ParameterValues.CreatedOn.ToString() && parameter[i].Direction == ParameterDirection.Output)
                    objSQLParameter[i] = new SqlParameter("@o_strCreatedOn", SqlDbType.VarChar, 25);

                if (parameter[i].Parameter == _ParameterValues.CreatedOn.ToString() && parameter[i].Direction == ParameterDirection.Input)
                    objSQLParameter[i] = new SqlParameter("@i_strCreatedOn", SqlDbType.VarChar, 25);

                if (parameter[i].Parameter == _ParameterValues.CreatedBy.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCreatedBy", SqlDbType.VarChar, 25);

                if (parameter[i].Parameter == _ParameterValues.SuccessRecords.ToString())
                    objSQLParameter[i] = new SqlParameter("@o_strSuccessRecords", SqlDbType.VarChar, 10);

                if (parameter[i].Parameter == _ParameterValues.FailureRecords.ToString())
                    objSQLParameter[i] = new SqlParameter("@o_strFailureRecords", SqlDbType.VarChar, 10);

                if (parameter[i].Parameter == _ParameterValues.TotalRecords.ToString())
                    objSQLParameter[i] = new SqlParameter("@o_strTotalRecords", SqlDbType.VarChar, 10);

                if (parameter[i].Parameter == _ParameterValues.CategoryCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCategoryCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.FixedRateCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strFixedRateCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.CureCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCureCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.PenalCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strPenalCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.MinimumCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strMinimumCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.MaximumCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strMaximumCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.SMEmailID.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strSMEmail", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.NameOfSM.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strNameOfSM", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.NameOfCRM.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strNameOfCRM", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.CreditTenor.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCreditTenor", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.RateCode.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strRateCode", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ContactPerson.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strContactPerson", SqlDbType.VarChar, 100);

                if (parameter[i].Parameter == _ParameterValues.ModeOfFunding.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strModeOfFunding", SqlDbType.Char, 1);

                if (parameter[i].Parameter == _ParameterValues.AssetClassification.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strAssetClassification", SqlDbType.Char, 1);

                if (parameter[i].Parameter == _ParameterValues.CreatedThroughChannel.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strCreatedChannel", SqlDbType.VarChar, 100);


                //--------------------------------------------------\\
                objSQLParameter[i].Direction = parameter[i].Direction;
                if (parameter[i].Direction == ParameterDirection.Input)
                    objSQLParameter[i].Value = parameter[i].Value;
                //--------------------------------------------------\\
            }
            return objSQLParameter;
        }

        #endregion

        //public string getConnectionString()
        //{
        //    EncryptionClient _objEncrypt = new EncryptionClient();
        //    string strConnStrEnc = "";
        //    if (System.Web.HttpContext.Current.Session["GroupName"].ToString().ToLower() == "clb")
        //        strConnStrEnc = ConfigurationManager.AppSettings["connstr"].ToString(); //Encrypted string from Web.Config
        //    else if (System.Web.HttpContext.Current.Session["GroupName"].ToString().ToLower() == "agri")
        //        strConnStrEnc = ConfigurationManager.AppSettings["connstragri"].ToString(); //Encrypted string from Web.Config

        //    string decryptedConn = _objEncrypt.StringDecrypt(strConnStrEnc, "CFSENC");
        //    return decryptedConn;


        //}

        public DataSet getDealerwiseOutstanding(Entity.Dealer entityReport)
        {
            DataSet dsReport = new DataSet();

            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();//entityReport.ConnectionString

                Dealer objReport;

                objReport = (Dealer)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[1];

                parameter[0].Parameter = _ParameterValues.AccountNo.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.Account_No;

                _objSQLParameter = new SqlParameter[1];

                _objSQLParameter = generateSQLParameter(parameter);

                dsReport = SqlHelper.ExecuteDataset(_objConn, CommandType.StoredProcedure, "usp_DealerOutstandingReport", 1000, _objSQLParameter);
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }

            return dsReport;
        }

        public DataSet getValidDealerRateCode(Entity.Dealer entityReport)
        {
            DataSet dsReport = new DataSet();

            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();//entityReport.ConnectionString

                Dealer objReport;

                objReport = (Dealer)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[6];

                parameter[0].Parameter = _ParameterValues.CategoryCode.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.Category_Code;

                parameter[1].Parameter = _ParameterValues.FixedRateCode.ToString();
                parameter[1].Direction = ParameterDirection.Input;
                parameter[1].Value = objReport.Fixed_Rate_Code;

                parameter[2].Parameter = _ParameterValues.CureCode.ToString();
                parameter[2].Direction = ParameterDirection.Input;
                parameter[2].Value = objReport.Cure_Code;

                parameter[3].Parameter = _ParameterValues.PenalCode.ToString();
                parameter[3].Direction = ParameterDirection.Input;
                parameter[3].Value = objReport.Penal_Code;

                parameter[4].Parameter = _ParameterValues.MinimumCode.ToString();
                parameter[4].Direction = ParameterDirection.Input;
                parameter[4].Value = objReport.Minimum_Code;

                parameter[5].Parameter = _ParameterValues.MaximumCode.ToString();
                parameter[5].Direction = ParameterDirection.Input;
                parameter[5].Value = objReport.Maximum_Code;

                _objSQLParameter = new SqlParameter[6];

                _objSQLParameter = generateSQLParameter(parameter);

                dsReport = SqlHelper.ExecuteDataset(_objConn, CommandType.Text, "Select * From fn_CheckDealerRateCode(@i_strCategoryCode, @i_strFixedRateCode, @i_strCureCode, @i_strPenalCode, @i_strMinimumCode, @i_strMaximumCode)", 1000, _objSQLParameter);
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }

            return dsReport;
        }

        public void InsertCorporateDealerTemp(Entity.Dealer entityReport)
        {
            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();

                Dealer objReport;

                objReport = (Dealer)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[56];

                parameter[0].Parameter = _ParameterValues.DealerName.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.Dealer_Name;

                parameter[1].Parameter = _ParameterValues.AccountNo.ToString();
                parameter[1].Direction = ParameterDirection.Input;
                parameter[1].Value = objReport.Account_No;

                parameter[2].Parameter = _ParameterValues.CustomerId.ToString();
                parameter[2].Direction = ParameterDirection.Input;
                parameter[2].Value = objReport.Customer_Id;

                parameter[3].Parameter = _ParameterValues.SanctionLimit.ToString();
                parameter[3].Direction = ParameterDirection.Input;
                parameter[3].Value = objReport.Sanction_Limit;

                parameter[4].Parameter = _ParameterValues.SanctionDate.ToString();
                parameter[4].Direction = ParameterDirection.Input;
                parameter[4].Value = objReport.Sanction_date;

                parameter[5].Parameter = _ParameterValues.ExpiryDate.ToString();
                parameter[5].Direction = ParameterDirection.Input;
                parameter[5].Value = objReport.Expiry_Date;

                parameter[6].Parameter = _ParameterValues.RenewalDate.ToString();
                parameter[6].Direction = ParameterDirection.Input;
                parameter[6].Value = objReport.Renewal_Date;

                parameter[7].Parameter = _ParameterValues.LimitIdPrefix.ToString();
                parameter[7].Direction = ParameterDirection.Input;
                parameter[7].Value = objReport.Limit_Id_Prefix;

                parameter[8].Parameter = _ParameterValues.LimitIdSuffix.ToString();
                parameter[8].Direction = ParameterDirection.Input;
                parameter[8].Value = objReport.Limit_Id_Suffix;

                parameter[9].Parameter = _ParameterValues.ParentLimitIdPrefix.ToString();
                parameter[9].Direction = ParameterDirection.Input;
                parameter[9].Value = objReport.Parent_Limit_Id_Prefix;

                parameter[10].Parameter = _ParameterValues.ParentLimitIdSuffix.ToString();
                parameter[10].Direction = ParameterDirection.Input;
                parameter[10].Value = objReport.Parent_Limit_Id_Suffix;

                parameter[11].Parameter = _ParameterValues.Address1.ToString();
                parameter[11].Direction = ParameterDirection.Input;
                parameter[11].Value = objReport.Address1;

                parameter[12].Parameter = _ParameterValues.Address2.ToString();
                parameter[12].Direction = ParameterDirection.Input;
                parameter[12].Value = objReport.Address2;

                parameter[13].Parameter = _ParameterValues.City.ToString();
                parameter[13].Direction = ParameterDirection.Input;
                parameter[13].Value = objReport.City;

                parameter[14].Parameter = _ParameterValues.State.ToString();
                parameter[14].Direction = ParameterDirection.Input;
                parameter[14].Value = objReport.State;

                parameter[15].Parameter = _ParameterValues.Pin.ToString();
                parameter[15].Direction = ParameterDirection.Input;
                parameter[15].Value = objReport.PIN;

                parameter[16].Parameter = _ParameterValues.PhoneNo.ToString();
                parameter[16].Direction = ParameterDirection.Input;
                parameter[16].Value = objReport.PhoneNo;

                parameter[17].Parameter = _ParameterValues.EmailID.ToString();
                parameter[17].Direction = ParameterDirection.Input;
                parameter[17].Value = objReport.Email1;

                parameter[18].Parameter = _ParameterValues.AccountOpenDate.ToString();
                parameter[18].Direction = ParameterDirection.Input;
                parameter[18].Value = objReport.Account_Opening_Date;

                parameter[19].Parameter = _ParameterValues.AccountCloseDate.ToString();
                parameter[19].Direction = ParameterDirection.Input;
                parameter[19].Value = objReport.Account_Closing_Date;

                parameter[20].Parameter = _ParameterValues.AccountStatus.ToString();
                parameter[20].Direction = ParameterDirection.Input;
                parameter[20].Value = objReport.Account_Status;

                parameter[21].Parameter = _ParameterValues.ProgramLimit.ToString();
                parameter[21].Direction = ParameterDirection.Input;
                parameter[21].Value = objReport.Limit;

                parameter[22].Parameter = _ParameterValues.ProgramSanctionDate.ToString();
                parameter[22].Direction = ParameterDirection.Input;
                parameter[22].Value = objReport.ProgramSanctionDate;

                parameter[23].Parameter = _ParameterValues.ProgramExpiryDate.ToString();
                parameter[23].Direction = ParameterDirection.Input;
                parameter[23].Value = objReport.ProgramExpiryDate;

                parameter[24].Parameter = _ParameterValues.ProgramRenewalDate.ToString();
                parameter[24].Direction = ParameterDirection.Input;
                parameter[24].Value = objReport.ProgramRenewalDate;

                parameter[25].Parameter = _ParameterValues.DocumentationDate.ToString();
                parameter[25].Direction = ParameterDirection.Input;
                parameter[25].Value = objReport.Documentation_Date;

                parameter[26].Parameter = _ParameterValues.Doc1.ToString();
                parameter[26].Direction = ParameterDirection.Input;
                parameter[26].Value = objReport.Doc1;

                parameter[27].Parameter = _ParameterValues.Doc2.ToString();
                parameter[27].Direction = ParameterDirection.Input;
                parameter[27].Value = objReport.Doc2;

                parameter[28].Parameter = _ParameterValues.Doc3.ToString();
                parameter[28].Direction = ParameterDirection.Input;
                parameter[28].Value = objReport.Doc3;

                parameter[29].Parameter = _ParameterValues.Doc4.ToString();
                parameter[29].Direction = ParameterDirection.Input;
                parameter[29].Value = objReport.Doc4;

                parameter[30].Parameter = _ParameterValues.Doc5.ToString();
                parameter[30].Direction = ParameterDirection.Input;
                parameter[30].Value = objReport.Doc5;

                parameter[31].Parameter = _ParameterValues.Doc6.ToString();
                parameter[31].Direction = ParameterDirection.Input;
                parameter[31].Value = objReport.Doc6;

                parameter[32].Parameter = _ParameterValues.Doc7.ToString();
                parameter[32].Direction = ParameterDirection.Input;
                parameter[32].Value = objReport.Doc7;

                parameter[33].Parameter = _ParameterValues.Doc8.ToString();
                parameter[33].Direction = ParameterDirection.Input;
                parameter[33].Value = objReport.Doc8;

                parameter[34].Parameter = _ParameterValues.Doc9.ToString();
                parameter[34].Direction = ParameterDirection.Input;
                parameter[34].Value = objReport.Doc9;

                parameter[35].Parameter = _ParameterValues.Doc10.ToString();
                parameter[35].Direction = ParameterDirection.Input;
                parameter[35].Value = objReport.Doc10;

                parameter[36].Parameter = _ParameterValues.DealerShortName.ToString();
                parameter[36].Direction = ParameterDirection.Input;
                parameter[36].Value = objReport.Short_Name;

                parameter[37].Parameter = _ParameterValues.SolID.ToString();
                parameter[37].Direction = ParameterDirection.Input;
                parameter[37].Value = objReport.Sol_Id;

                parameter[38].Parameter = _ParameterValues.DealerCorporateName.ToString();
                parameter[38].Direction = ParameterDirection.Input;
                parameter[38].Value = objReport.Dealer_Corporate_Name;

                parameter[39].Parameter = _ParameterValues.OutputFileID.ToString();
                parameter[39].Direction = ParameterDirection.Input;
                parameter[39].Value = objReport.FileID;

                parameter[40].Parameter = _ParameterValues.SMEmailID.ToString();
                parameter[40].Direction = ParameterDirection.Input;
                parameter[40].Value = objReport.SM_Email;

                parameter[41].Parameter = _ParameterValues.NameOfSM.ToString();
                parameter[41].Direction = ParameterDirection.Input;
                parameter[41].Value = objReport.SM_Name;

                parameter[42].Parameter = _ParameterValues.NameOfCRM.ToString();
                parameter[42].Direction = ParameterDirection.Input;
                parameter[42].Value = objReport.CRM_Name;

                parameter[43].Parameter = _ParameterValues.CreditTenor.ToString();
                parameter[43].Direction = ParameterDirection.Input;
                parameter[43].Value = objReport.Tenor;

                parameter[44].Parameter = _ParameterValues.CategoryCode.ToString();
                parameter[44].Direction = ParameterDirection.Input;
                parameter[44].Value = objReport.Category_Code;

                parameter[45].Parameter = _ParameterValues.RateCode.ToString();
                parameter[45].Direction = ParameterDirection.Input;
                parameter[45].Value = objReport.Rate_Code;

                parameter[46].Parameter = _ParameterValues.FixedRateCode.ToString();
                parameter[46].Direction = ParameterDirection.Input;
                parameter[46].Value = objReport.Fixed_Rate_Code;

                parameter[47].Parameter = _ParameterValues.CureCode.ToString();
                parameter[47].Direction = ParameterDirection.Input;
                parameter[47].Value = objReport.Cure_Code;

                parameter[48].Parameter = _ParameterValues.PenalCode.ToString();
                parameter[48].Direction = ParameterDirection.Input;
                parameter[48].Value = objReport.Penal_Code;

                parameter[49].Parameter = _ParameterValues.MinimumCode.ToString();
                parameter[49].Direction = ParameterDirection.Input;
                parameter[49].Value = objReport.Minimum_Code;

                parameter[50].Parameter = _ParameterValues.MaximumCode.ToString();
                parameter[50].Direction = ParameterDirection.Input;
                parameter[50].Value = objReport.Maximum_Code;

                parameter[51].Parameter = _ParameterValues.ContactPerson.ToString();
                parameter[51].Direction = ParameterDirection.Input;
                parameter[51].Value = objReport.Contact_Person;

                parameter[52].Parameter = _ParameterValues.ModeOfFunding.ToString();
                parameter[52].Direction = ParameterDirection.Input;
                parameter[52].Value = objReport.Mode_Of_Funding_Flag;

                parameter[53].Parameter = _ParameterValues.AssetClassification.ToString();
                parameter[53].Direction = ParameterDirection.Input;
                parameter[53].Value = objReport.Asset_Classification;

                parameter[54].Parameter = _ParameterValues.CreatedThroughChannel.ToString();
                parameter[54].Direction = ParameterDirection.Input;
                parameter[54].Value = objReport.CreatedThroughChannel;

                parameter[55].Parameter = _ParameterValues.ReturnFlag.ToString();
                parameter[55].Direction = ParameterDirection.Output;
                parameter[55].Value = "";

                _objSQLParameter = new SqlParameter[56];

                _objSQLParameter = generateSQLParameter(parameter);

                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, "usp_CorporateDealerTempAdd", 1000, _objSQLParameter);

                entityReport.Message = _objSQLParameter[55].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }
        }

        public void InsertUploadFileDetails(UploadFile uploadfile, string token)
        {
            string strUploadFileName, strUploadType = "", strCreatedBy;
            string _strUSPName = "usp_UploadServiceDetailsAdd";

            strUploadFileName = "Service_" + token;
            strUploadType = "CD";
            strCreatedBy = "Service";

            _objConn = con.GetConnection();

            UploadFile objReport;

            objReport = (UploadFile)uploadfile;

            CustomSQLParameter[] parameter = new CustomSQLParameter[6];

            parameter[0].Parameter = _ParameterValues.UploadFileName.ToString();
            parameter[0].Value = strUploadFileName;
            parameter[0].Direction = ParameterDirection.Input;

            parameter[1].Parameter = _ParameterValues.UploadFileType.ToString();
            parameter[1].Value = strUploadType;
            parameter[1].Direction = ParameterDirection.Input;

            parameter[2].Parameter = _ParameterValues.CreatedBy.ToString();
            parameter[2].Value = strCreatedBy;
            parameter[2].Direction = ParameterDirection.Input;

            parameter[3].Parameter = _ParameterValues.CreatedOn.ToString();
            parameter[3].Direction = ParameterDirection.Output;

            parameter[4].Parameter = _ParameterValues.OutputFileID.ToString();
            parameter[4].Direction = ParameterDirection.Output;

            parameter[5].Parameter = _ParameterValues.ReturnFlag.ToString();
            parameter[5].Direction = ParameterDirection.Output;

            SqlParameter[] _objSQLParameter = new SqlParameter[6];
            _objSQLParameter = generateSQLParameter(parameter);

            try
            {
                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, _strUSPName, _objSQLParameter);

                uploadfile.Message = _objSQLParameter[5].Value.ToString();
                uploadfile.Id = _objSQLParameter[4].Value.ToString();
                uploadfile.CreatedOn = _objSQLParameter[3].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;
            }
        }

        public void InsertIntoCorporateDealer(UploadFile uploadfile)     // CorporateDealer
        {
            CustomSQLParameter[] parameter = new CustomSQLParameter[7];
            string _strUSPName = "usp_CorporateDealerServiceUploadValidate";

            parameter[0].Parameter = _ParameterValues.OutputFileID.ToString();
            parameter[0].Value = uploadfile.Id;
            parameter[0].Direction = ParameterDirection.Input;

            parameter[1].Parameter = _ParameterValues.CreatedBy.ToString();
            parameter[1].Value = uploadfile.CreatedBy;
            parameter[1].Direction = ParameterDirection.Input;

            parameter[2].Parameter = _ParameterValues.CreatedOn.ToString();
            parameter[2].Value = uploadfile.CreatedOn;
            parameter[2].Direction = ParameterDirection.Input;

            parameter[3].Parameter = _ParameterValues.SuccessRecords.ToString();
            parameter[3].Direction = ParameterDirection.Output;

            parameter[4].Parameter = _ParameterValues.FailureRecords.ToString();
            parameter[4].Direction = ParameterDirection.Output;

            parameter[5].Parameter = _ParameterValues.TotalRecords.ToString();
            parameter[5].Direction = ParameterDirection.Output;

            parameter[6].Parameter = _ParameterValues.ReturnFlag.ToString();
            parameter[6].Direction = ParameterDirection.Output;

            SqlParameter[] _objSQLParameter = new SqlParameter[7];
            _objSQLParameter = generateSQLParameter(parameter);

            try
            {
                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, _strUSPName, COMMANDTIMEOUT, _objSQLParameter);
                uploadfile.Message = _objSQLParameter[6].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;
            }

        }

        public void getCorporateDealerError(Entity.Dealer entityReport)
        {
            DataSet dsReport = new DataSet();

            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();//entityReport.ConnectionString

                Dealer objReport;

                objReport = (Dealer)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[2];

                parameter[0].Parameter = _ParameterValues.AccountNo.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.Account_No;

                parameter[1].Parameter = _ParameterValues.ErrorMessage.ToString();
                parameter[1].Direction = ParameterDirection.Output;
                parameter[1].Value = "";

                _objSQLParameter = new SqlParameter[2];

                _objSQLParameter = generateSQLParameter(parameter);

                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, "usp_CorporateDealerErrorView", 1000, _objSQLParameter);

                entityReport.Message = _objSQLParameter[1].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }
        }

        public void IsValidAccountNo(Entity.Dealer entityReport)
        {
            DataSet dsReport = new DataSet();

            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();//entityReport.ConnectionString

                Dealer objReport;

                objReport = (Dealer)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[2];

                parameter[0].Parameter = _ParameterValues.AccountNo.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.Account_No;

                parameter[1].Parameter = _ParameterValues.ReturnFlag.ToString();
                parameter[1].Direction = ParameterDirection.Output;
                parameter[1].Value = "";

                _objSQLParameter = new SqlParameter[2];

                _objSQLParameter = generateSQLParameter(parameter);

                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, "usp_IsValidAccountNo", 1000, _objSQLParameter);

                entityReport.Message = _objSQLParameter[1].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }
        }
    }
}
