using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using ICICIInfotechLtd.Ibank.CFS.DAL.Interface;
using ICICIInfotechLtd.Ibank.CFS.Entity;
using ICICIInfotechLtd.Ibank.CFS.Entity.Interface;
using Microsoft.ApplicationBlocks.Data;  

namespace ICICIInfotechLtd.Ibank.CFS.DAL
{
	/// <summary>
	/// Summary description for DALApplicationException.
	/// </summary>
	public class DALApplicationException:IDALEntity	
	{
		private SqlConnection _objConn;
        DFSConnection con = new DFSConnection();

		public DALApplicationException()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Generate SQL Parameter

		//Enum to define codes for all parameters. 
		enum _ParameterValues
		{ 			
			ExceptionCode = 0,
			BaseException = 1,
			InnerException = 2,
			ExceptionMessage = 3,
			Source = 4,
			StackTrace = 5,
			TargetSite = 6,
			SourceClass = 7,
			SourceFunction = 8,
			CreatedBy = 9
		};	

		//General function which accepts ractangle array of string and returns array of SqlParameter
		public SqlParameter[] generateSQLParameter(string[,] parameter)
		{
			int intParaLen = parameter.GetLength(0);

			SqlParameter[] objSQLParameter = new SqlParameter[intParaLen];

			for(int i=0; i<intParaLen; i++ )
			{
				if(parameter[i,0] == _ParameterValues.ExceptionCode.ToString())	//ExceptionCode = 0
				{
					objSQLParameter[i] = new SqlParameter("@i_strExceptionCode", SqlDbType.VarChar);	
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.BaseException.ToString())	//BaseException = 1
				{
					objSQLParameter[i] = new SqlParameter("@i_strBaseException", SqlDbType.VarChar);	
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.InnerException.ToString())	//InnerException = 2
				{
					objSQLParameter[i] = new SqlParameter("@i_strInnerException", SqlDbType.VarChar);	
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}
				
				if(parameter[i,0] == _ParameterValues.ExceptionMessage.ToString())	//ExceptionMessage = 3
				{
					objSQLParameter[i] = new SqlParameter("@i_strMessage", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.Source.ToString())	//Source = 4
				{
					objSQLParameter[i] = new SqlParameter("@i_strSource", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.StackTrace.ToString())	//StackTrace = 5
				{
					objSQLParameter[i] = new SqlParameter("@i_strStackTrace", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.TargetSite.ToString())	//TargetSite = 6
				{
					objSQLParameter[i] = new SqlParameter("@i_strTargetSite", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.SourceClass.ToString())	//SourceClass = 7
				{
					objSQLParameter[i] = new SqlParameter("@i_strSourceClass", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.SourceFunction.ToString())	//SourceFunction = 8
				{
					objSQLParameter[i] = new SqlParameter("@i_strSourceFunction", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];			
				}

				if(parameter[i,0] == _ParameterValues.CreatedBy.ToString())	//CreatedBy = 9
				{
					objSQLParameter[i] = new SqlParameter("@i_strCreatedBy", SqlDbType.VarChar);
					objSQLParameter[i].Direction = ParameterDirection.Input;
					objSQLParameter[i].Value = parameter[i,1];	
				}
			}

			return objSQLParameter;
		}

		#endregion

		#region IDALEntity Members

		public void getEntity(IEntity entity)
		{
			// TODO:  Add DALApplicationException.getEntity implementation
		}

		public ArrayList getEntityList(IEntity entity)
		{
			// TODO:  Add DALApplicationException.getEntityList implementation
			return null;
		}

		public void addEntity(IEntity entity)
		{
			// TODO:  Add DALApplicationException.addEntity implementation
			SqlParameter[] _objSQLParameter;
			try
			{	
				ExceptionEntity _objException;
				_objException = (ExceptionEntity)entity;

				if(_objException.ConnectionString == "")
					_objConn = con.GetConnection();
				else
					_objConn = con.GetConnection(_objException.ConnectionString);

				string[,] parameter = new string[10,2];
				parameter[0,0] = _ParameterValues.ExceptionCode.ToString();
				parameter[0,1] = _objException.ExceptionCode;

				parameter[1,0] = _ParameterValues.BaseException.ToString();
				parameter[1,1] = _objException.BaseException;

				parameter[2,0] = _ParameterValues.InnerException.ToString();
				parameter[2,1] = _objException.InnerException;

				parameter[3,0] = _ParameterValues.ExceptionMessage.ToString();
				parameter[3,1] = _objException.ExceptionMessage;

				parameter[4,0] = _ParameterValues.Source.ToString();
				parameter[4,1] = _objException.Source;

				parameter[5,0] = _ParameterValues.StackTrace.ToString();
				parameter[5,1] = _objException.StackTrace;

				parameter[6,0] = _ParameterValues.TargetSite.ToString();
				parameter[6,1] = _objException.TargetSite;

				parameter[7,0] = _ParameterValues.SourceClass.ToString();
				parameter[7,1] = _objException.SourceClass;

				parameter[8,0] = _ParameterValues.SourceFunction.ToString();
				parameter[8,1] = _objException.SourceFunction;

				parameter[9,0] = _ParameterValues.CreatedBy.ToString();
				parameter[9,1] = _objException.CreatedBy;

				_objSQLParameter = new SqlParameter[10];
				_objSQLParameter = generateSQLParameter(parameter);
			  				
				SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, "usp_ApplicationExceptionAdd", _objSQLParameter);	
			}
			finally
			{		
				_objSQLParameter = null;
				con.CloseConnection(_objConn);
			}
		}

		public void updateEntity(IEntity entity)
		{
			// TODO:  Add DALApplicationException.updateEntity implementation
		}

		public void updateStatus(IEntity entity)
		{
			// TODO:  Add DALApplicationException.updateStatus implementation
		}

		#endregion
	}
}
