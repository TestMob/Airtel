﻿using System;
using System.Data;
using System.Data.SqlClient;
using ICICIInfotechLtd.Ibank.CFS.Entity;
using ICICIInfotechLtd.Ibank.CFS.DAL;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;

namespace ICICIInfotechLtd.Ibank.CFS.DAL
{
    /// <summary>
    /// Summary description for DALRequestLog.
    /// </summary>
    public class DALRequestLog
    {
        SqlConnection _objConn;
        DFSConnection con = new DFSConnection();

        public DALRequestLog()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Generate SQL Parameter

        //Enum to define codes for all parameters. 
        enum _ParameterValues
        {
            LogID = 0,
            UserToken,
            RequestData,
            ResponseData,
            IPAddress,
            ReturnFlag,
            New1,
            New2,
            RequestChannel
        };

        private SqlParameter[] generateSQLParameter(CustomSQLParameter[] parameter)
        {
            int intParaLen = parameter.GetLength(0);

            SqlParameter[] objSQLParameter = new SqlParameter[intParaLen];

            for (int i = 0; i < intParaLen; i++)
            {

                if (parameter[i].Parameter == _ParameterValues.LogID.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strLogID", SqlDbType.VarChar, 20);

                if (parameter[i].Parameter == _ParameterValues.UserToken.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strTokenNo", SqlDbType.VarChar, 20);

                if (parameter[i].Parameter == _ParameterValues.RequestData.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strRequestData", SqlDbType.VarChar);

                if (parameter[i].Parameter == _ParameterValues.ResponseData.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strResponseData", SqlDbType.VarChar);

                if (parameter[i].Parameter == _ParameterValues.IPAddress.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strIPAddress", SqlDbType.VarChar, 50);

                if (parameter[i].Parameter == _ParameterValues.ReturnFlag.ToString())
                    objSQLParameter[i] = new SqlParameter("@o_strReturnFlag", SqlDbType.Char, 1);

                if (parameter[i].Parameter == _ParameterValues.RequestChannel.ToString())
                    objSQLParameter[i] = new SqlParameter("@i_strRequestChannel", SqlDbType.VarChar, 30);
                
                //--------------------------------------------------\\
                objSQLParameter[i].Direction = parameter[i].Direction;
                if (parameter[i].Direction == ParameterDirection.Input)
                    objSQLParameter[i].Value = parameter[i].Value;
                //--------------------------------------------------\\
            }

            return objSQLParameter;
        }

        #endregion

        public void AddRequestLog(Entity.RequestLog entityReport)
        {
            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();

                RequestLog objReport;

                objReport = (RequestLog)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[6];

                parameter[0].Parameter = _ParameterValues.UserToken.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.TokenNo;

                parameter[1].Parameter = _ParameterValues.RequestData.ToString();
                parameter[1].Direction = ParameterDirection.Input;
                parameter[1].Value = objReport.RequestData;

                parameter[2].Parameter = _ParameterValues.ResponseData.ToString();
                parameter[2].Direction = ParameterDirection.Input;
                parameter[2].Value = objReport.ResponseData;

                parameter[3].Parameter = _ParameterValues.IPAddress.ToString();
                parameter[3].Direction = ParameterDirection.Input;
                parameter[3].Value = objReport.IPAddress;

                parameter[4].Parameter = _ParameterValues.RequestChannel.ToString();
                parameter[4].Direction = ParameterDirection.Input;
                parameter[4].Value = objReport.RequestChannel;

                parameter[5].Parameter = _ParameterValues.ReturnFlag.ToString();
                parameter[5].Direction = ParameterDirection.Output;
                parameter[5].Value = "";

                _objSQLParameter = new SqlParameter[6];

                _objSQLParameter = generateSQLParameter(parameter);

                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, "usp_RequestLogAdd", 1000, _objSQLParameter);

                entityReport.Message = _objSQLParameter[5].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }
        }

        public void IsValidTokenNo(Entity.RequestLog entityReport)
        {
            SqlParameter[] _objSQLParameter;

            try
            {
                _objConn = con.GetConnection();//entityReport.ConnectionString

                RequestLog objReport;

                objReport = (RequestLog)entityReport;

                CustomSQLParameter[] parameter = new CustomSQLParameter[2];

                parameter[0].Parameter = _ParameterValues.UserToken.ToString();
                parameter[0].Direction = ParameterDirection.Input;
                parameter[0].Value = objReport.TokenNo;

                parameter[1].Parameter = _ParameterValues.ReturnFlag.ToString();
                parameter[1].Direction = ParameterDirection.Output;
                parameter[1].Value = "";

                _objSQLParameter = new SqlParameter[2];

                _objSQLParameter = generateSQLParameter(parameter);

                SqlHelper.ExecuteNonQuery(_objConn, CommandType.StoredProcedure, "usp_IsValidTokenNo", 1000, _objSQLParameter);

                entityReport.Message = _objSQLParameter[1].Value.ToString();
            }
            finally
            {
                _objSQLParameter = null;

                con.CloseConnection(_objConn);
            }
        }
    }
}
