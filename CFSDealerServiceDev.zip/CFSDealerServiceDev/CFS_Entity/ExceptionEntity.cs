using System;

namespace ICICIInfotechLtd.Ibank.CFS.Entity
{
	/// <summary>
	/// Summary description for ExceptionEntity.
	/// </summary>
	public class ExceptionEntity:CommonMasterAttri
	{
		private string _ExceptionCode;
		private string _BaseException;
		private string _InnerException;
		private string _ExceptionMessage;
		private string _Source;
		private string _StackTrace;
		private string _TargetSite;
		private string _SourceClass;
		private string _SourceFunction;
		private string _ConnectionString;

		public ExceptionEntity()
		{
			//
			// TODO: Add constructor logic here
			//
			_ExceptionCode = "";
			_BaseException = "";
			_InnerException = "";
			_ExceptionMessage = "";
			_Source = "";
			_StackTrace = "";
			_TargetSite = "";
			_SourceClass = "";
			_SourceFunction = "";
			_ConnectionString = "";
		}

		public string ExceptionCode
		{
			get
			{
				return _ExceptionCode;
			}
			set
			{
				_ExceptionCode = value;
			}
		}

		public string BaseException
		{
			get
			{
				return _BaseException;
			}
			set
			{
				_BaseException = value;
			}
		}

		public string InnerException
		{
			get
			{
				return _InnerException;
			}
			set
			{
				_InnerException = value;
			}
		}

		public string ExceptionMessage
		{
			get
			{
				return _ExceptionMessage;
			}
			set
			{
				_ExceptionMessage = value;
			}
		}

		public string Source
		{
			get
			{
				return _Source;
			}
			set
			{
				_Source = value;
			}
		}

		public string StackTrace
		{
			get
			{
				return _StackTrace;
			}
			set
			{
				_StackTrace = value;
			}
		}

		public string TargetSite
		{
			get
			{
				return _TargetSite;
			}
			set
			{
				_TargetSite = value;
			}
		}

		public string SourceClass
		{
			get
			{
				return _SourceClass;
			}
			set
			{
				_SourceClass = value;
			}
		}

		public string SourceFunction
		{
			get
			{
				return _SourceFunction;
			}
			set
			{
				_SourceFunction = value;
			}
		}

		public string ConnectionString
		{
			get
			{
				return _ConnectionString;
			}
			set
			{
				_ConnectionString = value;
			}
		}		
	}
}
