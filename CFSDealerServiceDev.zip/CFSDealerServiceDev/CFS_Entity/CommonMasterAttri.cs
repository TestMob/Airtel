using System;
using ICICIInfotechLtd.Ibank.CFS.Entity.Interface; 

namespace ICICIInfotechLtd.Ibank.CFS.Entity
{
	/// <summary>
	/// Summary description for CommonMasterAttri.
	/// </summary>
	public class CommonMasterAttri:IEntity
	{
		private string _Id;
		private string _SrNo;
		private string _CreatedBy;
		private string _CreatedOn;
		private string _ModifiedBy;
		private string _ModifiedOn;
		private string _Message;
		private string _PageFlag;

		public CommonMasterAttri()
		{
			_Id="";
			_SrNo="";
			_CreatedBy="";
			_CreatedOn="";
			_ModifiedBy="";
			_ModifiedOn="";
			_Message="";
			_PageFlag="";
		}


		public string Id
		{
			get
			{
				return _Id;
			}
			set 
			{
				_Id = value.Trim();
			}
		}

		public string SrNo
		{
			get
			{
				return _SrNo;
			}
			set 
			{
				_SrNo = value.Trim();
			}
		}


		public string CreatedBy
		{
			get
			{
				return _CreatedBy;
			}
			set 
			{
				_CreatedBy = value.Trim();
			}
		}

		public string CreatedOn
		{
			get
			{
				return _CreatedOn;
			}
			set 
			{
				_CreatedOn = value.Trim();
			}
		}

		public string ModifiedBy
		{
			get
			{
				return _ModifiedBy;
			}
			set 
			{
				_ModifiedBy = value.Trim();
			}
		}

		public string ModifiedOn
		{
			get
			{
				return _ModifiedOn;
			}
			set 
			{
				_ModifiedOn = value.Trim();
			}
		}

		public string Message
		{
			get
			{
				return _Message;
			}
			set 
			{
				_Message = value.Trim();
			}
		}

		public string PageFlag
		{
			get
			{
				return _PageFlag;
			}
			set 
			{
				_PageFlag = value.Trim();
			}
		}
	}
}
