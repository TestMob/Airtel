using System;

namespace ICICIInfotechLtd.Ibank.CFS.Entity
{
	/// <summary>
	/// Summary description for CommonTypes.
	/// </summary>
	/// 
	public enum UploadType
	{
		CorporateDealer = 1, 
		Transaction = 2, 
		TOD = 3
	}

	public enum Status
	{
		Rejected=1,	// "R"
		Approved=2,	// "A" 
		Pending=3	// "P" 
	}

	public enum FundingModeStatus
	{
		Infinity=1, // "I"
		Manual=2,	// "M"
		Cheque=3	// "C"
	}

	public enum Classification
	{
		VendorOverdraftProgram=1, // "V"
		DealerOverdraftProgram=2  // "D"	
	}

	public enum MarkOff
	{
		NormalDisbursement=1,	// "N"
		Interest=2,				// "I"	
		ValueDate=3,			// "V"
		Fees					// "F"	
	}

	public enum RateCode
	{
		IBAR=1,	
		PLR=2,
		FixedRate=3
	}

	public struct CustomSQLParameter
	{
		public string Parameter;
		public System.Data.ParameterDirection Direction;
		public string Value;
	}
}
