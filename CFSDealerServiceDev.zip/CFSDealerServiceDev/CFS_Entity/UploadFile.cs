using System;

namespace ICICIInfotechLtd.Ibank.CFS.Entity
{
	/// <summary>
	/// Summary description for Upload.
	/// </summary>
	public class UploadFile:CommonMasterAttri
	{
		private string	_FileName;
		private UploadType _uploadtype;
        private string	_XMLString;
		private string	_uiphysicalpath;
		//private string	_errorfilephysicalpath;
		private string	_filecolumnseperator;
		private int		_filetotalcolumns;
		private string	_errorfilehtml;
		private int		_errorfilecount;
		private Int64	_successrecords;
		private Int64	_failurerecords;
		private Int64	_totalrecords;
		private string _isuploadactivated;

		public UploadFile()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public string XMLString
		{
			get
			{
				return _XMLString;
			}
			set
			{
				_XMLString = value.Trim(); 
			}
		}		

		public string FileName
		{
			get
			{
				return _FileName;
			}
			set
			{
				_FileName = value.Trim();
			}
		}

		public UploadType uploadtype
		{
			get
			{
				return _uploadtype;
			}
			set
			{
				_uploadtype = value;
			}
		}

		public string UIPhysicalPath
		{
			get
			{
				return _uiphysicalpath;
			}
			set
			{
				_uiphysicalpath = value;
			}
		}
/*
		public string ErrorFilePhysicalPath
		{
			get
			{
				return _errorfilephysicalpath;
			}
			set
			{
				_errorfilephysicalpath = value;
			}
		}
*/
		public string ErrorFileHTML
		{
			get
			{
				return _errorfilehtml;
			}
			set
			{
				_errorfilehtml = value;
			}
		}

		public int ErrorFileCount
		{
			get
			{
				return _errorfilecount;
			}
			set
			{
				_errorfilecount = value;
			}
		}

		public string FileColumnSeperator
		{
			get
			{
				return _filecolumnseperator;
			}
			set
			{
				_filecolumnseperator = value;
			}
		}

		public int FileTotalColumns
		{
			get
			{
				return _filetotalcolumns;
			}
			set
			{
				_filetotalcolumns = value;
			}
		}

		public Int64 SuccessRecords
		{
			get
			{
				return _successrecords;
			}
			set
			{
				_successrecords = value;
			}
		}

		public Int64 FailureRecords
		{
			get
			{
				return _failurerecords;
			}
			set
			{
				_failurerecords = value;
			}
		}

		public Int64 TotalRecords
		{
			get
			{
				return _totalrecords;
			}
			set
			{
				_totalrecords = value;
			}
		}

		public string IsUploadActivated
		{
			get
			{
				return _isuploadactivated;
			}
			set
			{
				_isuploadactivated = value;
			}
		}
	}
}
