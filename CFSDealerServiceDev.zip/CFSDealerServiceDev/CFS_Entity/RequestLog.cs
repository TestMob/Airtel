﻿using System;

namespace ICICIInfotechLtd.Ibank.CFS.Entity
{
    /// <summary>
    /// Summary description for RequestLog.
    /// </summary>
    public class RequestLog
    {
        private int _LogID;
        private string _Token_No;
        private string _Request_Data;
        private string _Response_Data;
        private string _IP_Address;
        private string _message;
        private string _Request_Channel;

        public RequestLog()
        {
           
        }

        public int LogID
        {
            get
            {
                return _LogID;
            }
            set
            {
                _LogID = value;
            }
        }

        public string TokenNo
        {
            get
            {
                return _Token_No;
            }
            set
            {
                _Token_No = value.Trim();
            }
        }

        public string RequestData
        {
            get
            {
                return _Request_Data;
            }
            set
            {
                _Request_Data = value.Trim();
            }
        }

        public string ResponseData
        {
            get
            {
                return _Response_Data;
            }
            set
            {
                _Response_Data = value.Trim();
            }
        }

        public string IPAddress
        {
            get
            {
                return _IP_Address;
            }
            set
            {
                _IP_Address = value.Trim();
            }
        }

        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value.Trim();
            }
        }

        public string RequestChannel
        {
            get
            {
                return _Request_Channel;
            }
            set
            {
                _Request_Channel = value.Trim();
            }
        }
    }
}
