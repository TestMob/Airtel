using System;

namespace ICICIInfotechLtd.Ibank.CFS.Entity.Interface
{
	/// <summary>
	/// Summary description for IEntity.
	/// </summary>
	public interface IEntity
	{

		string Id
		{
			get;
			set;
		}

		string SrNo
		{
			get;
			set;
		}

		string CreatedBy
		{
			get;
			set;
		}

		string CreatedOn
		{
			get;
			set;
		}

		string ModifiedBy
		{
			get;
			set;
		}

		string ModifiedOn
		{
			get;
			set;
		}

		string Message
		{
			get;
			set;
		}
	}
}
