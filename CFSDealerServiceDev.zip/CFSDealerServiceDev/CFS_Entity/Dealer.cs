using System;

namespace ICICIInfotechLtd.Ibank.CFS.Entity
{
    /// <summary>
    /// Summary description for Dealer.
    /// </summary>
    public class Dealer
    {
        private string _strConnStr;
        private string _strStartupPath;
        private string _strEmailFrom;
        private string _DealerID;
        private string _From_Date;
        private string _To_Date;

        private string _Dealer_Name;
        private string _Account_No;
        private string _Customer_Id;
        private string _Sanction_Limit;
        private string _Peak_Limit;
        private string _Peak_Tenor;
        private string _Tenor;
        private int _CorpId;
        private string _Overdue_BeyondCure;
        private string _Dealer_Corporate_Name;

        private string _Corporate_Id;
        private string _Corporate_Name;
        private string _Short_Name;
        private string _Limit_Id_Prefix;
        private string _Limit_Id_Suffix;
        private string _CRM_Name;
        private string _Account_Status;
        private string _Account_Opening_Date;
        private string _Account_Closing_Date;
        private string _Documentation_Date;
        private string _SM_Email;
        private string _Sol_Id;
        private string _Asset_Classification;
        private string _Category_Code;
        private string _Rate_Code;
        private string _Fixed_Rate_Code;
        private string _Penal_Code;
        private string _Minimum_Code;
        private string _Maximum_Code;
        private string _No_Of_Peak_Uses;
        private string _Peak_Interest;
        private string _Peak_Effective_From;
        private string _Peak_Effective_To;
        private string _TOD_Code;
        private string _TOD_Margin;
        private string _TOD_Calculation;
        private string _Mode_Of_Call;
        private string _Report_Format;
        private string _Name;
        private string _Parent_Limit_Id_Prefix;
        private string _Parent_Limit_Id_Suffix;
        private string _Contact_Person;
        private string _Limit;
        private string _Sanction_date;
        private string _Expiry_Date;
        private string _Renewal_Date;
        private string _Cure_Code;
        private string _SM_Name;
        private string _Mode_Of_Funding_Flag;
        private string _Mode_Of_Funding_Desc;
        private string _Classification_Flag;
        private string _Classification_Desc;
        private string _Email1;
        private string _Email2;
        private string _Email3;
        private string _Email4;
        private string _Email5;
        private string _Email6;
        private string _Rating;
        private string _Address1;
        private string _Address2;
        private string _City;
        private string _PIN;
        private string _State;
        private string _Country;
        private string _PhoneNo;
        private string _Doc1;
        private string _Doc2;
        private string _Doc3;
        private string _Doc4;
        private string _Doc5;
        private string _Doc6;
        private string _Doc7;
        private string _Doc8;
        private string _Doc9;
        private string _Doc10;
        private string _Program_Sanction_Date;
        private string _Program_Expiry_Date;
        private string _Program_Renewal_Date;
        private string _File_ID;
        private string _Message;
        private string _Created_Through_Channel;

        public Dealer()
        {
            _strConnStr = "";
            _strStartupPath = "";
            _strEmailFrom = "";
        }

        public static string formatDate(DateTime date, int formatType)
        {
            string format = ""; //formats are case sensitive

            if (date.ToString().Trim() == "") { return (""); }

            if (formatType == 1)
                format = "dd-MMM-yyyy";
            else if (formatType == 2)
                format = "dd-MMM-yyyy HH:mm:ss";

            return date.ToString(format);
        }

        public string StartupPath
        {
            get
            {
                return _strStartupPath;
            }
            set
            {
                _strStartupPath = value.Trim();
            }
        }

        public string ConnectionString
        {
            get
            {
                return _strConnStr;
            }
            set
            {
                _strConnStr = value.Trim();
            }
        }

        public string EmailFrom
        {
            get
            {
                return _strEmailFrom.Trim();
            }
            set
            {
                _strEmailFrom = value;
            }
        }

        public string DealerID
        {
            get
            {
                return _DealerID.Trim();
            }
            set
            {
                _DealerID = value;
            }
        }

        public string From_Date
        {
            get
            {
                if (_From_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _From_Date;
                }
            }
            set
            {
                _From_Date = value.Trim();
            }
        }

        public string To_Date
        {
            get
            {
                if (_To_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _To_Date;
                }
            }
            set
            {
                _To_Date = value.Trim();
            }
        }

        public string Account_No
        {
            get
            {
                if (_Account_No.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Account_No.Trim();
                }
            }
            set
            {
                _Account_No = value.Trim();
            }
        }

        public string Customer_Id
        {
            get
            {
                if (_Customer_Id.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Customer_Id.Trim();
                }
            }
            set
            {
                _Customer_Id = value.Trim();
            }
        }

        public string Sanction_Limit
        {
            get
            {
                if (_Sanction_Limit.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Sanction_Limit.Trim();
                }
            }
            set
            {
                _Sanction_Limit = value.Trim();
            }
        }

        public string Peak_Limit
        {
            get
            {
                if (_Peak_Limit.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Peak_Limit.Trim();
                }
            }
            set
            {
                _Peak_Limit = value.Trim();
            }
        }

        public string Peak_Tenor
        {
            get
            {
                if (_Peak_Tenor.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Peak_Tenor.Trim();
                }
            }
            set
            {
                _Peak_Tenor = value.Trim();
            }
        }

        public string Tenor
        {
            get
            {
                if (_Tenor.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Tenor.Trim();
                }
            }
            set
            {
                _Tenor = value.Trim();
            }
        }


        public string Overdue_BeyondCure
        {
            get
            {
                if (_Overdue_BeyondCure.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Overdue_BeyondCure.Trim();
                }
            }
            set
            {
                _Overdue_BeyondCure = value.Trim();
            }
        }

        //added on 25-09-2017
        public string Dealer_Corporate_Name
        {
            get
            {
                if (_Dealer_Corporate_Name.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Dealer_Corporate_Name.Trim();
                }
            }
            set
            {
                _Dealer_Corporate_Name = value.Trim();
            }
        }

        public string Dealer_Name
        {
            get
            {
                if (_Dealer_Name.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return _Dealer_Name.Trim();
                }
            }
            set
            {
                _Dealer_Name = value.Trim();
            }
        }

        public int CorpId
        {
            get
            {
                return _CorpId;
            }
            set
            {
                _CorpId = value;
            }
        }

        public string Corporate_Id
        {
            get
            {
                return _Corporate_Id;
            }
            set
            {
                _Corporate_Id = value.Trim();
            }
        }

        public string Corporate_Name
        {
            get
            {
                return _Corporate_Name;
            }
            set
            {
                _Corporate_Name = value.Trim();
            }
        }

        public string Short_Name
        {
            get
            {
                return _Short_Name;
            }
            set
            {
                _Short_Name = value.Trim();
            }
        }

        public string Limit_Id_Prefix
        {
            get
            {
                return _Limit_Id_Prefix;
            }
            set
            {
                _Limit_Id_Prefix = value.Trim();
            }
        }

        public string Limit_Id_Suffix
        {
            get
            {
                return _Limit_Id_Suffix;
            }
            set
            {
                _Limit_Id_Suffix = value.Trim();
            }
        }

        public string CRM_Name
        {
            get
            {
                return _CRM_Name;
            }
            set
            {
                _CRM_Name = value.Trim();
            }
        }

        public string Account_Status
        {
            get
            {
                return _Account_Status;
            }
            set
            {
                _Account_Status = value.Trim();
            }
        }

        public string Account_Opening_Date
        {
            get
            {
                if (_Account_Opening_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Account_Opening_Date), 1);

                    return _Account_Opening_Date.Trim();
                }
            }
            set
            {
                _Account_Opening_Date = value.Trim();
            }
        }

        public string Account_Closing_Date
        {
            get
            {
                if (_Account_Closing_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Account_Closing_Date), 1);

                    return _Account_Closing_Date.Trim();
                }
            }
            set
            {
                _Account_Closing_Date = value.Trim();
            }
        }

        public string Documentation_Date
        {
            get
            {
                if (_Documentation_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Documentation_Date), 1);

                    return _Documentation_Date.Trim();
                }
            }
            set
            {
                _Documentation_Date = value.Trim();
            }
        }

        public string SM_Email
        {
            get
            {
                return _SM_Email;
            }
            set
            {
                _SM_Email = value.Trim();
            }
        }

        public string Asset_Classification
        {
            get
            {
                return _Asset_Classification;
            }
            set
            {
                _Asset_Classification = value.Trim();
            }
        }

        public string Category_Code
        {
            get
            {
                return _Category_Code;
            }
            set
            {
                _Category_Code = value.Trim();
            }
        }

        public string Rate_Code
        {
            get
            {
                return _Rate_Code;
            }
            set
            {
                _Rate_Code = value.Trim();
            }
        }

        public string Fixed_Rate_Code
        {
            get
            {
                return _Fixed_Rate_Code;
            }
            set
            {
                _Fixed_Rate_Code = value.Trim();
            }
        }

        public string Penal_Code
        {
            get
            {
                return _Penal_Code;
            }
            set
            {
                _Penal_Code = value.Trim();
            }
        }

        public string Minimum_Code
        {
            get
            {
                return _Minimum_Code;
            }
            set
            {
                _Minimum_Code = value.Trim();
            }
        }

        public string Maximum_Code
        {
            get
            {
                return _Maximum_Code;
            }
            set
            {
                _Maximum_Code = value.Trim();
            }
        }

        public string No_Of_Peak_Uses
        {
            get
            {
                return _No_Of_Peak_Uses;
            }
            set
            {
                _No_Of_Peak_Uses = value.Trim();
            }
        }

        public string Peak_Interest
        {
            get
            {
                return _Peak_Interest;
            }
            set
            {
                _Peak_Interest = value.Trim();
            }
        }

        public string Peak_Effective_From
        {
            get
            {
                if (_Peak_Effective_From.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return formatDate(Convert.ToDateTime(_Peak_Effective_From), 1);
                }
            }
            set
            {
                _Peak_Effective_From = value.Trim();
            }
        }

        public string Peak_Effective_To
        {
            get
            {
                if (_Peak_Effective_To.Trim() == "")
                {
                    return "";
                }
                else
                {
                    return formatDate(Convert.ToDateTime(_Peak_Effective_To), 1);
                }
            }
            set
            {
                _Peak_Effective_To = value.Trim();
            }
        }

        public string TOD_Code
        {
            get
            {
                return _TOD_Code;
            }
            set
            {
                _TOD_Code = value.Trim();
            }
        }

        public string TOD_Margin
        {
            get
            {
                return _TOD_Margin;
            }
            set
            {
                _TOD_Margin = value.Trim();
            }
        }

        public string TOD_Calculation
        {
            get
            {
                return _TOD_Calculation;
            }
            set
            {
                _TOD_Calculation = value.Trim();
            }
        }

        public string Mode_Of_Call
        {
            get
            {
                return _Mode_Of_Call;
            }
            set
            {
                _Mode_Of_Call = value.Trim();
            }
        }

        public string Sol_Id
        {
            get
            {
                return _Sol_Id;
            }
            set
            {
                _Sol_Id = value.Trim();
            }
        }

        public string Report_Format
        {
            get
            {
                return _Report_Format;
            }
            set
            {
                _Report_Format = value.Trim();
            }
        }

        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value.Trim();
            }
        }

        public string Parent_Limit_Id_Prefix
        {
            get
            {
                return _Parent_Limit_Id_Prefix;
            }
            set
            {
                _Parent_Limit_Id_Prefix = value.Trim();
            }
        }

        public string Parent_Limit_Id_Suffix
        {
            get
            {
                return _Parent_Limit_Id_Suffix;
            }
            set
            {
                _Parent_Limit_Id_Suffix = value.Trim();
            }
        }

        public string Contact_Person
        {
            get
            {
                return _Contact_Person;
            }
            set
            {
                _Contact_Person = value.Trim();
            }
        }

        public string Limit
        {
            get
            {
                return _Limit;
            }
            set
            {
                _Limit = value.Trim();
            }
        }

        public string Sanction_date
        {
            get
            {
                if (_Sanction_date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Sanction_date), 1);

                    return _Sanction_date.Trim();
                }
            }
            set
            {
                _Sanction_date = value.Trim();
            }
        }

        public string Expiry_Date
        {
            get
            {
                if (_Expiry_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Expiry_Date), 1);

                    return _Expiry_Date.Trim();
                }
            }
            set
            {
                _Expiry_Date = value.Trim();
            }
        }

        public string Renewal_Date
        {
            get
            {
                if (_Renewal_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Renewal_Date), 1);

                    return _Renewal_Date.Trim();
                }
            }
            set
            {
                _Renewal_Date = value.Trim();
            }
        }

        public string Cure_Code
        {
            get
            {
                return _Cure_Code;
            }
            set
            {
                _Cure_Code = value.Trim();
            }
        }

        public string SM_Name
        {
            get
            {
                return _SM_Name;
            }
            set
            {
                _SM_Name = value.Trim();
            }
        }

        public string Mode_Of_Funding_Flag
        {
            get
            {
                return _Mode_Of_Funding_Flag;
            }
            set
            {
                _Mode_Of_Funding_Flag = value.Trim();
            }
        }

        public string Mode_Of_Funding_Desc
        {
            get
            {
                return _Mode_Of_Funding_Desc;
            }
            set
            {
                _Mode_Of_Funding_Desc = value.Trim();
            }
        }

        public string Classification_Flag
        {
            get
            {
                return _Classification_Flag;
            }
            set
            {
                _Classification_Flag = value.Trim();
            }
        }

        public string Classification_Desc
        {
            get
            {
                return _Classification_Desc;
            }
            set
            {
                _Classification_Desc = value.Trim();
            }
        }

        public string Email1
        {
            get
            {
                return _Email1;
            }
            set
            {
                _Email1 = value.Trim();
            }
        }

        public string Email2
        {
            get
            {
                return _Email2;
            }
            set
            {
                _Email2 = value.Trim();
            }
        }

        public string Email3
        {
            get
            {
                return _Email3;
            }
            set
            {
                _Email3 = value.Trim();
            }
        }

        public string Email4
        {
            get
            {
                return _Email4;
            }
            set
            {
                _Email4 = value.Trim();
            }
        }

        public string Email5
        {
            get
            {
                return _Email5;
            }
            set
            {
                _Email5 = value.Trim();
            }
        }

        public string Email6
        {
            get
            {
                return _Email6;
            }
            set
            {
                _Email6 = value.Trim();
            }
        }

        public string Rating
        {
            get
            {
                return _Rating;
            }
            set
            {
                _Rating = value.Trim();
            }
        }

        public string Address1
        {
            get
            {
                return _Address1;
            }
            set
            {
                _Address1 = value.Trim();
            }
        }

        public string Address2
        {
            get
            {
                return _Address2;
            }
            set
            {
                _Address2 = value.Trim();
            }
        }

        public string City
        {
            get
            {
                return _City;
            }
            set
            {
                _City = value.Trim();
            }
        }

        public string PIN
        {
            get
            {
                return _PIN;
            }
            set
            {
                _PIN = value.Trim();
            }
        }

        public string State
        {
            get
            {
                return _State;
            }
            set
            {
                _State = value.Trim();
            }
        }

        public string Country
        {
            get
            {
                return _Country;
            }
            set
            {
                _Country = value.Trim();
            }
        }

        public string PhoneNo
        {
            get
            {
                return _PhoneNo;
            }
            set
            {
                _PhoneNo = value.Trim();
            }
        }

        public string Doc1
        {
            get
            {
                return _Doc1;
            }
            set
            {
                _Doc1 = value.Trim();
            }
        }

        public string Doc2
        {
            get
            {
                return _Doc2;
            }
            set
            {
                _Doc2 = value.Trim();
            }
        }

        public string Doc3
        {
            get
            {
                return _Doc3;
            }
            set
            {
                _Doc3 = value.Trim();
            }
        }

        public string Doc4
        {
            get
            {
                return _Doc4;
            }
            set
            {
                _Doc4 = value.Trim();
            }
        }

        public string Doc5
        {
            get
            {
                return _Doc5;
            }
            set
            {
                _Doc5 = value.Trim();
            }
        }

        public string Doc6
        {
            get
            {
                return _Doc6;
            }
            set
            {
                _Doc6 = value.Trim();
            }
        }

        public string Doc7
        {
            get
            {
                return _Doc7;
            }
            set
            {
                _Doc7 = value.Trim();
            }
        }

        public string Doc8
        {
            get
            {
                return _Doc8;
            }
            set
            {
                _Doc8 = value.Trim();
            }
        }

        public string Doc9
        {
            get
            {
                return _Doc9;
            }
            set
            {
                _Doc9 = value.Trim();
            }
        }

        public string Doc10
        {
            get
            {
                return _Doc10;
            }
            set
            {
                _Doc10 = value.Trim();
            }
        }

        public string ProgramSanctionDate
        {
            get
            {
                if (_Program_Sanction_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Program_Sanction_Date), 1);

                    return _Program_Sanction_Date.Trim();
                }
            }
            set
            {
                _Program_Sanction_Date = value.Trim();
            }
        }

        public string ProgramExpiryDate
        {
            get
            {
                if (_Program_Expiry_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Program_Expiry_Date), 1);

                    return _Program_Expiry_Date.Trim();
                }
            }
            set
            {
                _Program_Expiry_Date = value.Trim();
            }
        }

        public string ProgramRenewalDate
        {
            get
            {
                if (_Program_Renewal_Date.Trim() == "")
                {
                    return "";
                }
                else
                {
                    //return formatDate(Convert.ToDateTime(_Program_Renewal_Date), 1);

                    return _Program_Renewal_Date.Trim();
                }
            }
            set
            {
                _Program_Renewal_Date = value.Trim();
            }
        }

        public string FileID
        {
            get
            {
                return _File_ID;
            }
            set
            {
                _File_ID = value.Trim();
            }
        }

        public string Message
        {
            get
            {
                return _Message;
            }
            set
            {
                _Message = value.Trim();
            }
        }

        public string CreatedThroughChannel
        {
            get
            {
                return _Created_Through_Channel;
            }
            set
            {
                _Created_Through_Channel = value.Trim();
            }
        }

        
    }
}
