USE [CFS]
GO

INSERT INTO [Menu_Master]
           ([MM_Menu_Name]
           ,[MM_Menu_Type]
           ,[MM_Maker_Checker]
           ,[MM_Menu_Order]
           ,[MM_URL_Add]
           ,[MM_URL_View]
           ,[MM_URL_Modify]
           ,[MM_URL_Checker]
           ,[MM_Created_By]
           ,[MM_Created_On]
           ,[MM_Modified_By]
           ,[MM_Modified_On])
     VALUES
           ('ACCOUNTS OPENED THROUGH OTHER CHANNELS',
		   'TR','M', (Select max(MM_menu_order)+1 from Menu_Master where MM_Menu_Type='TR')	
		   ,NULL,
		   'Accounts_From_Other_Channels.aspx',NULL,NULL,'SYSTEM',getdate(),null,	null)
GO


