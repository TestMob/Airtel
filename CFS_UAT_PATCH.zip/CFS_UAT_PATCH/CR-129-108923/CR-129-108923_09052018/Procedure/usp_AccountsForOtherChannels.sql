USE [CFS]
GO
/****** Object:  StoredProcedure [dbo].[usp_AccountsForOtherChannels]    Script Date: 09-05-2018 16:02:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [usp_AccountsForOtherChannels] 
(@i_strAccNo varchar(16), 
@i_strFromDate varchar(20), 
@i_strToDate varchar(20), 
@o_strReturnFlag char output)
AS
BEGIN 
	Set @o_strReturnFlag = 'S'

	If (@i_strAccNo Is Not Null And @i_strAccNo <> '')
	And Exists(Select DM_Account_No From Dealer_Master Where DM_Account_No = @i_strAccNo And DM_Status = 'A'
	And (DM_Created_Channel Is Null Or DM_Created_Channel = '' Or DM_Created_Channel = 'I-CORE'))
	Begin
		Set @o_strReturnFlag = 'E'
		Return
	End

	Select ROW_NUMBER() OVER(Order By D.DM_Account_Open_Date) As 'Sr. No', D.DM_Dealer_Name As 'Name of the Dealer', C.CM_Corporate_Name As 'Name of the Corporate', C.CM_Parent_Limit_Id_Prefix As 'Corporate Limit Node', 
	Convert(varchar, CD.CD_Program_Expiry_Date, 105) As 'Expiry Date of the Corporate Program',
	DD.DD_Dealer_Limit As 'Sanction Amount', Convert(varchar, DD.DD_Sanction_Date, 105) As 'Date of Sanction', 
	Convert(varchar, DD.DD_Expiry_Date, 105) As 'Date of Expiry', DD.DD_Fixed_Rate_Code +  ' : ' + Convert(varchar, F.FRM_Fixed_Rate) As 'Regular Tenor interest rate', 
	DD.DD_Cure_Code +  ' : ' + Convert(varchar, CU.CM_Cure_Rate) As 'Cooling Period interest rate',
	DD.DD_Penal_Code +  ' : ' + Convert(varchar, P.PM_Penal_Rate) As 'Delayed Period interest rate(Default rate)', 
	DD.DD_Tenor As 'Regular Tenor', CM_Cure_Days As 'Cooling Period Tenor', '' as 'Current I-MCLR 6M rate', D.DM_Account_No As 'OD Account Number',
	Upper(D.DM_Created_Channel) As 'Created Through Channel'
	From Corporate_Master C
	Inner Join Dealer_Master D On C.CM_Corporate_Id = D.DM_Corporate_Id
	Inner Join (Select ROW_NUMBER() OVER(PARTITION BY CD_Corporate_Id ORDER BY CD_Corporate_Details_Id Desc) As CD_Row,
	CD_Corporate_Id, CD_Program_Expiry_Date From Corporate_Details Where CD_Status = 'A') CD
	On CD.CD_Corporate_Id = C.CM_Corporate_Id
	Inner Join (Select ROW_NUMBER() OVER(PARTITION BY DD_Dealer_Id ORDER BY DD_Dealer_Details_Id Desc) As DD_Row, 
	DD_Dealer_Id, DD_Dealer_Limit, DD_Sanction_Date, DD_Expiry_Date, DD_Fixed_Rate_Code, DD_Cure_Code,
	DD_Penal_Code, DD_Tenor From Dealer_Details Where DD_Status = 'A') DD
	On D.DM_Dealer_Id = DD.DD_Dealer_Id
	Left Outer Join (Select ROW_NUMBER() OVER(PARTITION BY FRM_Fixed_Rate_Code ORDER BY FRM_Rate_Id Desc) As F_Row, 
	FRM_Fixed_Rate_Code, FRM_Fixed_Rate From Fixed_Rate_Master Where FRM_Status = 'A' And FRM_Enabled = 'Y') F
	On F.FRM_Fixed_Rate_Code = DD.DD_Fixed_Rate_Code
	Left Outer Join (Select ROW_NUMBER() OVER(PARTITION BY CM_Cure_Code ORDER BY CM_Cure_Id Desc) As CU_Row, 
	CM_Cure_Code, CM_Cure_Rate, CM_Cure_Days From Cure_Master Where CM_Status = 'A' And CM_Enabled = 'Y') CU
	On CU.CM_Cure_Code = DD.DD_Cure_Code
	Left Outer Join (Select ROW_NUMBER() OVER(PARTITION BY PM_Penal_Code ORDER BY PM_Penal_Id Desc) As P_Row, 
	PM_Penal_Code, PM_Penal_Rate From Penal_Master Where PM_Status = 'A' And PM_Enabled = 'Y') P
	On P.PM_Penal_Code = DD.DD_Penal_Code
	Where D.DM_Status = 'A' 
	--And ((D.DM_Account_Open_Date Between @i_strFromDate And @i_strToDate)
	And ((D.DM_Account_Open_Date Between 
	Case When @i_strFromDate is null or @i_strFromDate = '' Then D.DM_Account_Open_Date Else @i_strFromDate End 
	And Case When @i_strToDate is null or @i_strToDate = '' Then D.DM_Account_Open_Date Else @i_strToDate End)
	And (D.DM_Account_No = Case When @i_strAccNo Is Null Or @i_strAccNo = '' Then DM_Account_No Else @i_strAccNo End))
	And D.DM_Created_Channel Is Not Null And D.DM_Created_Channel <> '' And D.DM_Created_Channel <> 'I-CORE'
	And CD_Row = 1 And DD_Row = 1 
	And (F_Row = 1 Or F_Row Is Null)
	And (CU_Row = 1 Or CU_Row Is Null)
	And (P_Row = 1 Or P_Row Is Null)
END