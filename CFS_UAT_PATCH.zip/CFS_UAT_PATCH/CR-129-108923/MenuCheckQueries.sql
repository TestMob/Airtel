Select * from Menu_Master where MM_Menu_Name like 'consolidate%'

Select * from User_Menu_Mapping where UMM_User_Id='ban103419'

Select * from Menu_Master where MM_Menu_Type='TR'
order by MM_Menu_Type, MM_Menu_Order

Select max(MM_menu_order)+1 from Menu_Master
where MM_Menu_Type='TR'