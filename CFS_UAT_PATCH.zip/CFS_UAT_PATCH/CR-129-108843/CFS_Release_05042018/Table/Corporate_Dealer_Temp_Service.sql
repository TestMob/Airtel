USE [CFS]
GO

/****** Object:  Table [dbo].[Corporate_Dealer_Temp_Service]    Script Date: 05-04-2018 16:56:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Corporate_Dealer_Temp_Service](
	[CDTS_Dealer_Name] [varchar](100) NULL,
	[CDTS_Account_No] [varchar](100) NULL,
	[CDTS_Customer_Id] [varchar](100) NULL,
	[CDTS_Dealer_Limit] [varchar](100) NULL,
	[CDTS_Dealer_Sanction_Date] [varchar](100) NULL,
	[CDTS_Dealer_Expiry_Date] [varchar](100) NULL,
	[CDTS_Dealer_Renewal_Date] [varchar](100) NULL,
	[CDTS_Limit_Id_Prefix] [varchar](100) NULL,
	[CDTS_Limit_Id_Suffix] [varchar](100) NULL,
	[CDTS_Parent_Limit_Id_Prefix] [varchar](100) NULL,
	[CDTS_Parent_Limit_Id_Suffix] [varchar](100) NULL,
	[CDTS_Address1] [varchar](100) NULL,
	[CDTS_Address2] [varchar](100) NULL,
	[CDTS_City] [varchar](100) NULL,
	[CDTS_State] [varchar](100) NULL,
	[CDTS_Pin] [varchar](100) NULL,
	[CDTS_Phone_No] [varchar](100) NULL,
	[CDTS_Email_Id] [varchar](100) NULL,
	[CDTS_Account_Open_Date] [varchar](100) NULL,
	[CDTS_Account_Close_Date] [varchar](100) NULL,
	[CDTS_Account_Status] [varchar](100) NULL,
	[CDTS_Program_Limit] [varchar](100) NULL,
	[CDTS_Program_Sanction_Date] [varchar](100) NULL,
	[CDTS_Program_Expiry_Date] [varchar](100) NULL,
	[CDTS_Program_Renewal_Date] [varchar](100) NULL,
	[CDTS_Documentation_Date] [varchar](100) NULL,
	[CDTS_Doc1] [varchar](100) NULL,
	[CDTS_Doc2] [varchar](100) NULL,
	[CDTS_Doc3] [varchar](100) NULL,
	[CDTS_Doc4] [varchar](100) NULL,
	[CDTS_Doc5] [varchar](100) NULL,
	[CDTS_Doc6] [varchar](100) NULL,
	[CDTS_Doc7] [varchar](100) NULL,
	[CDTS_Doc8] [varchar](100) NULL,
	[CDTS_Doc9] [varchar](100) NULL,
	[CDTS_Doc10] [varchar](100) NULL,
	[CDTS_Dealer_Short_Name] [varchar](100) NULL,
	[CDTS_Sol_ID] [varchar](100) NULL,
	[CDTS_Dealer_Corporate_Name] [varchar](50) NULL,
	[CDTS_SM_Email_ID] [varchar](100) NULL,
	[CDTS_Name_Of_SM] [varchar](100) NULL,
	[CDTS_Name_Of_CRM] [varchar](100) NULL,
	[CDTS_Credit_Tenor] [varchar](100) NULL,
	[CDTS_Category_Name] [varchar](100) NULL,
	[CDTS_Rate_Code] [varchar](100) NULL,
	[CDTS_Fixed_Rate_Code] [varchar](100) NULL,
	[CDTS_Cure_Code] [varchar](100) NULL,
	[CDTS_Penal_Code] [varchar](100) NULL,
	[CDTS_Minimum_Code] [varchar](100) NULL,
	[CDTS_Maximum_Code] [varchar](100) NULL,
	[CDTS_Contact_Person] [varchar](100) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


