USE [CFS]
GO

/****** Object:  Table [dbo].[Upload_Service_Master]    Script Date: 05-04-2018 16:55:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Upload_Service_Master](
	[USM_Service_File_Id] [numeric](12, 0) IDENTITY(1,1) NOT NULL,
	[USM_Service_File_Name] [varchar](50) NOT NULL,
	[USM_Upload_Date] [datetime] NOT NULL,
	[USM_Type_Of_Upload] [varchar](5) NOT NULL,
	[USM_Total_Records] [int] NULL,
	[USM_Success_Records] [int] NULL,
	[USM_Failure_Records] [int] NULL,
	[USM_Created_By] [varchar](15) NOT NULL,
	[USM_Created_On] [datetime] NOT NULL,
 CONSTRAINT [PK_Upload_Service_Master] PRIMARY KEY CLUSTERED 
(
	[USM_Service_File_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


