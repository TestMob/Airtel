USE [CFS]
GO
/****** Object:  StoredProcedure [dbo].[usp_CorporateDealerServiceUploadValidate]    Script Date: 09-05-2018 15:26:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
   
ALTER PROCEDURE [usp_CorporateDealerServiceUploadValidate]    
  @i_strUploadFileId  AS VARCHAR(5),    
  @i_strCreatedBy  AS VARCHAR(15),    
  @i_strCreatedOn  AS VARCHAR(25),    
  @o_strSuccessRecords  AS VARCHAR(15)  OUTPUT,    
  @o_strFailureRecords  AS VARCHAR(15)  OUTPUT,    
  @o_strTotalRecords  AS VARCHAR(15)  OUTPUT,    
  @o_strReturnFlag  AS CHAR(1)  OUTPUT    
    
AS    
BEGIN    
SET NOCOUNT ON     
 BEGIN    
  DECLARE @dtCurrentDate     AS DATETIME    
  DECLARE @strErrorMessage   AS VARCHAR(250)    
  DECLARE @strCreatedBy      AS VARCHAR(15)    
  DECLARE @intUploadFileId   AS NUMERIC(7)    
  DECLARE @strCurrentDate    AS VARCHAR(25) -- Used for passing to the stored procedure    
  DECLARE @intTotalCount    AS NUMERIC(10)     
  DECLARE @intSuccessCount   AS NUMERIC(10)    
  DECLARE @intFailureCount   AS NUMERIC(10)    
  DECLARE @intErrorNo    AS NUMERIC(10)    
  DECLARE @strConvertDateToMMDDYYYY AS CHAR(1)    
    
  DECLARE @intCM_Corporate_Id  AS NUMERIC(7)    
  DECLARE @strCorporate_Status AS CHAR(1)    
  DECLARE @intDM_Dealer_Id  AS NUMERIC(7)    
  DECLARE @strDealer_Status AS CHAR(1)    
    
  --Cursor Variables Declaration [Start]-- Corporate_MAster Dealer_MAster    
  DECLARE @strCDT_Dealer_Name_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Account_No_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Customer_Id_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Dealer_Limit_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Dealer_Sanction_Date_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Dealer_Expiry_Date_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Dealer_Renewal_Date_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Limit_Id_Prefix_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Limit_Id_Suffix_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Parent_Limit_Id_Prefix_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Parent_Limit_Id_Suffix_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Address1_Temp   AS VARCHAR(250)     
  DECLARE @strCDT_Address2_Temp   AS VARCHAR(250)     
  DECLARE @strCDT_City_Temp   AS VARCHAR(50)      
  DECLARE @strCDT_State_Temp   AS VARCHAR(50)      
  DECLARE @strCDT_Pin_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Phone_No_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Email_Id_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Account_Open_Date_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Account_Close_Date_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Account_Status_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Program_Limit_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Program_Sanction_Date_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Program_Expiry_Date_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Program_Renewal_Date_Temp AS VARCHAR(100)     
  DECLARE @strCDT_Documentation_Date_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Doc1_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc2_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc3_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc4_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc5_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc6_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc7_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc8_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc9_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Doc10_Temp   AS VARCHAR(100)     
  DECLARE @strCDT_Dealer_Short_Name_Temp  AS VARCHAR(100)     
  DECLARE @strCDT_Sol_ID_Temp   AS VARCHAR(100)
  DECLARE @strCDT_SM_Email_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_SM_Name_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_CRM_Name_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Credit_Tenor_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Category_Name_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Rate_Code_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Fixed_Rate_Code_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Cure_Code_Temp   AS VARCHAR(100)
  DECLARE @strCDT_Penal_Code_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Minimum_Code_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Maximum_Code_Temp   AS VARCHAR(100) 
  DECLARE @strCDT_Contact_Person_Temp   AS VARCHAR(100)  
  DECLARE @strCDT_Mode_Of_Funding_Temp   AS CHAR(1)  
  DECLARE @strCDT_Asset_Classification_Temp   AS CHAR(1)  
  DECLARE @strCDT_Created_Channel_Temp   AS VARCHAR(100)  
     
   --New variable added by Suchi--  
  DECLARE @strCDT_DealerCorpName_Temp AS VARCHAR(50)  
  
  --Cursor Variables Declaration [End]--    
     
  --Original Variables Declaration [Start]--    
  DECLARE @strCDT_Dealer_Name   AS VARCHAR(50)      
  DECLARE @strCDT_Account_No   AS VARCHAR(16)      
  DECLARE @strCDT_Customer_Id   AS VARCHAR(9)      
  DECLARE @intCDT_Dealer_Limit   AS NUMERIC(20,4)     
  DECLARE @dtCDT_Dealer_Sanction_Date  AS DATETIME    
  DECLARE @dtCDT_Dealer_Expiry_Date  AS DATETIME    
  DECLARE @dtCDT_Dealer_Renewal_Date  AS DATETIME    
  DECLARE @strCDT_Limit_Id_Prefix   AS VARCHAR(100)     
  DECLARE @strCDT_Limit_Id_Suffix   AS VARCHAR(100)     
  DECLARE @strCDT_Parent_Limit_Id_Prefix  AS VARCHAR(12)      
  DECLARE @strCDT_Parent_Limit_Id_Suffix  AS VARCHAR(5)      
  DECLARE @strCDT_Address1   AS VARCHAR(250)     
  DECLARE @strCDT_Address2   AS VARCHAR(250)     
  DECLARE @strCDT_City    AS VARCHAR(50)     
  DECLARE @strCDT_State    AS VARCHAR(50)     
  DECLARE @strCDT_Pin    AS VARCHAR(20)     
  DECLARE @strCDT_Phone_No   AS VARCHAR(50)      
  DECLARE @strCDT_Email_Id   AS VARCHAR(50)      
  DECLARE @dtCDT_Account_Open_Date  AS DATETIME     
  DECLARE @dtCDT_Account_Close_Date  AS DATETIME     
  DECLARE @strCDT_Account_Status   AS VARCHAR(1)    
  DECLARE @intCDT_Program_Limit   AS NUMERIC(20,4)    
  DECLARE @dtCDT_Program_Sanction_Date  AS DATETIME     
  DECLARE @dtCDT_Program_Expiry_Date  AS DATETIME     
  DECLARE @dtCDT_Program_Renewal_Date  AS DATETIME     
  DECLARE @dtCDT_Documentation_Date  AS DATETIME    
  DECLARE @strCDT_Doc1    AS VARCHAR(50)     
  DECLARE @strCDT_Doc2    AS VARCHAR(50)      
  DECLARE @strCDT_Doc3    AS VARCHAR(50)      
  DECLARE @strCDT_Doc4    AS VARCHAR(50)      
  DECLARE @strCDT_Doc5    AS VARCHAR(50)      
  DECLARE @strCDT_Doc6    AS VARCHAR(50)      
  DECLARE @strCDT_Doc7    AS VARCHAR(50)      
  DECLARE @strCDT_Doc8    AS VARCHAR(50)      
  DECLARE @strCDT_Doc9    AS VARCHAR(50)      
  DECLARE @strCDT_Doc10    AS VARCHAR(50)      
  DECLARE @strCDT_Dealer_Short_Name  AS VARCHAR(50)      
  DECLARE @strCDT_Sol_ID    AS VARCHAR(8) 
  DECLARE @strCDT_SM_Email   AS VARCHAR(50) 
  DECLARE @strCDT_SM_Name   AS VARCHAR(50) 
  DECLARE @strCDT_CRM_Name   AS VARCHAR(50) 
  DECLARE @intCDT_Credit_Tenor   AS NUMERIC(3, 0) 
  DECLARE @strCDT_Category_Name   AS VARCHAR(30)
  DECLARE @intCDT_Category_Code   AS NUMERIC(7, 0) 
  DECLARE @intCDT_Rate_Code   AS NUMERIC(3, 0)
  DECLARE @strCDT_Fixed_Rate_Code   AS VARCHAR(10) 
  DECLARE @strCDT_Cure_Code   AS VARCHAR(10)
  DECLARE @strCDT_Penal_Code   AS VARCHAR(10) 
  DECLARE @strCDT_Minimum_Code   AS VARCHAR(10) 
  DECLARE @strCDT_Maximum_Code   AS VARCHAR(10) 
  DECLARE @strCDT_Contact_Person   AS VARCHAR(50)  
  DECLARE @strCDT_Mode_Of_Funding   AS CHAR(1)  
  DECLARE @strCDT_Asset_Classification   AS CHAR(1)  
  DECLARE @strCDT_Created_Channel   AS VARCHAR(100)  
   --New variable added by Suchi--  
  DECLARE @strCDT_DealerCorpName AS VARCHAR(50)    
  
  --Original Variables Declaration [End]--    
    
  --Original Field Size [Start]--    
  DECLARE @intCONST_Dealer_Name   AS SMALLINT    
  DECLARE @intCONST_Account_No   AS SMALLINT    
  DECLARE @intCONST_Customer_Id   AS SMALLINT    
  DECLARE @intCONST_Dealer_Limit   AS SMALLINT    
  DECLARE @intCONST_Limit_Id_Prefix  AS SMALLINT    
  DECLARE @intCONST_Limit_Id_Suffix  AS SMALLINT    
  DECLARE @intCONST_Parent_Limit_Id_Prefix AS SMALLINT    
  DECLARE @intCONST_Parent_Limit_Id_Suffix AS SMALLINT    
  DECLARE @intCONST_Address1   AS SMALLINT    
  DECLARE @intCONST_Address2   AS SMALLINT    
  DECLARE @intCONST_City    AS SMALLINT    
  DECLARE @intCONST_State    AS SMALLINT    
  DECLARE @intCONST_Pin    AS SMALLINT    
  DECLARE @intCONST_Phone_No   AS SMALLINT    
  DECLARE @intCONST_Email_Id   AS SMALLINT    
  DECLARE @intCONST_Account_Status  AS SMALLINT    
  DECLARE @intCONST_Program_Limit   AS SMALLINT    
  DECLARE @intCONST_Doc1    AS SMALLINT    
  DECLARE @intCONST_Doc2    AS SMALLINT    
  DECLARE @intCONST_Doc3    AS SMALLINT    
  DECLARE @intCONST_Doc4    AS SMALLINT    
  DECLARE @intCONST_Doc5    AS SMALLINT    
  DECLARE @intCONST_Doc6    AS SMALLINT    
  DECLARE @intCONST_Doc7    AS SMALLINT    
  DECLARE @intCONST_Doc8    AS SMALLINT    
  DECLARE @intCONST_Doc9    AS SMALLINT    
  DECLARE @intCONST_Doc10    AS SMALLINT    
  DECLARE @intCONST_Dealer_Short_Name  AS SMALLINT    
  DECLARE @intCONST_Sol_ID   AS SMALLINT 
  DECLARE @intCONST_SM_Email   AS SMALLINT  
  DECLARE @intCONST_SM_Name   AS SMALLINT  
  DECLARE @intCONST_CRM_Name   AS SMALLINT  
  DECLARE @intCONST_Credit_Tenor   AS SMALLINT  
  DECLARE @intCONST_Category_Name   AS SMALLINT  
  --DECLARE @intCONST_Rate_Code   AS SMALLINT  
  DECLARE @intCONST_Fixed_Rate_Code   AS SMALLINT  
  DECLARE @intCONST_Cure_Code   AS SMALLINT  
  DECLARE @intCONST_Penal_Code   AS SMALLINT  
  DECLARE @intCONST_Minimum_Code   AS SMALLINT
  DECLARE @intCONST_Maximum_Code   AS SMALLINT  
  DECLARE @intCONST_Contact_Person   AS SMALLINT  
  DECLARE @intCONST_Created_Channel   AS SMALLINT  
   --New variable added by Suchi--  
  DECLARE @intCONST_DealerCorpName AS SMALLINT    
    
  SET @intCONST_Dealer_Name  = 50    
  SET @intCONST_Account_No  = 16    
  SET @intCONST_Customer_Id  = 9    
  SET @intCONST_Dealer_Limit  = 21    
  SET @intCONST_Limit_Id_Prefix  = 12    
  SET @intCONST_Limit_Id_Suffix  = 2    
  SET @intCONST_Parent_Limit_Id_Prefix = 12    
  SET @intCONST_Parent_Limit_Id_Suffix = 2    
  SET @intCONST_Address1   = 250    
  SET @intCONST_Address2   = 250    
  SET @intCONST_City   = 50    
  SET @intCONST_State   = 50    
  SET @intCONST_Pin   = 6    
  SET @intCONST_Phone_No   = 50    
  SET @intCONST_Email_Id   = 40    
  SET @intCONST_Account_Status  = 1    
  SET @intCONST_Program_Limit  = 21    
  SET @intCONST_Doc1   = 50    
  SET @intCONST_Doc2   = 50    
  SET @intCONST_Doc3   = 50    
  SET @intCONST_Doc4   = 50    
  SET @intCONST_Doc5   = 50    
  SET @intCONST_Doc6   = 50    
  SET @intCONST_Doc7   = 50    
  SET @intCONST_Doc8   = 50    
  SET @intCONST_Doc9   = 50    
  SET @intCONST_Doc10   = 50    
  SET @intCONST_Dealer_Short_Name  = 50    
  SET @intCONST_Sol_ID   = 8   
  SET @intCONST_DealerCorpName=50
  SET @intCONST_SM_Email = 50
  SET @intCONST_SM_Name = 50
  SET @intCONST_CRM_Name = 50
  SET @intCONST_Credit_Tenor =  3
  SET @intCONST_Category_Name =  30
  --SET @intCONST_Rate_Code = 0
  SET @intCONST_Fixed_Rate_Code = 10
  SET @intCONST_Cure_Code = 10
  SET @intCONST_Penal_Code = 10
  SET @intCONST_Minimum_Code = 10
  SET @intCONST_Maximum_Code =  10
  SET @intCONST_Contact_Person = 50  
  SET @intCONST_Created_Channel = 30  
  --Original Field Size [End]--    
    
  SET @strConvertDateToMMDDYYYY = 'N'   --If the uploaded data has date format as DD-MM-YYYY then turn the flag to Y    
  SET @dtCurrentDate   = GETDATE()    
  SET @strCurrentDate  = CONVERT(VARCHAR, @dtCurrentDate, 121)    
  SET @strCreatedBy    = @i_strCreatedBy    
  SET @intSuccessCount = 0    
  SET @intUploadFileId = CONVERT(NUMERIC,@i_strUploadFileId)    
    
  SET @o_strTotalRecords   = '0'    
  SET @o_strSuccessRecords  = '0'    
  SET @o_strFailureRecords  = '0'    
 END    
 BEGIN    
    
  DECLARE CorporateDealer_Cursor CURSOR     
  FOR    
  SELECT      
   CDTS_Dealer_Name, CDTS_Account_No,    
   CDTS_Customer_Id, CDTS_Dealer_Limit,    
   CDTS_Dealer_Sanction_Date, CDTS_Dealer_Expiry_Date,    
   CDTS_Dealer_Renewal_Date, CDTS_Limit_Id_Prefix,    
   CDTS_Limit_Id_Suffix, CDTS_Parent_Limit_Id_Prefix,    
   CDTS_Parent_Limit_Id_Suffix, CDTS_Address1,    
   CDTS_Address2, CDTS_City,    
   CDTS_State, CDTS_Pin,    
   CDTS_Phone_No, CDTS_Email_Id,    
   CDTS_Account_Open_Date, CDTS_Account_Close_Date,    
   CDTS_Account_Status, CDTS_Program_Limit,    
   CDTS_Program_Sanction_Date, CDTS_Program_Expiry_Date,    
   CDTS_Program_Renewal_Date, CDTS_Documentation_Date,    
   CDTS_Doc1, CDTS_Doc2,     
   CDTS_Doc3, CDTS_Doc4,     
   CDTS_Doc5, CDTS_Doc6,     
   CDTS_Doc7, CDTS_Doc8,     
   CDTS_Doc9, CDTS_Doc10,    
   CDTS_Dealer_Short_Name, CDTS_Sol_ID,CDTS_Dealer_Corporate_Name,
   CDTS_SM_Email_ID, CDTS_Name_Of_SM, CDTS_Name_Of_CRM, CDTS_Credit_Tenor, CDTS_Category_Name, CDTS_Rate_Code,
   CDTS_Fixed_Rate_Code, CDTS_Cure_Code, CDTS_Penal_Code, CDTS_Minimum_Code, CDTS_Maximum_Code, CDTS_Contact_Person,
   CDTS_Mode_Of_Funding, CDTS_Asset_Classification, CDTS_Created_Channel    
  FROM CORPORATE_DEALER_TEMP_SERVICE    
    
  OPEN CorporateDealer_Cursor    
   FETCH NEXT FROM CorporateDealer_Cursor    
   INTO     
    @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp,    
    @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
    @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp,    
    @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
    @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp,    
    @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
    @strCDT_Address2_Temp, @strCDT_City_Temp,    
    @strCDT_State_Temp, @strCDT_Pin_Temp,    
    @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp,    
    @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
    @strCDT_Account_Status_Temp, @strCDT_Program_Limit_Temp,     
    @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
    @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp,    
    @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
    @strCDT_Doc3_Temp, @strCDT_Doc4_Temp,     
    @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
    @strCDT_Doc7_Temp, @strCDT_Doc8_Temp,     
    @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,    
    @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp,  
	@strCDT_DealerCorpName_Temp,   
	@strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	@strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	@strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	@strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp
    
  WHILE (@@FETCH_STATUS = 0)    
  BEGIN    
    
   --/////////////////////////////////////////////////////////////////////////////////////////////////////--    
   SET  @strCDT_Dealer_Name_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Dealer_Name_Temp,'')))    
   SET  @strCDT_Account_No_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Account_No_Temp,'')))    
   SET @strCDT_Customer_Id_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Customer_Id_Temp,'')))    
   SET @strCDT_Dealer_Limit_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Dealer_Limit_Temp,'')))    
   SET @strCDT_Dealer_Sanction_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Dealer_Sanction_Date_Temp,'')))    
   SET @strCDT_Dealer_Expiry_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Dealer_Expiry_Date_Temp,'')))    
   SET @strCDT_Dealer_Renewal_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Dealer_Renewal_Date_Temp,'')))     
   SET @strCDT_Limit_Id_Prefix_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Limit_Id_Prefix_Temp,'')))    
   SET @strCDT_Limit_Id_Suffix_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Limit_Id_Suffix_Temp,'')))    
   SET @strCDT_Parent_Limit_Id_Prefix_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Parent_Limit_Id_Prefix_Temp,'')))    
   SET @strCDT_Parent_Limit_Id_Suffix_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Parent_Limit_Id_Suffix_Temp,'')))    
   SET @strCDT_Address1_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Address1_Temp,'')))    
   SET @strCDT_Address2_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Address2_Temp,'')))    
   SET @strCDT_City_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_City_Temp,'')))    
   SET @strCDT_State_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_State_Temp,'')))    
   SET @strCDT_Pin_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Pin_Temp,'')))    
   SET @strCDT_Phone_No_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Phone_No_Temp,'')))    
   SET @strCDT_Email_Id_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Email_Id_Temp,'')))    
   SET @strCDT_Account_Open_Date_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Account_Open_Date_Temp,'')))    
   SET @strCDT_Account_Close_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Account_Close_Date_Temp,'')))    
   SET @strCDT_Account_Status_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Account_Status_Temp,'')))    
   SET @strCDT_Program_Limit_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Program_Limit_Temp,'')))    
    SET @strCDT_Program_Sanction_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Program_Sanction_Date_Temp,'')))    
   SET @strCDT_Program_Expiry_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Program_Expiry_Date_Temp,'')))    
   SET @strCDT_Program_Renewal_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Program_Renewal_Date_Temp,'')))    
   SET @strCDT_Documentation_Date_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Documentation_Date_Temp,'')))    
   SET @strCDT_Doc1_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc1_Temp,'')))    
   SET @strCDT_Doc2_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc2_Temp,'')))    
   SET @strCDT_Doc3_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc3_Temp,'')))    
   SET @strCDT_Doc4_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc4_Temp,'')))    
   SET @strCDT_Doc5_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc5_Temp,'')))    
   SET @strCDT_Doc6_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc6_Temp,'')))    
   SET @strCDT_Doc7_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc7_Temp,'')))    
   SET @strCDT_Doc8_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc8_Temp,'')))    
   SET @strCDT_Doc9_Temp    = RTRIM(LTRIM(ISNULL(@strCDT_Doc9_Temp,'')))    
   SET @strCDT_Doc10_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Doc10_Temp,'')))    
   SET  @strCDT_Dealer_Short_Name_Temp  = RTRIM(LTRIM(ISNULL(@strCDT_Dealer_Short_Name_Temp,'')))    
   SET  @strCDT_Sol_ID_Temp   = RTRIM(LTRIM(ISNULL(@strCDT_Sol_ID_Temp,'')))   
   SET @strCDT_DealerCorpName_Temp=RTRIM(LTRIM(ISNULL(@strCDT_DealerCorpName_Temp ,''))) 
   SET @strCDT_SM_Email_Temp = RTRIM(LTRIM(ISNULL(@strCDT_SM_Email_Temp,'')))   
   SET @strCDT_SM_Name_Temp = RTRIM(LTRIM(ISNULL(@strCDT_SM_Name_Temp,'')))   
   SET @strCDT_CRM_Name_Temp = RTRIM(LTRIM(ISNULL(@strCDT_CRM_Name_Temp,'')))   
   SET @strCDT_Credit_Tenor_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Credit_Tenor_Temp,'')))   
   SET @strCDT_Category_Name_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Category_Name_Temp,'')))   
   SET @strCDT_Rate_Code_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Rate_Code_Temp,'')))   
   SET @strCDT_Fixed_Rate_Code_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Fixed_Rate_Code_Temp,'')))   
   SET @strCDT_Cure_Code_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Cure_Code_Temp,'')))   
   SET @strCDT_Penal_Code_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Penal_Code_Temp,'')))   
   SET @strCDT_Minimum_Code_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Minimum_Code_Temp,'')))   
   SET @strCDT_Maximum_Code_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Maximum_Code_Temp,'')))   
   SET @strCDT_Contact_Person_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Contact_Person_Temp,''))) 
   SET @strCDT_Mode_Of_Funding_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Mode_Of_Funding_Temp,'')))   
   SET @strCDT_Asset_Classification_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Asset_Classification_Temp,'')))   
   SET @strCDT_Created_Channel_Temp = RTRIM(LTRIM(ISNULL(@strCDT_Created_Channel_Temp,'')))   
   --/////////////////////////////////////////////////////////////////////////////////////////////////////--    
    
   --Setting MMDDYYYY Date Format if the data is in DDMMYYYY--    
   IF (UPPER(@strConvertDateToMMDDYYYY) = 'Y')    
   BEGIN        
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Dealer_Sanction_Date_Temp , @strCDT_Dealer_Sanction_Date_Temp  OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Dealer_Expiry_Date_Temp   , @strCDT_Dealer_Expiry_Date_Temp  OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Dealer_Renewal_Date_Temp  , @strCDT_Dealer_Renewal_Date_Temp  OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Account_Open_Date_Temp   , @strCDT_Account_Open_Date_Temp  OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Account_Close_Date_Temp   , @strCDT_Account_Close_Date_Temp OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Sanction_Date_Temp OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Program_Expiry_Date_Temp  , @strCDT_Program_Expiry_Date_Temp OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Program_Renewal_Date_Temp , @strCDT_Program_Renewal_Date_Temp OUTPUT    
    EXEC usp_GetMMDDYYYYDateFormat  @strCDT_Documentation_Date_Temp   , @strCDT_Documentation_Date_Temp OUTPUT    
   END    
   --///////////////////////////////////////////////////////////--    
     
   --|||||| VALIDATIONS Start ||||||--    
   --1. Dealer Name    
   IF (LEN(@strCDT_Dealer_Name_Temp) <= @intCONST_Dealer_Name)    
   BEGIN    
    SET @strCDT_Dealer_Name = @strCDT_Dealer_Name_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer Name exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
    GOTO MoveToNextRecord    
   END     
    
   --2. Account No    
    
   IF (@strCDT_Account_No_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Account No. is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
    GOTO MoveToNextRecord    
   END    
       
   IF (LEN(@strCDT_Account_No_Temp) <= @intCONST_Account_No)    
   BEGIN    
    SET @strCDT_Account_No = @strCDT_Account_No_Temp    
   END    
   ELSE    
   BEGIN    
    
    SET @strErrorMessage = 'Account No. exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
    GOTO MoveToNextRecord    
   END     

   IF Exists(Select DM_Account_No FRom Dealer_master Where DM_Account_No = @strCDT_Account_No_Temp)    
   BEGIN    
    SET @strErrorMessage = 'Dealer Already Exists.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
    GOTO MoveToNextRecord    
   END    
    
   --3. Customer Id    
   IF (LEN(@strCDT_Customer_Id_Temp) <= @intCONST_Customer_Id)    
   BEGIN    
    SET @strCDT_Customer_Id = @strCDT_Customer_Id_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Customer Id exceed the max length.'    
     EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate     
    GOTO MoveToNextRecord    
   END     
    
   --4. Dealer Limit    
    
   IF (@strCDT_Dealer_Limit_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Dealer Limit is NULL.'    
      EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Dealer_Limit_Temp) <= @intCONST_Dealer_Limit)    
   BEGIN    
    SET @intCDT_Dealer_Limit = CONVERT(NUMERIC(20,4),@strCDT_Dealer_Limit_Temp)    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer Limit exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END     
    
   --5. Dealer Sanction Date    
   IF (@strCDT_Dealer_Sanction_Date_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Sanction Date is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (ISDATE(@strCDT_Dealer_Sanction_Date_Temp) = 1)    
   BEGIN    
    SET @dtCDT_Dealer_Sanction_Date = CONVERT(DATETIME, @strCDT_Dealer_Sanction_Date_Temp)    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer Saction Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --6. Dealer Expiry Date    
   IF (@strCDT_Dealer_Expiry_Date_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Dealer Expiry Date is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END    
    
   IF (ISDATE(@strCDT_Dealer_Expiry_Date_Temp) = 1)    
   BEGIN    
    SET @dtCDT_Dealer_Expiry_Date = CONVERT(DATETIME, @strCDT_Dealer_Expiry_Date_Temp)    
    IF (DATEDIFF(dd, @dtCDT_Dealer_Sanction_Date, @dtCDT_Dealer_Expiry_Date) < 0) -- IF Sanction date > Expiry date     
    BEGIN    
     SET @strErrorMessage = 'Dealer Sanction date is greater than Expiry Date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
     GOTO MoveToNextRecord    
    END     
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer Expiry Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END    
    
   --7. Dealer Renewal Date ---Allowing if Renewal Date is NULL    
   IF (@strCDT_Dealer_Renewal_Date_Temp <> '')    
   BEGIN    
    IF (ISDATE(@strCDT_Dealer_Renewal_Date_Temp) = 1)    
    BEGIN    
     SET @dtCDT_Dealer_Renewal_Date = CONVERT(DATETIME, @strCDT_Dealer_Renewal_Date_Temp)    
     IF (DATEDIFF(dd, @dtCDT_Dealer_Sanction_Date, @dtCDT_Dealer_Renewal_Date) < 0) -- IF Sanction date > Renewal date    
     BEGIN    
      SET @strErrorMessage = 'Sanction Date is greater than Dealer Renewal Date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
      GOTO MoveToNextRecord    
     END     
    END    
    ELSE    
    BEGIN    
     SET @strErrorMessage = 'Dealer Renewal Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
     GOTO MoveToNextRecord    
    END    
    
   END    
    
   --8. Limit Id Prefix    
   IF (@strCDT_Limit_Id_Prefix_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Limit Prefix is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Limit_Id_Prefix_Temp) <= @intCONST_Limit_Id_Prefix)    
   BEGIN    
    SET @strCDT_Limit_Id_Prefix = @strCDT_Limit_Id_Prefix_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Limit Prefix exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END    
    
   --9. Limit Id Suffix    
   IF (@strCDT_Limit_Id_Suffix_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Limit Suffix is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Limit_Id_Suffix_Temp) <= @intCONST_Limit_Id_Suffix)    
   BEGIN    
    SET @strCDT_Limit_Id_Suffix = @strCDT_Limit_Id_Suffix_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Limit Suffix exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --10. Parent Limit Id Prefix    
   IF (@strCDT_Parent_Limit_Id_Prefix_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Parent Limit Prefix is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Parent_Limit_Id_Prefix_Temp) <= @intCONST_Parent_Limit_Id_Prefix)    
   BEGIN    
    SET @strCDT_Parent_Limit_Id_Prefix = @strCDT_Parent_Limit_Id_Prefix_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Parent Limit Prefix exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
       
   --11. Parent Limit Id Suffix    
   IF (@strCDT_Parent_Limit_Id_Suffix_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Parent Limit Suffix is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Parent_Limit_Id_Suffix_Temp) <= @intCONST_Parent_Limit_Id_Suffix)    
   BEGIN    
    SET @strCDT_Parent_Limit_Id_Suffix = @strCDT_Parent_Limit_Id_Suffix_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Parent Limit Suffix exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --12. Address1    
   IF (LEN(@strCDT_Address1_Temp) <= @intCONST_Address1)    
   BEGIN    
    SET @strCDT_Address1 = @strCDT_Address1_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Address1 exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate     
    GOTO MoveToNextRecord    
   END    
    
   --13. Address2    
   IF (LEN(@strCDT_Address2_Temp) <= @intCONST_Address2)    
   BEGIN    
    SET @strCDT_Address2 = @strCDT_Address2_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Address2 exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate     
    GOTO MoveToNextRecord    
   END    
    
   --14. City    
   IF (LEN(@strCDT_City_Temp) <= @intCONST_City)    
   BEGIN    
    SET @strCDT_City = @strCDT_City_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'City exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --15. State    
   IF (LEN(@strCDT_State_Temp) <= @intCONST_State)    
   BEGIN    
    SET @strCDT_State = @strCDT_State_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'State exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
    
   --16. Pin    
   IF (LEN(@strCDT_Pin_Temp) <= @intCONST_Pin)    
   BEGIN    
    SET @strCDT_Pin = @strCDT_Pin_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Pin exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --17. Phone_No    
   IF (LEN(@strCDT_Phone_No_Temp) <= @intCONST_Phone_No)    
   BEGIN    
    SET @strCDT_Phone_No = @strCDT_Phone_No_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Phone No. exceed the max length.'    
    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --18. Email Id    
   IF (LEN(@strCDT_Email_Id_Temp) <= @intCONST_Email_Id)    
   BEGIN    
    SET @strCDT_Email_Id = @strCDT_Email_Id_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Email Id exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --19. Account Open Date    
   IF (@strCDT_Account_Open_Date_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Account Open Date is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   IF (ISDATE(@strCDT_Account_Open_Date_Temp) = 1)    
   BEGIN    
    SET @dtCDT_Account_Open_Date = CONVERT(DATETIME, @strCDT_Account_Open_Date_Temp)    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Account Open Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --20. Account Close Date    
   IF (@strCDT_Account_Close_Date_Temp <> '')    
   BEGIN    
    IF (ISDATE(@strCDT_Account_Close_Date_Temp) = 1)    
    BEGIN    
     SET @dtCDT_Account_Close_Date = CONVERT(DATETIME, @strCDT_Account_Close_Date_Temp)    
    END    
    ELSE    
    BEGIN    
     SET @strErrorMessage = 'Account Close Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
     GOTO MoveToNextRecord    
    END    
   END    
    
   --21. Account Status    
   IF (@strCDT_Account_Status_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Account Status is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Account_Status_Temp) <= @intCONST_Account_Status)    
   BEGIN    
    SET @strCDT_Account_Status = @strCDT_Account_Status_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Account Status exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --22. Program Limit    
   IF (@strCDT_Program_Limit_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Program Limit is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate     
    GOTO MoveToNextRecord    
   END    
    
   IF (ISNUMERIC(@strCDT_Program_Limit_Temp) <> 1)    
   BEGIN    
    SET @strErrorMessage = 'Program Limit is not numeric.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   IF (LEN(@strCDT_Program_Limit_Temp) <= @intCONST_Program_Limit)    
   BEGIN    
    SET @intCDT_Program_Limit = @strCDT_Program_Limit_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Program Limit exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
       
   --23. Program Sanction Date    
   IF (@strCDT_Program_Sanction_Date_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Program Sanction Date is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (ISDATE(@strCDT_Program_Sanction_Date_Temp) = 1)    
   BEGIN    
    SET @dtCDT_Program_Sanction_Date = CONVERT(DATETIME, @strCDT_Program_Sanction_Date_Temp)    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Program Sanction Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --24. Program Expiry Date    
   IF (@strCDT_Program_Expiry_Date_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Program Expiry Date is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   IF (ISDATE(@strCDT_Program_Expiry_Date_Temp) = 1)    
   BEGIN    
    SET @dtCDT_Program_Expiry_Date = CONVERT(DATETIME, @strCDT_Program_Expiry_Date_Temp)    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Program Expiry Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --25. Program Renewal Date    
   IF (@strCDT_Program_Renewal_Date_Temp <> '')    
   BEGIN    
    IF (ISDATE(@strCDT_Program_Renewal_Date_Temp) = 1)    
    BEGIN    
     SET @dtCDT_Program_Renewal_Date = CONVERT(DATETIME, @strCDT_Program_Renewal_Date_Temp)    
    END    
    ELSE    
    BEGIN    
     SET @strErrorMessage = 'Program Renewal Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
     GOTO MoveToNextRecord    
    END    
   END    
    
   --26. Documentation Date    
   IF (LTRIM(@strCDT_Documentation_Date_Temp) <> '')    
   BEGIN    
    IF (ISDATE(@strCDT_Documentation_Date_Temp) = 1)    
    BEGIN    
     SET @dtCDT_Documentation_Date = @strCDT_Documentation_Date_Temp    
    END    
    ELSE    
    BEGIN    
     SET @strErrorMessage = 'Documentation Date is not a valid date.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
     GOTO MoveToNextRecord    
    END      
   END    
    
   --27. Doc1    
   IF (LEN(@strCDT_Doc1_Temp) <= @intCONST_Doc1)    
   BEGIN    
    IF (@strCDT_Doc1_Temp = '')    
     SET @strCDT_Doc1 = NULL    
    ELSE    
     SET @strCDT_Doc1 = @strCDT_Doc1_Temp    
   END    
   ELSE    
   BEGIN    
    
    SET @strErrorMessage = 'Document1 exeecd the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END    
    
   --28. Doc2    
   IF (LEN(@strCDT_Doc2_Temp) <= @intCONST_Doc2)    
   BEGIN    
    IF (@strCDT_Doc2_Temp = '')    
     SET @strCDT_Doc2 = NULL    
    ELSE    
     SET @strCDT_Doc2 = @strCDT_Doc2_Temp    
        
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document2 exeecd the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
       
   --29. Doc3    
   IF (LEN(@strCDT_Doc3_Temp) <= @intCONST_Doc3)    
   BEGIN    
    IF (@strCDT_Doc3_Temp = '')    
     SET @strCDT_Doc3 = NULL    
    ELSE    
     SET @strCDT_Doc3 = @strCDT_Doc3_Temp    
    
        
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document3 exeecd the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --30. Doc4    
   IF (LEN(@strCDT_Doc4_Temp) <= @intCONST_Doc4)    
   BEGIN    
    IF (@strCDT_Doc4_Temp = '')    
     SET @strCDT_Doc4 = NULL    
    ELSE    
     SET @strCDT_Doc4 = @strCDT_Doc4_Temp    
        
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document4 exeecd the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
    
   END    
    
   --31. Doc5    
   IF (LEN(@strCDT_Doc5_Temp) <= @intCONST_Doc5)    
   BEGIN    
    IF (@strCDT_Doc5_Temp = '')    
     SET @strCDT_Doc5 = NULL    
    ELSE    
     SET @strCDT_Doc5 = @strCDT_Doc5_Temp    
        
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document5 exeecd the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate      
    GOTO MoveToNextRecord    
   END    
    
   --32. Doc6    
   IF (LEN(@strCDT_Doc6_Temp) <= @intCONST_Doc6)    
   BEGIN    
    IF (@strCDT_Doc6_Temp = '')    
     SET @strCDT_Doc6 = NULL    
    ELSE    
     SET @strCDT_Doc6 = @strCDT_Doc6_Temp    
    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document6 exeecd the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --33. Doc7    
    
   IF (LEN(@strCDT_Doc7_Temp) <= @intCONST_Doc7)    
   BEGIN    
    IF (@strCDT_Doc7_Temp = '')    
     SET @strCDT_Doc7 = NULL    
    ELSE    
     SET @strCDT_Doc7 = @strCDT_Doc7_Temp     
    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document7 exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate     
    GOTO MoveToNextRecord    
   END    
    
    
   --34. Doc8    
   IF (LEN(@strCDT_Doc8_Temp) <= @intCONST_Doc8)    
   BEGIN    
    IF (@strCDT_Doc8_Temp = '')    
     SET @strCDT_Doc8 = NULL    
    ELSE    
     SET @strCDT_Doc8 = @strCDT_Doc8_Temp    
    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document8 exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
    
   --35. Doc9    
   IF (LEN(@strCDT_Doc9_Temp) <= @intCONST_Doc9)    
   BEGIN    
    IF (@strCDT_Doc9_Temp = '')    
     SET @strCDT_Doc9 = NULL    
    ELSE    
     SET @strCDT_Doc9 = @strCDT_Doc9_Temp    
    
    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document9 exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
    
   --36. Doc10    
   IF (LEN(@strCDT_Doc10_Temp) <= @intCONST_Doc10)    
   BEGIN    
    IF (@strCDT_Doc10_Temp = '')    
     SET @strCDT_Doc10 = NULL    
    ELSE    
     SET @strCDT_Doc10 = @strCDT_Doc10_Temp    
    
    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Document10 exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --37. Dealer Short Name    
   IF (LEN(@strCDT_Dealer_Short_Name_Temp) <= @intCONST_Dealer_Short_Name)    
   BEGIN    
    SET @strCDT_Dealer_Short_Name = @strCDT_Dealer_Short_Name_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer short name exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END    
    
   --38. Sol Id    
   IF (@strCDT_Sol_ID_Temp = '')    
   BEGIN    
    SET @strErrorMessage = 'Dealer Sol Id is NULL.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate     
    GOTO MoveToNextRecord    
   END       
    
   IF (LEN(@strCDT_Sol_ID_Temp) <= @intCONST_Sol_ID)    
    
   BEGIN    
    SET @strCDT_Sol_ID = @strCDT_Sol_ID_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer Sol Id exceed the max length.'    
     EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
    GOTO MoveToNextRecord    
   END       
  
  --39. Dealer Corporate Name    
   IF (LEN(@strCDT_DealerCorpName_Temp) <= @intCONST_DealerCorpName)    
   BEGIN    
    SET @strCDT_DealerCorpName = @strCDT_DealerCorpName_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Dealer Corporate Name exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END     

  --40. SM / Account Manager EMail id
  IF (LEN(@strCDT_SM_Email_Temp) <= @intCONST_SM_Email)    
   BEGIN    
    SET @strCDT_SM_Email = @strCDT_SM_Email_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'SM / Account Manager Email id exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --41. Name of SM
  IF (@strCDT_SM_Name_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Name of SM is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  IF (LEN(@strCDT_SM_Name_Temp) <= @intCONST_SM_Name)    
   BEGIN    
    SET @strCDT_SM_Name = @strCDT_SM_Name_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Name of SM exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --42. Name of CRM
  IF (@strCDT_CRM_Name_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Name of CRM is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  IF (LEN(@strCDT_CRM_Name_Temp) <= @intCONST_CRM_Name)    
   BEGIN    
    SET @strCDT_CRM_Name = @strCDT_CRM_Name_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Name of CRM exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --43. Credit Tenor
  IF (@strCDT_Credit_Tenor_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Credit Tenor For the Program is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  IF (ISNUMERIC(@strCDT_Credit_Tenor_Temp) <> 1)  
  Begin
	 SET @strErrorMessage = 'Credit Tenor For the Program is not numeric'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord   
  End

  IF (LEN(@strCDT_Credit_Tenor_Temp) <= @intCONST_Credit_Tenor)    
   BEGIN    
    SET @intCDT_Credit_Tenor = Convert(NUMERIC(3, 0), @strCDT_Credit_Tenor_Temp)
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Credit Tenor For the Program exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  
  
  --44. Category Name
  --IF (@strCDT_Category_Name_Temp = '') 
  -- BEGIN    
  --  SET @strErrorMessage = 'Category Name is Null'    
  --  EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
  --    @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
  --    @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
  --    @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
  --    @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
  --    @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
  --    @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
  --    @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
  --   @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
  --   @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
  --   @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 --@strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 --@strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 --@strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 --@strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
  --  GOTO MoveToNextRecord    
  -- END 

  IF (LEN(@strCDT_Category_Name_Temp) <= @intCONST_Category_Name)    
   BEGIN    
    SET @strCDT_Category_Name = @strCDT_Category_Name_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Category Name exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --45. Rate Code
  IF (@strCDT_Rate_Code_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Rate Code is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END
   Else
   BEGIN
		Set @intCDT_Rate_Code = Convert(NUMERIC(3, 0), @strCDT_Rate_Code_Temp)
   END 

  --46. Fixed Rate Code
  --IF (@strCDT_Fixed_Rate_Code_Temp = '') 
  -- BEGIN    
  --  SET @strErrorMessage = 'Fixed Rate Code is Null'    
  --  EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
  --    @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
  --    @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
  --    @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
  --    @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
  --    @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
  --    @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
  --    @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
  --   @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
  --   @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
  --   @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 --@strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 --@strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 --@strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 --@strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
  --  GOTO MoveToNextRecord    
  -- END 

  IF (LEN(@strCDT_Fixed_Rate_Code_Temp) <= @intCONST_Fixed_Rate_Code)    
   BEGIN    
    SET @strCDT_Fixed_Rate_Code = @strCDT_Fixed_Rate_Code_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Fixed Rate Code exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --47. Cure Code
  --IF (@strCDT_Cure_Code_Temp = '') 
  -- BEGIN    
  --  SET @strErrorMessage = 'Cure Code is Null'    
  --  EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
  --    @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
  --    @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
  --    @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
  --    @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
  --    @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
  --    @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
  --    @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
  --   @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
  --   @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
  --   @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 --@strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 --@strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 --@strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 --@strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
  --  GOTO MoveToNextRecord    
  -- END 

  IF (LEN(@strCDT_Cure_Code_Temp) <= @intCONST_Cure_Code)    
   BEGIN    
    SET @strCDT_Cure_Code = @strCDT_Cure_Code_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Cure Code exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --48. Penal Code
  --IF (@strCDT_Penal_Code_Temp = '') 
  -- BEGIN    
  --  SET @strErrorMessage = 'Penal Code is Null'    
  --  EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
  --    @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
  --    @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
  --    @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
  --    @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
  --    @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
  --    @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
  --    @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
  --   @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
  --   @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
  --   @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 --@strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 --@strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 --@strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 --@strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
  --  GOTO MoveToNextRecord    
  -- END 

  IF (LEN(@strCDT_Penal_Code_Temp) <= @intCONST_Penal_Code)    
   BEGIN    
    SET @strCDT_Penal_Code = @strCDT_Penal_Code_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Penal Code exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --49. Minimum Code
  IF (@strCDT_Minimum_Code_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Minimum Code is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  IF (LEN(@strCDT_Minimum_Code_Temp) <= @intCONST_Minimum_Code)    
   BEGIN    
    SET @strCDT_Minimum_Code = @strCDT_Minimum_Code_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Minimum Code exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --50. Maximum Code
  IF (@strCDT_Maximum_Code_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Maximum Code is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  IF (LEN(@strCDT_Maximum_Code_Temp) <= @intCONST_Maximum_Code)    
   BEGIN    
    SET @strCDT_Maximum_Code = @strCDT_Maximum_Code_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Maximum Code exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

  --------START: <Checking all rate codes exist in database or not>---------
  Declare @value char(1)
  Set @value = (Select Value from fn_CheckDealerRateCode(@strCDT_Category_Name, @strCDT_Fixed_Rate_Code, @strCDT_Cure_Code,
				@strCDT_Penal_Code, @strCDT_Minimum_Code, @strCDT_Maximum_Code))

  If (@value = 'E')
  Begin
	SET @strErrorMessage = (Select RetMessage from fn_CheckDealerRateCode(@strCDT_Category_Name, @strCDT_Fixed_Rate_Code, @strCDT_Cure_Code,
				@strCDT_Penal_Code, @strCDT_Minimum_Code, @strCDT_Maximum_Code)) 
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
  End

  --fetch Category Code by Category Name
  ----Set @intCDT_Category_Code = (Select distinct CM_Category_Code From Category_Master Where CM_Category_Name = @strCDT_Category_Name)

   --------END: <Checking all rate codes exist in database or not>---------

  --51. Contact Person
  IF (LEN(@strCDT_Contact_Person_Temp) <= @intCONST_Contact_Person)    
   BEGIN    
    SET @strCDT_Contact_Person = @strCDT_Contact_Person_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Contact Person exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 

   --52. Mode Of Funding
  IF (@strCDT_Mode_Of_Funding_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Mode Of Funding is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END
   ELSE
   BEGIN
		SET @strCDT_Mode_Of_Funding = @strCDT_Mode_Of_Funding_Temp   
   END

      --53. Asset Classification
  IF (@strCDT_Asset_Classification_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Asset Classification is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END
  ELSE
   BEGIN
		SET @strCDT_Asset_Classification = @strCDT_Asset_Classification_Temp   
   END

      --54. Created Through Channel
  IF (@strCDT_Created_Channel_Temp = '') 
   BEGIN    
    SET @strErrorMessage = 'Created Through Channel is Null'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END

   IF (LEN(@strCDT_Created_Channel_Temp) <= @intCONST_Created_Channel)    
   BEGIN    
    SET @strCDT_Created_Channel = @strCDT_Created_Channel_Temp    
   END    
   ELSE    
   BEGIN    
    SET @strErrorMessage = 'Created Through Channel exceed the max length.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
    GOTO MoveToNextRecord    
   END 
  
   --|||||| VALIDATIONS End ||||||--    
        
   --|||||| CORPORATE Functionality [Start] ||||||--    
       
   --Checking Corporate existance    
   SELECT  @intCM_Corporate_Id = CM_Corporate_Id, @strCorporate_Status = CM_Status    
   FROM Corporate_Master    
   WHERE     
    CM_Parent_Limit_Id_Prefix = @strCDT_Parent_Limit_Id_Prefix AND    
    CM_Parent_Limit_Id_Suffix = @strCDT_Parent_Limit_Id_Suffix    
       
    
   IF (@intCM_Corporate_Id IS NULL) --IF Corporate does not exists then insert    
   BEGIN    
    
    BEGIN TRANSACTION    
    -- Parent Limit Prefix is also inserted in Corporate Code    
    INSERT INTO Corporate_Master    
     (    
      CM_Upload_File_Id, CM_Corporate_Name, CM_Corporate_Code, CM_Corporate_Division,    
      CM_Parent_Limit_Id_Prefix, CM_Parent_Limit_Id_Suffix, CM_Customer_Id, CM_No_Of_Dealers,    
      CM_SM_Name, CM_Mode_Of_Funding, CM_Classification, CM_Contact_Person,    
      CM_EMail1, CM_EMail2, CM_EMail3, CM_EMail4,    
      CM_EMail5, CM_EMail6, CM_Program_Rating, CM_Address1,    
      CM_Address2, CM_City, CM_State, CM_Pin,    
      CM_Doc1, CM_Doc2, CM_Doc3, CM_Doc4,    
      CM_Doc5, CM_Doc6, CM_Doc7, CM_Doc8,    
      CM_Doc9, CM_Doc10, CM_Status, CM_Remark,    
      CM_Created_By, CM_Created_On    
     )    
    VALUES    
     (    
      @intUploadFileId, @strCDT_Parent_Limit_Id_Prefix, @strCDT_Parent_Limit_Id_Prefix, NULL,    
      @strCDT_Parent_Limit_Id_Prefix, @strCDT_Parent_Limit_Id_Suffix, @strCDT_Customer_Id, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, NULL, 'A',  NULL,    
      @strCreatedBy, @dtCurrentDate    
     )    
    
    SET @intCM_Corporate_Id = IDENT_CURRENT('Corporate_Master') -- @@IDENTITY    
    SET @intErrorNo  = @@ERROR    
    
    --PRINT '@intCM_Corporate_Id : ' + Convert(varchar(20), @intCM_Corporate_Id)          
    
        
    --PRINT '@intCM_Corporate_Id=' + CONVERT(VARCHAR,@intCM_Corporate_Id)    
    --PRINT @intErrorNo    
    IF (@intErrorNo <> 0 OR @intCM_Corporate_Id IS NULL) --ERROR OCCURED    
    BEGIN    
     ROLLBACK TRANSACTION    
     SET @strErrorMessage = 'ERROR occured while inserting Corporate Master.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate    
     GOTO MoveToNextRecord    
    END     
        
--    IF EXISTS(SELECT CM_Upload_File_Id @intCM_Corporate_Id        
    INSERT INTO Corporate_Details    
     (    
      CD_Corporate_Id, CD_Program_Limit,    
      CD_Program_Sanction_Date, CD_Program_Expiry_Date, CD_Program_Renewal_Date,    
      CD_Tenor, CD_Cure_Code,     
      CD_Effective_From, CD_Effective_Till,     
      CD_Status, CD_Remarks,    
      CD_Created_By, CD_Created_On    
     )    
    VALUES    
     (    
      @intCM_Corporate_Id, @intCDT_Program_Limit,    
      @dtCDT_Program_Sanction_Date, @dtCDT_Program_Expiry_Date, @dtCDT_Program_Renewal_Date,    
NULL, NULL,    
      @dtCDT_Program_Sanction_Date, NULL,    
      'A', NULL,    
      @strCreatedBy, @dtCurrentDate    
     )    
    
    SET @intErrorNo = @@ERROR         
    IF (@intErrorNo <> 0)     
    BEGIN    
     ROLLBACK TRANSACTION    
     SET @strErrorMessage = 'ERROR occured while inserting Corporate Details.'    
     EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
     GOTO MoveToNextRecord    
    END    
    ELSE    
    BEGIN    
     COMMIT TRANSACTION    
    END    
   END    
   ELSE --If Corporate Exists then check whether corporate is 'R' the insert    
   BEGIN    
        
    /*    
    IF (@strCorporate_Status = 'A') --Corporate Exists with 'A' status    
    BEGIN    
        
     UPDATE  Corporate_Master    
     SET CM_Upload_File_Id = @intUploadFileId,    
      CM_Corporate_Code = @strCDT_Limit_Id_Prefix,    
      CM_Status   = 'P',    
      CM_Created_By     = @strCreatedBy,    
      CM_Created_On   = @dtCurrentDate    
     WHERE    
      CM_Parent_Limit_Id_Prefix = @strCDT_Parent_Limit_Id_Prefix AND    
      CM_Parent_Limit_Id_Suffix = @strCDT_Parent_Limit_Id_Suffix     
              
    END    
    IF (@strCorporate_Status = 'P') --Corporate Exists with 'P' status    
    BEGIN    
     SET @strErrorMessage = 'Corporate exists with Pending status.'    
     GOTO MoveToNextRecord    
    END    
    */        
    
    IF (UPPER(@strCorporate_Status) = 'R') --If Rejected Then treat as a new record    
    BEGIN    
     BEGIN TRANSACTION    
     INSERT INTO Corporate_Master    
      (    
       CM_Upload_File_Id, CM_Corporate_Name, CM_Corporate_Code, CM_Corporate_Division,    
       CM_Parent_Limit_Id_Prefix, CM_Parent_Limit_Id_Suffix, CM_Customer_Id, CM_No_Of_Dealers,    
       CM_SM_Name, CM_Mode_Of_Funding, CM_Classification, CM_Contact_Person,    
       CM_EMail1, CM_EMail2, CM_EMail3, CM_EMail4,    
       CM_EMail5, CM_EMail6, CM_Program_Rating, CM_Address1,    
       CM_Address2, CM_City, CM_State, CM_Pin,    
       CM_Doc1, CM_Doc2, CM_Doc3, CM_Doc4,    
       CM_Doc5, CM_Doc6, CM_Doc7, CM_Doc8,    
       CM_Doc9, CM_Doc10, CM_Status, CM_Remark,    
       CM_Created_By, CM_Created_On    
      )    
     VALUES    
      (    
       @intUploadFileId, @strCDT_Parent_Limit_Id_Prefix, @strCDT_Parent_Limit_Id_Prefix, NULL,    
       @strCDT_Parent_Limit_Id_Prefix, @strCDT_Parent_Limit_Id_Suffix, @strCDT_Customer_Id, NULL,    
       NULL, NULL, NULL, NULL,    
       NULL, NULL, NULL, NULL,    
       NULL, NULL, NULL, NULL,    
    
       NULL, NULL, NULL, NULL,    
       NULL, NULL, NULL, NULL,    
       NULL, NULL, NULL, NULL,    
       NULL, NULL, 'A',  NULL,    
       @strCreatedBy, @dtCurrentDate    
      )     
     SET @intCM_Corporate_Id = IDENT_CURRENT('Corporate_Master') -- @@IDENTITY    
     SET @intErrorNo  = @@ERROR    
--     PRINT '@intCM_Corporate_Id TTTT: ' + Convert(varchar(20), @intCM_Corporate_Id)    
    
     
     IF (@intErrorNo <> 0 OR @intCM_Corporate_Id IS NULL) --ERROR OCCURED    
     BEGIN    
      ROLLBACK TRANSACTION    
      SET @strErrorMessage = 'ERROR occured while inserting Corporate Master.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
      GOTO MoveToNextRecord    
     END    
         
     INSERT INTO Corporate_Details    
      (    
       CD_Corporate_Id, CD_Program_Limit,    
       CD_Program_Sanction_Date, CD_Program_Expiry_Date, CD_Program_Renewal_Date,    
       CD_Tenor, CD_Cure_Code,     
       CD_Effective_From, CD_Effective_Till,     
       CD_Status, CD_Remarks,    
       CD_Created_By, CD_Created_On    
      )    
     VALUES    
      (    
       @intCM_Corporate_Id, @intCDT_Program_Limit,    
       @dtCDT_Program_Sanction_Date, @dtCDT_Program_Expiry_Date, @dtCDT_Program_Renewal_Date,    
       NULL, NULL,    
       @dtCDT_Program_Sanction_Date, NULL,    
       'A', NULL,    
       @strCreatedBy, @dtCurrentDate    
      )    
     
     SET @intErrorNo  = @@ERROR    
     IF (@intErrorNo <> 0) --ERROR OCCURED    
     BEGIN    
      ROLLBACK TRANSACTION    
      SET @strErrorMessage = 'ERROR occured while inserting Corporate Details.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
      GOTO MoveToNextRecord    
    
     END    
     ELSE    
     BEGIN    
      COMMIT TRANSACTION    
     END    
    END        
   END       
   --|||||| CORPORATE Functionality [End] ||||||--    
    
   --|||||| DEALER Functionality [Start] ||||||--       
       
   --Checking Dealer existance    
    
   SELECT  @intDM_Dealer_Id = DM_Dealer_Id, @strDealer_Status = DM_Status    
   FROM Dealer_Master    
   WHERE     
    DM_Limit_Id_Prefix = @strCDT_Limit_Id_Prefix AND    
    DM_Limit_Id_Suffix = @strCDT_Limit_Id_Suffix    
       
   IF (@intDM_Dealer_Id IS NULL) --IF Dealer does not exists    
   BEGIN    
    BEGIN TRANSACTION    
    
    INSERT INTO Dealer_Master    
     (    
      DM_Upload_File_Id, DM_Corporate_Id, DM_Dealer_Name, DM_Dealer_Short_Name,     
      DM_Account_No, DM_Customer_Id, DM_Parent_Limit_Id_Prefix, DM_Parent_Limit_Id_Suffix,     
      DM_Limit_Id_Prefix, DM_Limit_Id_Suffix, DM_SM_Name, DM_CRM_Name,     
      DM_Account_Status, DM_Account_Open_Date, DM_Account_Close_Date, DM_Address1,     
      DM_Address2, DM_City, DM_State, DM_Pin,     
      DM_Phone_No, DM_Contact_Person, DM_Email1, DM_Email2,     
      DM_Email3, DM_Documentation_Date, DM_Mode_Of_Funding, DM_SM_EMail,     
      DM_Asset_Classification, DM_Dealer_Rating, DM_Sol_ID,DM_Dealer_Corporate_Name, DM_Doc1, DM_Doc2,     
      DM_Doc3, DM_Doc4, DM_Doc5, DM_Doc6,     
      DM_Doc7, DM_Doc8, DM_Doc9, DM_Doc10, DM_TOD_Flag,    
      DM_Status, DM_Remark, DM_Created_By, DM_Created_On, DM_Created_Channel     
     )    
     VALUES    
     (    
      @intUploadFileId, @intCM_Corporate_Id, @strCDT_Dealer_Name, @strCDT_Dealer_Short_Name,    
      @strCDT_Account_No, @strCDT_Customer_Id, @strCDT_Parent_Limit_Id_Prefix, @strCDT_Parent_Limit_Id_Suffix,    
      @strCDT_Limit_Id_Prefix, @strCDT_Limit_Id_Suffix, @strCDT_SM_Name, @strCDT_CRM_Name,    
      @strCDT_Account_Status, @dtCDT_Account_Open_Date, @dtCDT_Account_Close_Date, @strCDT_Address1,    
      @strCDT_Address2, @strCDT_City, @strCDT_State, @strCDT_Pin,    
      @strCDT_Phone_No, @strCDT_Contact_Person, @strCDT_Email_Id, NULL,    
      NULL, @dtCDT_Documentation_Date, @strCDT_Mode_Of_Funding, @strCDT_SM_Email,    
      @strCDT_Asset_Classification, NULL, @strCDT_Sol_Id,@strCDT_DealerCorpName, @strCDT_Doc1, @strCDT_Doc2,    
      @strCDT_Doc3, @strCDT_Doc4, @strCDT_Doc5, @strCDT_Doc6,    
      @strCDT_Doc7, @strCDT_Doc8, @strCDT_Doc9, @strCDT_Doc10, 'N',    
      'A', NULL, @strCreatedBy, @dtCurrentDate, @strCDT_Created_Channel    
     )    
     SET @intDM_Dealer_Id = IDENT_CURRENT('Dealer_Master') --@@IDENTITY    
     --print '@@IDENTITY : ' + CONVERT(VARCHAR,@@IDENTITY)    
     SET @intErrorNo  = @@ERROR    
     
     IF (@intErrorNo <> 0 OR @intDM_Dealer_Id IS NULL) --ERROR OCCURED    
     BEGIN    
      ROLLBACK TRANSACTION    
      SET @strErrorMessage = 'ERROR occured while inserting Dealer Master.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
      GOTO MoveToNextRecord    
     END    
     --print '@intDM_Dealer_Id : ' + CONVERT(VARCHAR,@intDM_Dealer_Id)    
    
     INSERT INTO Dealer_Details    
     (    
      DD_Dealer_Id, DD_Tenor, DD_Dealer_Limit, DD_Sanction_Date,    
      DD_Expiry_Date, DD_Renewal_Date, DD_Category_Code, DD_Rate_Code,    
      DD_Fixed_Rate_Code, DD_Cure_Code, DD_Penal_Code, DD_Minimum_Code,    
      DD_Maximum_Code, DD_No_Of_Peak_Usage,  DD_Peak_Interest, DD_Peak_Tenor,    
      DD_Peak_Limit, DD_Peak_Effective_From, DD_Peak_Effective_Till, DD_TOD_Code,     
      DD_TOD_Margin, DD_Effective_From, DD_Effective_Till, DD_Status,     
      DD_Remark, DD_Created_By, DD_Created_On    
     )    
     VALUES    
     (    
      @intDM_Dealer_Id, @intCDT_Credit_Tenor, @intCDT_Dealer_Limit, @dtCDT_Dealer_Sanction_Date,    
      @dtCDT_Dealer_Expiry_Date, @dtCDT_Dealer_Renewal_Date,  @intCDT_Category_Code, @intCDT_Rate_Code,    
      @strCDT_Fixed_Rate_Code, @strCDT_Cure_Code, @strCDT_Penal_Code, @strCDT_Minimum_Code,    
      @strCDT_Maximum_Code, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, @dtCDT_Account_Open_Date, NULL, 'A',    
      NULL, @strCreatedBy, @dtCurrentDate    
     )    
    
     SET @intErrorNo = @@ERROR    
     
     IF (@intErrorNo <> 0) --ERROR OCCURED    
     BEGIN    
      ROLLBACK TRANSACTION    
      SET @strErrorMessage = 'ERROR occured while inserting Dealer Details.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
      GOTO MoveToNextRecord    
     END    
     ELSE    
     BEGIN    
      COMMIT TRANSACTION    
     END    
   END    
   ELSE    
   BEGIN    
    IF (UPPER(@strDealer_Status) = 'R') --If Dealer status is rejected    
    BEGIN    
     BEGIN TRANSACTION    
    
     INSERT INTO Dealer_Master    
     (    
      DM_Upload_File_Id, DM_Corporate_Id, DM_Dealer_Name, DM_Dealer_Short_Name,     
      DM_Account_No, DM_Customer_Id, DM_Parent_Limit_Id_Prefix, DM_Parent_Limit_Id_Suffix,     
      DM_Limit_Id_Prefix, DM_Limit_Id_Suffix, DM_SM_Name, DM_CRM_Name,     
      DM_Account_Status, DM_Account_Open_Date, DM_Account_Close_Date, DM_Address1,     
      DM_Address2, DM_City, DM_State, DM_Pin,     
      DM_Phone_No, DM_Contact_Person, DM_Email1, DM_Email2,     
      DM_Email3, DM_Documentation_Date, DM_Mode_Of_Funding, DM_SM_EMail,     
      DM_Asset_Classification, DM_Dealer_Rating, DM_Sol_ID,DM_Dealer_Corporate_Name,  
	  DM_Doc1, DM_Doc2,     
      DM_Doc3, DM_Doc4, DM_Doc5, DM_Doc6,     
      DM_Doc7, DM_Doc8, DM_Doc9, DM_Doc10, DM_TOD_Flag,    
      DM_Status, DM_Remark, DM_Created_By, DM_Created_On, DM_Created_Channel     
     )    
     VALUES    
     (    
      @intUploadFileId, @intCM_Corporate_Id, @strCDT_Dealer_Name, @strCDT_Dealer_Short_Name,    
      @strCDT_Account_No, @strCDT_Customer_Id, @strCDT_Parent_Limit_Id_Prefix, @strCDT_Parent_Limit_Id_Suffix,    
      @strCDT_Limit_Id_Prefix, @strCDT_Limit_Id_Suffix, @strCDT_SM_Name, @strCDT_CRM_Name,    
      @strCDT_Account_Status, @dtCDT_Account_Open_Date, @dtCDT_Account_Close_Date, @strCDT_Address1,    
      @strCDT_Address2, @strCDT_City, @strCDT_State, @strCDT_Pin,    
      @strCDT_Phone_No, @strCDT_Contact_Person, @strCDT_Email_Id, NULL,    
      NULL, @dtCDT_Documentation_Date, @strCDT_Mode_Of_Funding, @strCDT_SM_Email,    
      @strCDT_Asset_Classification, NULL, @strCDT_Sol_Id,@strCDT_DealerCorpName, @strCDT_Doc1, @strCDT_Doc2,    
      @strCDT_Doc3, @strCDT_Doc4, @strCDT_Doc5, @strCDT_Doc6,    
      @strCDT_Doc7, @strCDT_Doc8, @strCDT_Doc9, @strCDT_Doc10, 'N',    
      'A', NULL, @strCreatedBy, @dtCurrentDate, @strCDT_Created_Channel    
     )    
     SET @intDM_Dealer_Id = IDENT_CURRENT('Dealer_Master') --@@IDENTITY    
     SET @intErrorNo      = @@ERROR    
     
     IF (@intErrorNo <> 0 OR @intDM_Dealer_Id IS NULL) --ERROR OCCURED    
     BEGIN    
      ROLLBACK TRANSACTION    
      SET @strErrorMessage = 'ERROR occured while inserting Dealer Master.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
      GOTO MoveToNextRecord    
     END    
    
     INSERT INTO Dealer_Details    
     (    
      DD_Dealer_Id, DD_Tenor, DD_Dealer_Limit, DD_Sanction_Date,    
      DD_Expiry_Date, DD_Renewal_Date, DD_Category_Code, DD_Rate_Code,    
      DD_Fixed_Rate_Code, DD_Cure_Code, DD_Penal_Code, DD_Minimum_Code,    
      DD_Maximum_Code, DD_No_Of_Peak_Usage,  DD_Peak_Interest, DD_Peak_Tenor,    
      DD_Peak_Limit, DD_Peak_Effective_From, DD_Peak_Effective_Till, DD_TOD_Code,     
      DD_TOD_Margin, DD_Effective_From, DD_Effective_Till, DD_Status,     
      DD_Remark, DD_Created_By, DD_Created_On    
     )    
     VALUES    
     (    
      @intDM_Dealer_Id, @intCDT_Credit_Tenor, @intCDT_Dealer_Limit, @dtCDT_Dealer_Sanction_Date,    
      @dtCDT_Dealer_Expiry_Date, @dtCDT_Dealer_Renewal_Date,  @intCDT_Category_Code, @intCDT_Rate_Code,    
      @strCDT_Fixed_Rate_Code, @strCDT_Cure_Code, @strCDT_Penal_Code, @strCDT_Minimum_Code,    
      @strCDT_Maximum_Code, NULL, NULL, NULL,    
      NULL, NULL, NULL, NULL,    
      NULL, @dtCDT_Account_Open_Date, NULL, 'A',    
      NULL, @strCreatedBy, @dtCurrentDate    
     )    
     SET @intErrorNo  = @@ERROR    
     
     IF (@intErrorNo <> 0) --ERROR OCCURED    
     BEGIN    
      ROLLBACK TRANSACTION    
      SET @strErrorMessage = 'ERROR occured while inserting Dealer details.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate        
      GOTO MoveToNextRecord    
     END    
    
     COMMIT TRANSACTION    
    END    
    ELSE    
    BEGIN    
     SET @strErrorMessage = 'Dealer already exists.'    
    EXECUTE usp_CorporateDealerServiceUploadErrorAdd    
      @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp, @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
      @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp, @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
      @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp, @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
      @strCDT_Address2_Temp, @strCDT_City_Temp, @strCDT_State_Temp, @strCDT_Pin_Temp,    
      @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp, @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
      @strCDT_Account_Status, @strCDT_Program_Limit_Temp, @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
      @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp, @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
     @strCDT_Doc3_Temp, @strCDT_Doc4_Temp, @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
     @strCDT_Doc7_Temp, @strCDT_Doc8_Temp, @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,     
     @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp, 
	 @strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	 @strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	 @strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	 @strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp,
	 @strCDT_DealerCorpName_Temp, @strErrorMessage, @strCreatedBy, @strCurrentDate       
     GOTO MoveToNextRecord    
    END    
   END    
   --|||||| DEALER Functionality [End]   ||||||--    
   SET @intSuccessCount = @intSuccessCount + 1    
    
    
MoveToNextRecord:    
   --Flushing variables used inside the trigger--    
    
   SET @strCDT_Dealer_Name_Temp  = NULL    
   SET @strCDT_Account_No_Temp  = NULL    
   SET @strCDT_Customer_Id_Temp  = NULL    
   SET @strCDT_Dealer_Limit_Temp  = NULL    
   SET @strCDT_Dealer_Sanction_Date_Temp = NULL    
   SET @strCDT_Dealer_Expiry_Date_Temp = NULL    
   SET @strCDT_Dealer_Renewal_Date_Temp = NULL    
   SET @strCDT_Limit_Id_Prefix_Temp = NULL    
   SET @strCDT_Limit_Id_Suffix_Temp = NULL    
   SET @strCDT_Parent_Limit_Id_Prefix_Temp = NULL    
   SET @strCDT_Parent_Limit_Id_Suffix_Temp = NULL    
   SET @strCDT_Address1_Temp  = NULL    
   SET @strCDT_Address2_Temp  = NULL    
   SET @strCDT_City_Temp   = NULL     
   SET @strCDT_State_Temp   = NULL    
   SET @strCDT_Pin_Temp   = NULL    
   SET @strCDT_Phone_No_Temp  = NULL    
   SET @strCDT_Email_Id_Temp  = NULL    
   SET @strCDT_Account_Open_Date_Temp = NULL    
   SET @strCDT_Account_Close_Date_Temp = NULL    
   SET @strCDT_Account_Status_Temp  = NULL     
   SET @strCDT_Program_Limit_Temp   = NULL    
    SET @strCDT_Program_Sanction_Date_Temp = NULL    
   SET @strCDT_Program_Expiry_Date_Temp  = NULL    
   SET @strCDT_Program_Renewal_Date_Temp = NULL    
   SET @strCDT_Documentation_Date_Temp = NULL    
   SET @strCDT_Doc1_Temp    = NULL    
   SET @strCDT_Doc2_Temp   = NULL    
   SET @strCDT_Doc3_Temp   = NULL    
   SET @strCDT_Doc4_Temp   = NULL    
   SET @strCDT_Doc5_Temp   = NULL    
   SET @strCDT_Doc6_Temp   = NULL       
   SET @strCDT_Doc7_Temp   = NULL    
   SET @strCDT_Doc8_Temp   = NULL    
   SET @strCDT_Doc9_Temp   = NULL    
   SET @strCDT_Doc10_Temp   = NULL    
   SET @strCDT_Dealer_Short_Name_Temp = NULL    
   SET @strCDT_Sol_ID_Temp   = NULL   
   SET @strCDT_DealerCorpName_Temp=NULL
   SET @strCDT_SM_Email_Temp   = NULL    
   SET @strCDT_SM_Name_Temp   = NULL    
   SET @strCDT_CRM_Name_Temp   = NULL    
   SET @strCDT_Credit_Tenor_Temp = NULL    
   SET @strCDT_Category_Name_Temp   = NULL   
   SET @strCDT_Rate_Code_Temp=NULL   
   SET @strCDT_Fixed_Rate_Code_Temp   = NULL    
   SET @strCDT_Cure_Code_Temp   = NULL    
   SET @strCDT_Penal_Code_Temp   = NULL    
   SET @strCDT_Minimum_Code_Temp = NULL    
   SET @strCDT_Maximum_Code_Temp   = NULL   
   SET @strCDT_Contact_Person_Temp=NULL
   SET @strCDT_Mode_Of_Funding_Temp=NULL	
   SET @strCDT_Asset_Classification_Temp=NULL   
   SET @strCDT_Created_Channel_Temp=NULL   

    
   SET @intCM_Corporate_Id   = NULL    
   SET @strCorporate_Status  = NULL    
   SET @intDM_Dealer_Id   = NULL     
   SET @strDealer_Status   = NULL    
   SET @intErrorNo    = NULL    
    
   -----------------------------------------------    
    
   FETCH NEXT FROM CorporateDealer_Cursor    
   INTO     
    @strCDT_Dealer_Name_Temp, @strCDT_Account_No_Temp,    
    @strCDT_Customer_Id_Temp, @strCDT_Dealer_Limit_Temp,    
    @strCDT_Dealer_Sanction_Date_Temp, @strCDT_Dealer_Expiry_Date_Temp,    
    @strCDT_Dealer_Renewal_Date_Temp, @strCDT_Limit_Id_Prefix_Temp,    
    @strCDT_Limit_Id_Suffix_Temp, @strCDT_Parent_Limit_Id_Prefix_Temp,    
    @strCDT_Parent_Limit_Id_Suffix_Temp, @strCDT_Address1_Temp,    
    @strCDT_Address2_Temp, @strCDT_City_Temp,    
    @strCDT_State_Temp, @strCDT_Pin_Temp,    
    @strCDT_Phone_No_Temp, @strCDT_Email_Id_Temp,    
    @strCDT_Account_Open_Date_Temp, @strCDT_Account_Close_Date_Temp,    
    @strCDT_Account_Status_Temp, @strCDT_Program_Limit_Temp,     
     @strCDT_Program_Sanction_Date_Temp, @strCDT_Program_Expiry_Date_Temp,     
    @strCDT_Program_Renewal_Date_Temp, @strCDT_Documentation_Date_Temp,    
    @strCDT_Doc1_Temp, @strCDT_Doc2_Temp,     
    @strCDT_Doc3_Temp, @strCDT_Doc4_Temp,     
    @strCDT_Doc5_Temp, @strCDT_Doc6_Temp,     
    @strCDT_Doc7_Temp, @strCDT_Doc8_Temp,     
    @strCDT_Doc9_Temp, @strCDT_Doc10_Temp,    
    @strCDT_Dealer_Short_Name_Temp, @strCDT_Sol_ID_Temp,@strCDT_DealerCorpName_Temp,
	@strCDT_SM_Email_Temp, @strCDT_SM_Name_Temp, @strCDT_CRM_Name_Temp, @strCDT_Credit_Tenor_Temp, @strCDT_Category_Name_Temp,
	@strCDT_Rate_Code_Temp, @strCDT_Fixed_Rate_Code_Temp, @strCDT_Cure_Code_Temp, @strCDT_Penal_Code_Temp, 
	@strCDT_Minimum_Code_Temp, @strCDT_Maximum_Code_Temp, @strCDT_Contact_Person_Temp,
	@strCDT_Mode_Of_Funding_Temp, @strCDT_Asset_Classification_Temp, @strCDT_Created_Channel_Temp  
       
  END    
    
  CLOSE CorporateDealer_Cursor    
  DEALLOCATE CorporateDealer_Cursor    
      
  SELECT @intFailureCount = COUNT(CDES_Error_Id) FROM Corporate_Dealer_Error_Service   
  UPDATE UPLOAD_SERVICE_MASTER SET USM_Success_Records = @intSuccessCount, USM_Failure_Records = @intFailureCount WHERE USM_Service_File_Id = @intUploadFileId    
    
  SET @o_strSuccessRecords = CONVERT(VARCHAR, @intSuccessCount)    
  SET @o_strFailureRecords = CONVERT(VARCHAR, @intFailureCount)       
  SELECT @intTotalCount    = USM_Total_Records from UPLOAD_SERVICE_MASTER WHERE USM_Service_File_Id = @intUploadFileId    
  SET @o_strTotalRecords  = @intTotalCount    
     
  IF (@intSuccessCount = @intTotalCount)    
   SET @o_strReturnFlag    = 'S'    
  ELSE    
   SET @o_strReturnFlag    = 'E'    
      
 END    
     
 --///////////Updating upload flag to 'N'///////////////////     
 UPDATE System_Status_Master SET SSM_Para_Value = 'N'     
 WHERE UPPER(SSM_Para_Name) = 'CORPORATE_DEALER_UPLOAD_FLAG'    
     
 SET @intErrorNo = @@ERROR    
 IF (@intErrorNo <> 0)    
 BEGIN      
  SET @o_strReturnFlag = 'E'     
 END    
 --///////////////////////////////////////////////////////    
    
SET NOCOUNT OFF    
END 