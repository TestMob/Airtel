USE [CFS]
GO
/****** Object:  StoredProcedure [dbo].[usp_CorporateDealerServiceUploadErrorAdd]    Script Date: 09-05-2018 15:25:35 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

    
ALTER  PROCEDURE [usp_CorporateDealerServiceUploadErrorAdd]    
   @i_strDealer_Name  AS VARCHAR(100),     
   @i_strAccount_No  AS VARCHAR(100),    
   @i_strCustomer_Id  AS VARCHAR(100),     
   @i_strDealer_Limit   AS VARCHAR(100),     
   @i_strDealer_Sanction_Date  AS VARCHAR(100),     
   @i_strDealer_Expiry_Date AS VARCHAR(100),     
   @i_strDealer_Renewal_Date AS VARCHAR(100),     
   @i_strLimit_Id_Prefix   AS VARCHAR(100),     
   @i_strLimit_Id_Suffix   AS VARCHAR(100),     
   @i_strParent_Limit_Id_Prefix  AS VARCHAR(100),     
   @i_strParent_Limit_Id_Suffix  AS VARCHAR(100),     
   @i_strAddress1   AS VARCHAR(250),     
   @i_strAddress2   AS VARCHAR(250),     
   @i_strCity   AS VARCHAR(100),     
   @i_strState   AS VARCHAR(100),     
   @i_strPin   AS VARCHAR(100),     
   @i_strPhone_No   AS VARCHAR(100),     
   @i_strEmail_Id   AS VARCHAR(100),     
   @i_strAccount_Open_Date AS VARCHAR(100),     
   @i_strAccount_Close_Date AS VARCHAR(100),     
   @i_strAccount_Status  AS VARCHAR(100),     
   @i_strProgram_Limit  AS VARCHAR(100),     
   @i_strProgram_Sanction_Date AS VARCHAR(100),     
   @i_strProgram_Expiry_Date AS VARCHAR(100),     
   @i_strProgram_Renewal_Date AS VARCHAR(100),     
   @i_strDocumentation_Date AS VARCHAR(100),     
   @i_strDoc1   AS VARCHAR(100),     
   @i_strDoc2   AS VARCHAR(100),     
   @i_strDoc3   AS VARCHAR(100),     
   @i_strDoc4   AS VARCHAR(100),     
   @i_strDoc5   AS VARCHAR(100),     
   @i_strDoc6   AS VARCHAR(100),     
   @i_strDoc7   AS VARCHAR(100),     
   @i_strDoc8   AS VARCHAR(100),     
   @i_strDoc9   AS VARCHAR(100),     
   @i_strDoc10   AS VARCHAR(100),    
   @i_strDealer_Short_Name AS VARCHAR(100),    
   @i_strSol_ID   AS VARCHAR(100),   
   @i_strSMEmail varchar(100),
   @i_strNameOfSM varchar(100),
   @i_strNameOfCRM varchar(100),
   @i_strCreditTenor varchar(100),
   @i_strCategoryCode varchar(100),
   @i_strRateCode varchar(100),
   @i_strFixedRateCode varchar(100),
   @i_strCureCode varchar(100),
   @i_strPenalCode varchar(100),
   @i_strMinimumCode varchar(100),
   @i_strMaximumCode varchar(100),
   @i_strContactPerson varchar(100), 
   @i_strModeOfFunding char(1),
   @i_strAssetClassification char(1),
   @i_strCreatedChannel varchar(100),
   --New variable added by Suchi--   
   @i_strDealerCorp_Name   AS VARCHAR(50),  
   @i_strErrorMessage   AS VARCHAR(250),    
   @i_strCreatedBy      AS VARCHAR(100),    
   @i_strCreatedOn      AS VARCHAR(25)     
    
     
AS    
BEGIN    
    
 BEGIN    
  DECLARE @dtCurrentDate AS DATETIME    
  DECLARE @intErrorNo    AS NUMERIC(10)    
  SET @dtCurrentDate = CONVERT(DATETIME, @i_strCreatedOn)    
 END    
    
 INSERT INTO Corporate_Dealer_Error_Service   
 (    
  CDES_Dealer_Name, CDES_Account_No,CDES_Customer_Id, CDES_Dealer_Limit,    
  CDES_Dealer_Sanction_Date, CDES_Dealer_Expiry_Date, CDES_Dealer_Renewal_Date, CDES_Limit_Id_Prefix,    
  CDES_Limit_Id_Suffix, CDES_Parent_Limit_Id_Prefix, CDES_Parent_Limit_Id_Suffix, CDES_Address1,    
  CDES_Address2, CDES_City, CDES_State, CDES_Pin,    
  CDES_Phone_No, CDES_Email_Id, CDES_Account_Open_Date, CDES_Account_Close_Date,    
  CDES_Account_Status, CDES_Program_Limit, CDES_Program_Sanction_Date, CDES_Program_Expiry_Date,    
  CDES_Program_Renewal_Date, CDES_Documentation_Date, CDES_Doc1, CDES_Doc2,     
  CDES_Doc3, CDES_Doc4, CDES_Doc5, CDES_Doc6,     
  CDES_Doc7,CDES_Doc8, CDES_Doc9, CDES_Doc10,     
  CDES_Dealer_Short_Name, CDES_Sol_ID,CDES_Dealer_Corporate_Name, CDES_Error_Message, CDES_Created_By, CDES_Created_On,
  CDES_SM_Email_ID, CDES_Name_Of_SM, CDES_Name_Of_CRM, CDES_Credit_Tenor, CDES_Category_Name, CDES_Rate_Code, CDES_Fixed_Rate_Code,
  CDES_Cure_Code, CDES_Penal_Code, CDES_Minimum_Code, CDES_Maximum_Code, CDES_Contact_Person,
  CDES_Mode_Of_Funding, CDES_Asset_Classification, CDES_Created_Channel  
 )         
 VALUES     
 (     
  @i_strDealer_Name, @i_strAccount_No, @i_strCustomer_Id, @i_strDealer_Limit,     
  @i_strDealer_Sanction_Date, @i_strDealer_Expiry_Date, @i_strDealer_Renewal_Date, @i_strLimit_Id_Prefix,    
  @i_strLimit_Id_Suffix, @i_strParent_Limit_Id_Prefix, @i_strParent_Limit_Id_Suffix, @i_strAddress1,    
  @i_strAddress2, @i_strCity, @i_strState, @i_strPin,    
  @i_strPhone_No, @i_strEmail_Id, @i_strAccount_Open_Date, @i_strAccount_Close_Date,    
  @i_strAccount_Status, @i_strProgram_Limit, @i_strProgram_Sanction_Date, @i_strProgram_Expiry_Date,    
  @i_strProgram_Renewal_Date, @i_strDocumentation_Date, @i_strDoc1, @i_strDoc2,     
  @i_strDoc3, @i_strDoc4, @i_strDoc5, @i_strDoc6,     
  @i_strDoc7, @i_strDoc8, @i_strDoc9, @i_strDoc10,     
  @i_strDealer_Short_Name, @i_strSol_ID,@i_strDealerCorp_Name, @i_strErrorMessage, @i_strCreatedBy, @dtCurrentDate,
  @i_strSMEmail, @i_strNameOfSM, @i_strNameOfCRM, @i_strCreditTenor, @i_strCategoryCode, @i_strRateCode, @i_strFixedRateCode,
  @i_strCureCode, @i_strPenalCode, @i_strMinimumCode, @i_strMaximumCode, @i_strContactPerson,
  @i_strModeOfFunding, @i_strAssetClassification, @i_strCreatedChannel   
 )    
    
 SET @intErrorNo = @@ERROR    
 IF(@intErrorNo <> 0) --IF ERROR THEN JUST RETURN    
 BEGIN    
  RETURN     
 END      
    
END 