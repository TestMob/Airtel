USE [CFS]
GO

/****** Object:  Table [dbo].[Corporate_Dealer_Error_Service]    Script Date: 09-05-2018 15:33:04 ******/
--DROP TABLE [Corporate_Dealer_Error_Service]
GO

/****** Object:  Table [dbo].[Corporate_Dealer_Error_Service]    Script Date: 09-05-2018 15:33:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Corporate_Dealer_Error_Service](
	[CDES_Error_Id] [numeric](12, 0) IDENTITY(1,1) NOT NULL,
	[CDES_Dealer_Name] [varchar](100) NULL,
	[CDES_Account_No] [varchar](100) NULL,
	[CDES_Customer_Id] [varchar](100) NULL,
	[CDES_Dealer_Limit] [varchar](100) NULL,
	[CDES_Dealer_Sanction_Date] [varchar](100) NULL,
	[CDES_Dealer_Expiry_Date] [varchar](100) NULL,
	[CDES_Dealer_Renewal_Date] [varchar](100) NULL,
	[CDES_Limit_Id_Prefix] [varchar](100) NULL,
	[CDES_Limit_Id_Suffix] [varchar](100) NULL,
	[CDES_Parent_Limit_Id_Prefix] [varchar](100) NULL,
	[CDES_Parent_Limit_Id_Suffix] [varchar](100) NULL,
	[CDES_Address1] [varchar](100) NULL,
	[CDES_Address2] [varchar](100) NULL,
	[CDES_City] [varchar](100) NULL,
	[CDES_State] [varchar](100) NULL,
	[CDES_Pin] [varchar](100) NULL,
	[CDES_Phone_No] [varchar](100) NULL,
	[CDES_Email_Id] [varchar](100) NULL,
	[CDES_Account_Open_Date] [varchar](100) NULL,
	[CDES_Account_Close_Date] [varchar](100) NULL,
	[CDES_Account_Status] [varchar](100) NULL,
	[CDES_Program_Limit] [varchar](100) NULL,
	[CDES_Program_Sanction_Date] [varchar](100) NULL,
	[CDES_Program_Expiry_Date] [varchar](100) NULL,
	[CDES_Program_Renewal_Date] [varchar](100) NULL,
	[CDES_Documentation_Date] [varchar](100) NULL,
	[CDES_Doc1] [varchar](100) NULL,
	[CDES_Doc2] [varchar](100) NULL,
	[CDES_Doc3] [varchar](100) NULL,
	[CDES_Doc4] [varchar](100) NULL,
	[CDES_Doc5] [varchar](100) NULL,
	[CDES_Doc6] [varchar](100) NULL,
	[CDES_Doc7] [varchar](100) NULL,
	[CDES_Doc8] [varchar](100) NULL,
	[CDES_Doc9] [varchar](100) NULL,
	[CDES_Doc10] [varchar](100) NULL,
	[CDES_Dealer_Short_Name] [varchar](100) NULL,
	[CDES_Sol_ID] [varchar](100) NULL,
	[CDES_SM_Email_ID] [varchar](100) NULL,
	[CDES_Name_Of_SM] [varchar](100) NULL,
	[CDES_Name_Of_CRM] [varchar](100) NULL,
	[CDES_Credit_Tenor] [varchar](100) NULL,
	[CDES_Category_Name] [varchar](100) NULL,
	[CDES_Rate_Code] [varchar](100) NULL,
	[CDES_Fixed_Rate_Code] [varchar](100) NULL,
	[CDES_Cure_Code] [varchar](100) NULL,
	[CDES_Penal_Code] [varchar](100) NULL,
	[CDES_Minimum_Code] [varchar](100) NULL,
	[CDES_Maximum_Code] [varchar](100) NULL,
	[CDES_Contact_Person] [varchar](100) NULL,
	[CDES_Mode_Of_Funding] [char](1) NULL,
	[CDES_Asset_Classification] [char](1) NULL,
	[CDES_Created_Channel] [varchar](100) NULL,
	[CDES_Error_Message] [varchar](100) NULL,
	[CDES_Created_By] [varchar](15) NOT NULL,
	[CDES_Created_On] [datetime] NOT NULL,
	[CDES_Dealer_Corporate_Name] [varchar](50) NULL,
 CONSTRAINT [PK_Corporate_Dealer_Error_Service_Id] PRIMARY KEY CLUSTERED 
(
	[CDES_Error_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


