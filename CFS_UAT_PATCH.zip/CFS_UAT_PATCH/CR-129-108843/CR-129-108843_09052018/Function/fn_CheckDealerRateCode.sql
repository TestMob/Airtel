USE [CFS]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_CheckDealerRateCode]    Script Date: 09-05-2018 15:22:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [fn_CheckDealerRateCode]        
(@i_strCategoryCode VARCHAR(40),        
 @i_strFixedRateCode VARCHAR(20),        
 @i_strCureCode VARCHAR(20),
 @i_strPenalCode VARCHAR(20),
 @i_strMinimumCode VARCHAR(20),
 @i_strMaximumCode VARCHAR(20)
 )        
         
 RETURNS @ValueTable TABLE(Value char(1), RetMessage VARCHAR(200))        
 AS        
 BEGIN        
 DECLARE @Value char(1), @RetMessage VARCHAR(200)
 Set @Value = 'S'
 Set @RetMessage = ''
 
 If (@i_strCategoryCode Is Not Null And @i_strCategoryCode <> '') And 
 Not Exists(Select CM_Category_Name From Category_Master Where CM_Category_Name = @i_strCategoryCode And CM_Status = 'A' And CM_Enabled = 'Y'
				And CM_Category_Id IN (SELECT MAX(CM_Category_Id) FROM Category_Master WHERE CM_Status = 'A' GROUP BY CM_Category_Code))
 Begin
	Set @Value = 'E'
	Set @RetMessage = 'Category Name ''' + @i_strCategoryCode + ''' does not exist'

	Goto AddData
 End
 Else If (@i_strCureCode Is Not Null And @i_strCureCode <> '') And 
 Not Exists(Select CM_Cure_Code From Cure_Master Where CM_Cure_Code = @i_strCureCode And CM_Status = 'A' And CM_Enabled = 'Y'
					And CM_Cure_Id IN (SELECT MAX(CM_Cure_Id) FROM Cure_Master WHERE CM_Status = 'A' GROUP BY CM_Cure_Code))
 Begin
	Set @Value = 'E'
	Set @RetMessage = 'Cure Rate Code ''' + @i_strCureCode + ''' does not exist'

	Goto AddData
 End
 Else If (@i_strFixedRateCode Is Not Null And @i_strFixedRateCode <> '') And 
 Not Exists(Select FRM_Fixed_Rate_Code From Fixed_Rate_Master Where FRM_Fixed_Rate_Code = @i_strFixedRateCode And FRM_Status = 'A' And FRM_Enabled = 'Y'
					And FRM_Rate_Id IN (SELECT MAX(FRM_Rate_Id) FROM Fixed_Rate_Master WHERE FRM_Status = 'A' GROUP BY FRM_Fixed_Rate_Code))
 Begin
	Set @Value = 'E'
	Set @RetMessage = 'Fixed Rate Code ''' + @i_strFixedRateCode + ''' does not exist'

	Goto AddData
 End
 Else If (@i_strPenalCode Is Not Null And @i_strPenalCode <> '') And 
 Not Exists(Select PM_Penal_Code From Penal_Master Where PM_Penal_Code = @i_strPenalCode And PM_Status = 'A' And PM_Enabled = 'Y'
					And PM_Penal_Id IN (SELECT MAX(PM_Penal_Id) FROM Penal_Master WHERE PM_Status = 'A' GROUP BY PM_Penal_Code))
 Begin
	Set @Value = 'E'
	Set @RetMessage = 'Penal Code ''' + @i_strPenalCode + ''' does not exist'

	Goto AddData
 End
 Else If (@i_strMinimumCode Is Not Null And @i_strMinimumCode <> '') And 
 Not Exists(Select MM_Code From Minimum_Master Where MM_Code = @i_strMinimumCode And MM_Status = 'A' And MM_Enabled = 'Y'
					And MM_Minimum_Id IN (SELECT MAX(MM_Minimum_Id) FROM Minimum_Master WHERE MM_Status = 'A' GROUP BY MM_Code))
 Begin
	Set @Value = 'E'
	Set @RetMessage = 'Minimum Code ''' + @i_strMinimumCode + ''' does not exist'

	Goto AddData
 End
 Else If (@i_strMaximumCode Is Not Null And @i_strMaximumCode <> '') And 
 Not Exists(Select MM_Code From Maximum_Master Where MM_Code = @i_strMaximumCode And MM_Status = 'A' And MM_Enabled = 'Y'
					And MM_Maximum_Id IN (SELECT MAX(MM_Maximum_Id) FROM Maximum_Master WHERE MM_Status = 'A' GROUP BY MM_Code))
 Begin
	Set @Value = 'E'
	Set @RetMessage = 'Maximum Code ''' + @i_strMaximumCode + ''' does not exist'

	Goto AddData
 End

 AddData:
 Insert Into @ValueTable(Value, RetMessage) Values(@Value, @RetMessage)
 Return
 END        
         
 